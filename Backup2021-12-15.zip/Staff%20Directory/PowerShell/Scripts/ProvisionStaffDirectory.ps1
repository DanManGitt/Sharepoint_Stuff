Param(   
    [string]$SiteCollectionUrl								
)

$ErrorActionPreference = 'Stop'
$curDateTime = Get-Date -Format 'dd/MM/yyyy HH:mm:s'   
$fields = "$PSScriptRoot\..\..\SharePoint\Templates\Fields\Fields.xml"
$contenttypes = "$PSScriptRoot\..\..\SharePoint\Templates\ContentTypes\ContentTypes.xml"
$lists = "$PSScriptRoot\..\..\SharePoint\Templates\Lists\Lists.xml"
$assets = "$PSScriptRoot\..\..\SharePoint\Templates\Assets\Assets.xml"

If ((Get-PsSnapin |?{$_.Name -eq "Microsoft.SharePoint.PowerShell"})-eq $null){
    Write-Host 'Adding PS Snapin'        
    Add-PsSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue | Out-Null
}

$scriptDir = Split-Path $script:MyInvocation.MyCommand.Path

Write-Host 'Running script at'$myInvocation.MyCommand.Definition'on'$curDateTime 
Write-Host ''		

# Get template site if not entered
if($SiteCollectionUrl -eq ''){
    $SiteCollectionUrl = Read-Host "Enter the Url of the site collection you wish to create or provision to";
}	

# trim trailing slash if there is one
$SiteCollectionUrl = $SiteCollectionUrl.TrimEnd('/')

# Check if site already exists
Write-Host 'Getting Site'	    

# Notify if site doesn't exist
if($site -eq $null){
    Write-Output $SiteCollectionUrl " doesn't exist"
}

# Start Pnp Trace Logging	
$TraceLogLocation = $scriptDir + "\trace-log.txt";
Write-Output $("Writing to PnP trace log at location {0}" -f $TraceLogLocation)
Set-PnPTraceLog -On -LogFile $TraceLogLocation -Level Debug -AutoFlush $true

try
{    	
    # Connect to site
    Write-Output $("Connecting to {0}..." -f $SiteCollectionUrl);
    Connect-PnPOnline -Url $SiteCollectionUrl -Credentials WCMStoredCredentials -IgnoreSslErrors;  
    if($site -ne $null){
        $confirmation = Read-Host "Site already exists at"$SiteCollectionUrl". Apply template to this existing site? (y/n)"
        if ($confirmation -ne 'y') {            
            Write-Host "Exiting"
            exit
        }        
    }  
    Write-Output "Context obtained";
    # Apply fields
    Write-Host "Applying Fields template" -ForegroundColor Magenta;
    Apply-PnPProvisioningTemplate -Path $fields
    Write-Host "Done :-)" -ForegroundColor Green

    # Apply content types
    Write-Host "Applying Content types template" -ForegroundColor Magenta;
    Apply-PnPProvisioningTemplate -Path $contenttypes
    Write-Host "Done :-)" -ForegroundColor Green

    # Apply lists
    Write-Host "Applying Lists/libraries template" -ForegroundColor Magenta;
    Apply-PnPProvisioningTemplate -Path $lists
    Write-Host "Done :-)" -ForegroundColor Green

    # Apply assets
    Write-Host "Applying Assets template" -ForegroundColor Magenta;
    Apply-PnPProvisioningTemplate -Path $assets
    Write-Host "Done :-)" -ForegroundColor Green

    Write-Host "Script completed succesfully." -ForegroundColor Green
}
catch
{
    Write-Error $_.Exception.Message
    Write-Error $_.Exception.ItemName
}
finally
{
    Set-PnPTraceLog -Off
    Disconnect-PnPOnline
}