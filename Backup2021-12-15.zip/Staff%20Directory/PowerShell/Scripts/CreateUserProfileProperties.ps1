#=======================================================================================================
#   Parameters
#=======================================================================================================
# Param 1 - The csv file path and name
# Param 2 - The Site URL
# Param 3 - logFile

#=======================================================================================================
#   CSV File Structure
#=======================================================================================================
# PropertyName   - This field is used for the Internal Name of the User Profile.
# DisplayName    - This field is used for the Display Name property of the User Profile Property.
# Privacy        - The allowed values are - Public, Contacts, Organization, Manager, Private and NotSet
# Privacy Policy - The allowed values are - Mandatory, OptIn, OptOut and Disabled
# Type           - The data type of the property.
# Length         - In case of string, enter this value or enter 0
# ConnectionName - The Synchronization connection name.
# AttributeName  - The attribute from the synchronization that you would like to map to.
# IsMultivalued  - Whether this property will hold multiple values.
# Remove         - This will allow the script to remove the field --> Be careful as all data in this field will be lost!!!!
# Create         - This will allow the script to create the field

#=======================================================================================================
#   CSV File Example
#=======================================================================================================
# PropertyName,DisplayName,Privacy,PrivacyPolicy,Type,Length,ConnectionName,AttributeName,IsMultivalued,Remove,Create
# LocationBuilding,Location Building,Public,OptOut,string,200,,,false,false,true
# LocationFloor,Location Floor,Public,OptOut,string,200,,,false,false,true
# LocationWorkstation,Location Workstation,Public,OptOut,string,200,,,false,false,true

param($Parm1, $Parm2, $Parm3)
#write-host "CreateuserProfileProperties called" $Parm1, $Parm2

#Load SharePoint User Profile assemblies
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Office.Server") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Office.Server.UserProfiles")| Out-Null

if ($Parm3) {
  $logFile = $Parm3
} else {  
  $logFile = "$PSScriptRoot\Logs\" + (Get-Date -Format "yyyyMMddTHHmm") + ".txt"
}

function log($msg) {
  if ($logFile) {
    $msg | Add-Content $logFile
  } 
}

function provisionProfileFields() {   

  $userProps = Import-Csv $Parm1
    
  #Get UserProfileManager
  $mySiteUrl = $Parm2
  $site = Get-SPSite $mySiteUrl
  $context = Get-SPServiceContext $site
  $upConfigManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileConfigManager($context)
  $profilePropertyManager = $upConfigManager.ProfilePropertyManager
  $coreprofilePropertyManager = $profilePropertyManager.GetCoreProperties()
  $userProfileTypeProperties = $profilePropertyManager.GetProfileTypeProperties([Microsoft.Office.Server.UserProfiles.ProfileType]::User)
  $userProfileSubTypeManager = [Microsoft.Office.Server.UserProfiles.ProfileSubTypeManager]::Get($context)
  $userProfile = $userProfileSubTypeManager.GetProfileSubtype([Microsoft.Office.Server.UserProfiles.ProfileSubtypeManager]::GetDefaultProfileName([Microsoft.Office.Server.UserProfiles.ProfileType]::User))
  $userProfileProperties = $userProfile.Properties 

  Foreach ($userProp in $userProps)
  {
    #Set Custom Property values
    $PropertyName = $userProp.PropertyName
    $PropertyDisplayName = $userProp.DisplayName
    $Privacy= $userProp.Privacy
    $PrivacyPolicy = $userProp.PrivacyPolicy
    $coreProperty = $coreprofilePropertyManager.Create($false)
    $coreProperty.Name = $PropertyName
    $coreProperty.DisplayName = $PropertyDisplayName
    $coreProperty.Type = $userProp.Type

    #Check if the Type is string then assign the length.
    if ($userProp.Type -eq "string")
    {
      $coreProperty.Length = $userProp.Length
    }

    if ($userProp.IsMultivalued -eq "true")
    {
      $coreProperty.IsMultivalued = $true
    }
    $foundProperty = $coreprofilePropertyManager.GetPropertyByName($userProp.PropertyName)

    #if the property is found then we delete that property.
    if (($foundProperty -ne $null) -and ($userProp.remove -eq $true))
    {
      #Uncomment the code to delete the property.
      $msg = "Removing profile property" + $userProp.PropertyName
      Write-host $msg 
      log $msg
      $coreprofilePropertyManager.RemovePropertyByName($userProp.PropertyName)
    }

    $foundProperty = $coreprofilePropertyManager.GetPropertyByName($userProp.PropertyName)
    if (($foundProperty -eq $null) -and ($userProp.create -eq $true))
    {
      $msg = "Creating profile property $userProp.PropertyName"
      Write-host $msg -f green
      log $msg

      $coreprofilePropertyManager.Add($coreProperty)
      $profileTypeProperty = $userProfileTypeProperties.Create($coreProperty)

      #Show on the Edit Details page
      $profileTypeProperty.IsVisibleOnEditor = $true
  
      #Show in the profile properties section of the user's profile page
      $profileTypeProperty.IsVisibleOnViewer = $true
  
      #Show updates to the property in newsfeed
      $profileTypeProperty.IsEventLog = $true
  
      $userProfileTypeProperties.Add($profileTypeProperty)
      $profileSubTypeProperty = $userProfileProperties.Create($profileTypeProperty)
      $profileSubTypeProperty.DefaultPrivacy =[Microsoft.Office.Server.UserProfiles.Privacy]::$Privacy
      $profileSubTypeProperty.PrivacyPolicy = [Microsoft.Office.Server.UserProfiles.PrivacyPolicy]::$PrivacyPolicy
      $userProfileProperties.Add($profileSubTypeProperty)
  
      #Add New Mapping for synchronization user profile data
      #SharePoint Synchronization connection
      if ($userProp.ConnectionName -ne '') {
        $connectionName =$userProp.ConnectionName
  
        #Attribute name in Connection Source
        $attributeName =$userProp.AttributeName
  
        $synchConnection = $upConfigManager.ConnectionManager[$connectionName]
        $synchConnection.PropertyMapping.AddNewMapping([Microsoft.Office.Server.UserProfiles.ProfileType]::User,$PropertyName,$attributeName)
      }
    } else {
      if ($userProp.create -eq $true) {
        $msg = "Cannot create profile property " + $userProp.PropertyName + "as it already exists"
        Write-host $msg -f red
        log $msg
      }
    }
  }
}


try {
  provisionProfileFields 
}
Catch{
  $output = $_.Exception.Message
  write-host $output -ForegroundColor Red
  log $output
}
Finally{
  #$web.Dispose()
}