#=======================================================================================================
#   Parameters
#=======================================================================================================
# Param 1 - The Site URL
# Param 2 - List
# Param 3 - Users to import
# Param 4 - logFile
param($Parm1, $Parm2, $parm3, $Parm4)
Add-PsSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

#write-host "BackupFieldsToUserProfileProperties called" $Parm1, $Parm2, $Parm3

switch($env:USERDOMAIN){
  { $_ -in ("DEV", "TEST") } { $e = "dev"; $prefix = "dev"; $webUrl="https://aechub.dev.aec.local/apps/people" }
  { $_ -eq ("UAT") } { $e = "prod"; $prefix = "uat"; $webUrl="https://aechub.uat.aec.local/apps/people" } #uses $e = prod because profile syncs with PROD domain
  default { $e = "prod"; $prefix = "prod"; $webUrl="https://aechub.prod.aec.gov.au/apps/people" }
}

if ($Parm1) { #Use Param if supplied
  $webUrl = $Parm1
}

if ($Parm2) { #Use Param if supplied
  $ListName =  $Parm2
} else {
  $ListName = "Corporate Directory Users"
}
$Fields = @(
    #[pscustomobject]@{listField='UserInformation';     profileField='AboutMe'},
    [pscustomobject]@{listField='LocationBuilding';    profileField='LocationBuilding'},
    [pscustomobject]@{listField='LocationFloor';       profileField='LocationFloor'},
    [pscustomobject]@{listField='LocationWorkstation'; profileField='LocationWorkstation'},
    [pscustomobject]@{listField='LocationImage';       profileField='LocationImage'},
    [pscustomobject]@{listField='LocationX';           profileField='LocationX'},
    [pscustomobject]@{listField='LocationY';           profileField='LocationY'}
)

if ($Parm3) { #Use Param if supplied
  $importUsers = $Parm3
} else {  
  $importUsers = @()
}

#write-host "import Users"
#$importUsers

if ($Parm4) { #Use Param if supplied
  $logFile = $Parm4
} else {  
  $logFile = "$PSScriptRoot\Logs\" + (Get-Date -Format "yyyyMMddTHHmm") + ".txt"
}

function log($msg) {
  if ($logFile) {
    $msg | Add-Content $logFile
  } 
}

function BackupFields([Microsoft.SharePoint.SPList] $userList, $fields){   
  $listItems = $null
  
  $TotalUsers = 0
  $usersUpdated = 0
  $usersSkipped = 0
  $errors = 0

  # retrieve all existing items to delete
  $query = New-Object Microsoft.SharePoint.SPQuery;
  $query.ViewAttributes = "Scope='Recursive'";
  $query.RowLimit = 10000;   
  $listItems = $userList.GetItems($query)

  $ServiceContext  = Get-SPServiceContext -site $webUrl
  $UserProfileManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileManager($ServiceContext)
  
  foreach ($item in $listItems)
  {
    $TotalUsers = $TotalUsers + 1
    $userID = $e + "\" + $item["UserID"]      

    #$output = $userID + " - Checking for changes"
    #write-host $output -f yellow
    #log $output

    if ($UserProfileManager.UserExists($userID)) {
      $UserProfile = $UserProfileManager.GetUserProfile($userID)
      $itemChanged = $false

      foreach ($field in $Fields) {
        $isListFieldEmpty = [string]::IsNullOrWhitespace($item[$field.listField])
        $isProfileFieldEmpty = [string]::IsNullOrWhitespace($userProfile[$field.profileField].Value)
        if (($item[$field.listField] -ne $userProfile[$field.profileField].Value) -and
            !($isListFieldEmpty -and $isProfileFieldEmpty)) {
          $itemChanged = $true;
          break;
          
        }
      }

      $currentUpdateField
      #change detected so update profile
      if ($itemChanged) {
        try {
          $output = "Change detected - Updating profile for $userID "
          write-host $output -f Green
          log $output

          foreach ($field in $Fields) {
            $currentUpdateField = $field
            $output = "  current values List:Profile " + $userProfile[$field.profileField].Value + " : " + $item[$field.listField]
            write-host $output -f Green
            log $output

            $userProfile[$field.profileField].Value = $item[$field.listField]
            #Set-PnPUserProfileProperty -Account $userID -Property $field.profileField -Value $item[$field.listField]
          }
          
          $userProfile.Commit() 
          $usersUpdated++
        }
        catch {
          $errors = $errors + 1

          $output = "Failed trying to update: " + $userID + " -> " + $currentUpdateField.profileField + " to value: " +  $item[$currentUpdateField.listField]
          write-host $output -f Red
          log $output     

          write-host $_.Exception.Message -ForegroundColor Red
          log $_.Exception.Message
        }
      }
    } else {
      $usersSkipped = $usersSkipped + 1

      $output = "$usersSkipped - Skipping user as no profile available: $userID"
      #write-host $output -f red
      log $output


      #check if this user has data that should be updated in their profile
      $userChangedMsg = "`r`nChanged detected - profile not found for $userID - Data could not be updated to profile "

      # I couldn't get this to work 
      #$users = $importUsers | Where {$_.UserAccountID -eq $item["UserID"]} 
      #if ($users.count -gt 0) {
      #  $importUser = $users[0]
      #}

      # So finding user manually
      $importUser = $null
      for ($i = 0; $i -lt $importUsers.count; $i++) {        
        if ($importUsers[$i].UserAccountID -eq $item["UserID"]) {
            #write-host $importUsers[$i].UserAccountID
            $importUser = $importUsers[$i]
            break;
        }
      }

      #if ($importUser -ne $null){
      #  Write-Host "User FOund: " + $importUser.UserAccountID
      #}

      if (($importUser -ne $null) -or ($importUsers.count -eq 0)) { #only report user error if they are going to be imported (or if we dont have a list of users to import
        foreach ($field in $Fields) {
          if (![string]::IsNullOrWhitespace($item[$field.listField])) {


            # report User details 
            if (![string]::IsNullOrWhitespace($userChangedMsg)) {
              $errors = $errors + 1 #only update count once per person
              write-host $userChangedMsg -f red
              log $userChangedMsg
              $userChangedMsg = ""
            }

            $output = "  Field: '" + $field.listField + "'`t`t Value: '" +  $item[$field.listField] + "'"
            write-host $output -f red
            log $output

            #break;
          }
        }
      }
    }
  }
  
  $msg  = "`r`nBackup summary `r`n"
  $msg += "    Total users  : $TotalUsers `r`n"
  $msg += "    Users updated: $usersUpdated `r`n"
  $msg += "    Users skipped: $usersSkipped `r`n"
  $msg += "    Error Count  : $errors `r`n"
  log ""
  log $msg
  if ($errors -eq 0){
    write-host $msg -f green
  }
  else {
    write-host $msg -f red
  }

  return $errors
}

$exitValue = 0

try {
  $web = Get-SPWeb -Identity $webUrl
  Connect-PnPOnline -Url $webUrl -CurrentCredentials
  $List = $web.Lists[$ListName]

  if (!$logFile) { 
    Write-host "No log file supplied"
  }

  $exitValue = BackupFields $List $Fields $importUsers
  $exitValue = $exitValue[-1] #simple tric to get the actual returnvalue I expected.
}
Catch{
    $output = $_.Exception.Message
    write-host $output -ForegroundColor Red
    log $output

    $exitValue = 1 #report failure if exception occurrs
}
Finally{
    $web.Dispose()
    $output = "Exiting backup with value: $exitValue"
    Write-host $output
    log $output

    exit $exitValue
}