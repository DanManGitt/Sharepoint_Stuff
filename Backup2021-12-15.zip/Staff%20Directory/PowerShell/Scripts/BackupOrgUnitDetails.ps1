#=======================================================================================================
#   Parameters
#=======================================================================================================
# Param 1 - The Site URL
# Param 2 - From List
# Param 3 - To List
# Param 4 - logFile
param($Parm1, $Parm2, $parm3, $Parm4)
Add-PsSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

#write-host "BackupOrdDetails called" $Parm1, $Parm2, $Parm3, $Parm4

if ([string]::IsNullOrWhitespace($webUrl)) {
  switch($env:USERDOMAIN){
      { $_ -in ("DEV", "TEST") } { $e = "dev"; $webUrl="https://aechub.dev.aec.local/apps/people" }
      { $_ -eq ("UAT") } { $e = "prod";  $webUrl="https://aechub.uat.aec.local/apps/people" } #uses $e = prod because profile syncs with Prod domain
      default { $e = "prod"; $webUrl="https://aechub.prod.aec.gov.au/apps/people" }
  }
}

if ($Parm1) { #Use Param if supplied
  $webUrl = $Parm1
}

if ($Parm2) { #Use Param if supplied
  $FromListName =  $Parm2
} else {
  $FromListName = "Corporate Directory Org Units"
}

if ($Parm3) { #Use Param if supplied
  $ToListName = $Parm3
} else {  
  $ToListName = "Corporate Directory Org Units Details"
}

if ($Parm4) { #Use Param if supplied
  $logFile = $Parm4
} else {  
  $logFile = "$PSScriptRoot\Logs\OrgDetailsBackup_" + (Get-Date -Format "yyyyMMddTHHmm") + ".txt"
}

$Fields = @(
  [pscustomobject]@{fromListField='Title';           toListField='Title'},
  [pscustomobject]@{fromListField='OrgUnitNumber';   toListField='OrgUnitNumber'},
  [pscustomobject]@{fromListField='UnitDescription'; toListField='UnitDescription'},
  [pscustomobject]@{fromListField='GroupMailbox';    toListField='GroupMailbox'},
  [pscustomobject]@{fromListField='Manager';         toListField='Manager'},
  [pscustomobject]@{fromListField='BPO';             toListField='BPO'}
)

function log($msg) {
  if ($logFile) {
    $msg | Add-Content $logFile
  } 
}

function BackupOrgFields($FromListName, $ToListName, $Fields) {
  $listItems = $null;
  
  $TotalOrgs = 0;
  $orgsUpdated = 0;
  $orgsSkipped = 0;
  $errors = 0;

  $listItems = Get-PnPListItem -List $FromListName
  
  foreach ($item in $listItems)
  {
    $itemChanged = $false;
    $TotalOrgs++
    $orgunitID = $item["OrgUnitNumber"]      

    $query = "<View><Query><Where><Eq><FieldRef Name='OrgUnitNumber'/><Value Type='Number'>$orgunitID</Value></Eq></Where></Query></View>"
    $updateItem = Get-PnPListItem -List $ToListName -Query $query

    $newValues = @{};
    foreach ($field in $Fields) {
     $newValues[$field.toListField] = $item[$field.fromListField]
    }
    #$newValues | select-object *
    
    if ($updateItem.count -gt 0){
      foreach ($field in $Fields) {
        #write-host "Checking Field: '"$field.toListField"' Original: '"$updateItem[$field.toListField]"' New '"$item[$field.fromListField]"' changed: " ($item[$field.fromListField] -ne $updateItem[$field.toListField])
        if ($item[$field.fromListField] -ne $updateItem[$field.toListField]) {
          $itemChanged = $true;
          break;
        }
      }

      if ($itemChanged) {
        try {
          $output = "Change detected - Updating Org for ID: $orgunitID "
          write-host $output -f Green
          log $output

          $orgsUpdated++
          Set-PnPListItem -List $ToListName -Identity $updateItem -Values $newValues
        }
        catch {
          $errors = $errors + 1

          $output = "Failed trying to update: " + $orgunitID + " -> " + $currentUpdateField.toListField + " to value: " +  $item[$currentUpdateField.fromListField]
          write-host $output -f Red
          log $output     

          write-host $_.Exception.Message -ForegroundColor Red
          log $_.Exception.Message
        }
      }  else {
        $output = "Change not detected - skipping Org for ID: $orgunitID "
        write-host $output -f yellow
        log $output

        $orgsSkipped++
      }    
    } else {
      $output = "Item not found - adding Org for ID: $orgunitID "
      write-host $output -f green
      log $output

      #$newItem = 
      Add-PnPListItem -List $ToListName -Values $newValues 
      #Set-PnPListItem -List $ToListName -Identity $newItem -Values $newValues 
    }
  }
  
  $msg  = "`r`nBackup summary `r`n"
  $msg += "    Total Orgs   : $TotalOrgs `r`n"
  $msg += "    Orgs updated : $orgsUpdated `r`n"
  $msg += "    Orgs skipped : $orgsSkipped `r`n"
  $msg += "    Error Count  : $errors `r`n"
  log ""
  log $msg
  if ($errors -eq 0){
    write-host $msg -f green
  }
  else {
    write-host $msg -f red
  }

  return $errors
}

$exitValue = 0

try {
  $web = Get-SPWeb -Identity $webUrl
  Connect-PnPOnline -Url $webUrl -CurrentCredentials

  if (!$logFile) { 
    Write-host "No log file supplied"
  }

  $exitValue = BackupOrgFields -FromListName $FromListName -ToListName $ToListName -Fields $Fields
  $exitValue = $exitValue[-1] #simple trick to get the actual returnvalue I expected.
}
Catch{
    $output = $_.Exception.Message
    write-host $output -ForegroundColor Red
    log $output

    $exitValue = 1 #report failure if exception occurrs
}
Finally{
    $web.Dispose()
    $output = "Exiting backup with value: $exitValue"
    Write-host $output
    log $output

    exit $exitValue
}