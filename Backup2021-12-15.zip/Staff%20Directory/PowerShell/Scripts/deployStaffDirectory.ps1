# Set-Executionpolicy -Scope Process -ExecutionPolicy UnRestricted

#################################
# uncomment as required
#################################
$siteUrl = "https://aechub.dev.aec.local/apps/people"
#$siteUrl = "https://aechub.uat.aec.local/apps/people"
#$siteUrl = "https://aechub.prod.aec.gov.au/apps/people"
#$siteUrl = "https://teams.uat.aec.local/"
#$siteUrl = "https://teams.uat.aec.local/sites/admin"
#$siteUrl = "https://teams.prod.aec.gov.au/"
#$siteUrl = "https://teams.prod.aec.gov.au/sites/admin"


& "$PSScriptRoot\ProvisionStaffDirectory.ps1" -SiteCollectionUrl $siteUrl -SiteTitle $siteTitle -NewSiteType $siteType -DocIDPrefix $docIdPrefix -SiteType $siteTemplate
