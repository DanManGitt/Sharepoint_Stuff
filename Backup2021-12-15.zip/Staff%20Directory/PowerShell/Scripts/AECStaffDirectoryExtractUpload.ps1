<#
Script to populate APS leaves from Aurion
#>
function GetExistingOrgUnits([Microsoft.SharePoint.SPList] $orgUnitList){   
  $listItems = $null    

    # retrieve all existing items to delete
  $query = New-Object Microsoft.SharePoint.SPQuery;				
  # $query.ViewFields = "<FieldRef Name=`"Name`"/><FieldRef Name=`"OrgUnitNumber`" /><FieldRef Name=`"Title`" /><FieldRef Name=`"UnitDescription`" /><FieldRef Name=`"Manager`" /><FieldRef Name=`"GroupMailbox`" /><FieldRef Name=`"BPO`" />";
  $query.ViewFields = "<FieldRef Name='Name'/><FieldRef Name='OrgUnitNumber' /><FieldRef Name='Title' />";
  $query.ViewFieldsOnly = $true;    
  $query.RowLimit = 10000;            
  $listItems = $orgUnitList.GetItems($query)
  return $listItems             
}

function DeleteExistingOrgUnits([Microsoft.SharePoint.SPList] $orgUserList, [System.Object[]] $existingOrgUnits)
{   
  #build the batch operation
  $itemCount = 0;
  $listId = $orgUnitList.ID;
  [System.Text.StringBuilder]$batchXml = New-Object "System.Text.StringBuilder";
  $batchXml.Append("<?xml version=`"1.0`" encoding=`"UTF-8`"?><Batch>") | Out-Null;
  $command = [System.String]::Format( "<Method><SetList>{0}</SetList><SetVar Name=`"ID`">{1}</SetVar><SetVar Name=`"Cmd`">Delete</SetVar></Method>", $listId, "{0}" );  

  foreach ($item in $existingOrgUnits)
  {
    # dont remove the Executive Org Unit as its used to map the electoral commisioner, board members, division heads etc. to one common "branch"
    if($item -ne $null -and $item.Title -ne "Executive"){                                    
      $batchXml.Append([System.String]::Format($command, $item.ID.ToString())) | Out-Null; $itemCount++;
    }
  }
  
  $batchXml.Append("</Batch>") | Out-Null;
  $web.ProcessBatchData($batchXml.ToString()) | Out-Null;    

  write-host ""
  $output = "{0} existing org units found in list {1}/Lists/{2}" -f $itemCount, $web.Url,$orgUnitList.Title            
  write-host $output
  $output | Add-Content $logFile                            

  $output = "Deleting existing org units from list"
  write-host $output...
  $output | Add-Content $logFile   

  $output = "{0} org units deleted `r`n" -f $itemCount
  write-host $output -ForegroundColor Green
  $output | Add-Content $logFile  
}

function AddNewOrgUnits([Microsoft.SharePoint.SPList] $orgUserList, [System.Object[]] $existingOrgUnits, [System.Object[]] $newOrgUnits)
{   
    $output = "{0} org units found in Aurion extract" -f $newOrgUnits.Count 
    write-host $output
    $output | Add-Content $logFile

    $output = "Adding new org units to list..."
    write-host $output
    $output | Add-Content $logFile
    
    # add new org units from Aurion extract to org unit list            
    foreach($contentItem in $newOrgUnits){                

        $itemsAdded  = $itemsAdded  + 1                                               
        
        # create list item
        $newOrgUnit= $orgUnitList.items.add()

        # set properties
        $newOrgUnit["Title"] = $contentItem.OrgUnitDescription
        if($contentItem.OrgUnitLevel -eq 5 -and $contentItem.SuperiorOrgUnitNumber -eq 3){
          $newOrgUnit["OrgUnitLevel"] = 4
          $newOrgUnit["ParentOrganisationUnit"] = 4
        }
        else{
          $newOrgUnit["OrgUnitLevel"] = $contentItem.OrgUnitLevel
          $newOrgUnit["ParentOrganisationUnit"] = $contentItem.SuperiorOrgUnitNumber
        }
        $newOrgUnit["OrgUnitNumber"] = $contentItem.OrgUnitNumber

        # preserve data in the unitdescription, groupmailbox and manager fields from the previous org unit upload
        # if($existingOrgUnits -ne $null){
        #   $obj = $existingOrgUnits | Where-Object {$_["OrgUnitNumber"] -eq $newOrgUnit["OrgUnitNumber"]}        
        #   if($obj){
        #     # $newOrgUnit["UnitDescription"] = $obj["UnitDescription"];
        #     $newOrgUnit["GroupMailbox"] = $obj["GroupMailbox"];             
        #     $newOrgUnit["Manager"] = $obj["Manager"];  
        #     $newOrgUnit["BPO"] = $obj["BPO"]; 
        #   }
        # }

        # update item
        $newOrgUnit.update()      
    }

    $output = "{0} org units added `r`n" -f $itemsAdded  
    write-host $output -ForegroundColor Green
    $output | Add-Content $logFile   
    
}    

 function GetExistingUsers([Microsoft.SharePoint.SPList] $userList){   

    $listItems = $null
    
    # retrieve all existing items to delete
    $query = New-Object Microsoft.SharePoint.SPQuery;
    $query.ViewAttributes = "Scope='Recursive'";
    $query.RowLimit = 10000;   
    $listItems = $userList.GetItems($query)
    return $listItems             
}

function DeleteOldUsers([Microsoft.SharePoint.SPList] $userList, [System.Object[]] $existingUsers)
{

    # build the batch operation
    $itemCount = 0;
    $listId = $userList.ID;
    [System.Text.StringBuilder]$batchXml = New-Object "System.Text.StringBuilder";
    $batchXml.Append("<?xml version=`"1.0`" encoding=`"UTF-8`"?><Batch>")  | Out-Null;
    $command = [System.String]::Format( "<Method><SetList>{0}</SetList><SetVar Name=`"ID`">{1}</SetVar><SetVar Name=`"Cmd`">Delete</SetVar></Method>", $listId, "{0}" );

    foreach ($item in $existingUsers)
    {
      if($item -ne $null){                                            
        $batchXml.Append([System.String]::Format($command, $item.ID.ToString())) | Out-Null; $itemCount++;
      }
    }

    $batchXml.Append("</Batch>")  | Out-Null;            

    write-host ""
    $output = "{0} existing users found in list {1}/Lists/{2}" -f $itemCount, $web.Url,$userList.Title            
    write-host $output
    $output | Add-Content $logFile                            

    $output = "Deleting existing users from list"
    write-host $output...
    $output | Add-Content $logFile   

    # execute batch operation
    $web.ProcessBatchData($batchXml.ToString()) | Out-Null;                       

    $output = "{0} users deleted `r`n" -f $itemCount
    write-host $output -ForegroundColor Green
    $output | Add-Content $logFile
}

function AddNewUsers([Microsoft.SharePoint.SPList] $userList, [System.Object[]] $newUsers,[System.Object[]] $newOrgUnits, 
                      [System.Object[]] $existingUsers, [System.Object[]] $newRoles)
{   
  $output = "{0} users found in Aurion extract" -f $newUsers.Count 
  write-host $output
  $output | Add-Content $logFile

  $output = "Adding new users to list"
  write-host $output...
  $output | Add-Content $logFile
          
  # add new user detail items from Aurion extract to user details list            
  foreach($contentItem in $newUsers){                

    #write-host $contentItem.UserAccountID 
    if ($contentItem.UserAccountID -ne "dcowdroy") { 
      $itemsAdded  = $itemsAdded  + 1 
      #write-host "proceeding" $itemsAdded
      
      # get user from SP User Profile Manager (for details not supplied in Aurion extract)
      $userID = $e + "\" + $contentItem.UserAccountID       
      $userProfile = Get-PnPUserProfileProperty -Account $userID
              
      # create list item
      $newUser = $userList.items.add()

      # set properties
      $newUser["UserID"] = $contentItem.UserAccountID
      $newUser["FirstName"] = $contentItem.FirstName
      # $newUser["LastName"] = $contentItem.Surname
      if ($userProfile.UserProfileProperties.LastName -ne $null) {
        $newUser["LastName"] = $userProfile.UserProfileProperties.LastName
      } else {
        $newUser["LastName"] = $contentItem.Surname
      }
      $newUser["PreferredName"] = $contentItem.PreferredName
      
      $newUser["JobTitle"] = $contentItem.JobTitle

      # if AD job title is blank, user Aurion job title
      #if($newUser["JobTitle"] -eq "" -or $newUser["JobTitle"] -eq $null){
          #$newUser["JobTitle"] = $contentItem.JobTitle
      #}

      $newUser["WorkPhone"] = $userProfile.UserProfileProperties.WorkPhone
      $newUser["Extension"] = $userProfile.UserProfileProperties.IPPhone
      $newUser["CellPhone"] = $userProfile.UserProfileProperties.CellPhone
      $newUser["PictureURL"] = $userProfile.UserProfileProperties.PictureURL
      $newUser["OfficeLocation"] = $userProfile.UserProfileProperties.Office
      $newUser["State"] = $userProfile.UserProfileProperties.State
      $newUser["Email"] = $contentItem.EmailAddress      
      $newUser["Manager"] = $contentItem.Manager  
      $newUser["ManagerId"] = $contentItem.ManagerId   
      
      # if the backup to user profile succeeded
      if ($profileBackupErrorCount -eq 0){
        $newUser["LocationBuilding"] = $userProfile.UserProfileProperties.LocationBuilding
        $newUser["LocationFloor"] = $userProfile.UserProfileProperties.LocationFloor
        $newUser["LocationWorkstation"] = $userProfile.UserProfileProperties.LocationWorkstation
        $newUser["LocationImage"] = $userProfile.UserProfileProperties.LocationImage
        $newUser["LocationX"] = $userProfile.UserProfileProperties.LocationX
        $newUser["LocationY"] = $userProfile.UserProfileProperties.LocationY        
      }
      
      # preserve data in the userinformation field from the previous user upload
      if($existingUsers -ne $null){
        $obj = $existingUsers | Where-Object {$_["UserID"] -eq $newUser["UserID"]}        
        if($obj){
          $newUser["UserInformation"] = $obj["UserInformation"];                           

          # if the backup to user profile failed use data from existing users list infomation
          if ($profileBackupErrorCount -ne 0){
            $newUser["LocationBuilding"] = $obj["LocationBuilding"];
            $newUser["LocationFloor"] = $obj["LocationFloor"];
            $newUser["LocationWorkstation"] = $obj["LocationWorkstation"];
            $newUser["LocationImage"] = $obj["LocationImage"];
            $newUser["LocationX"] = $obj["LocationX"];
            $newUser["LocationY"] = $obj["LocationY"];            
          }
        } 
      }      

      $orgUnitNumber = $contentItem.OrganisationUnitNumber     

      #get team/section/branch details for user
      $orgUnit = $newOrgUnits | Where-Object {$_.OrgUnitNumber -eq $orgUnitNumber}                 

      #if user has a branch, section or team they are not an executive
      $isExecutive = $true        

      if($orgUnit -ne $null){

        #org unit is a team (level 6)
        if($orgUnit.OrgUnitLevel -eq 6){ 
          $newUser["Team"] = $orgUnit.OrgUnitDescription
          $newUser["TeamNumber"] = $orgUnit.OrgUnitNumber
          
          #get parent org unit details
          $pou = $orgUnit.SuperiorOrgUnitNumber                               
          $orgUnit = $newOrgUnits | Where-Object {$_.OrgUnitNumber -eq $pou}                         
          $isExecutive = $false
        }
            
        #org unit is a section (level 5)
        if($orgUnit.OrgUnitLevel -eq 5){ 
          $newUser["Section"] = $orgUnit.OrgUnitDescription
          $newUser["SectionNumber"] = $orgUnit.OrgUnitNumber
          
          #get parent org unit details
          $pou = $orgUnit.SuperiorOrgUnitNumber
          $orgUnit = $newOrgUnits | Where-Object {$_.OrgUnitNumber -eq $pou}                         
          $isExecutive = $false
        }

        #org unit is a branch (level 4)
        if($orgUnit.OrgUnitLevel -eq 4){ 
          $newUser["Branch"] = $orgUnit.OrgUnitDescription
          $newUser["BranchNumber"] = $orgUnit.OrgUnitNumber

          #get parent org unit details
          $pou = $orgUnit.SuperiorOrgUnitNumber
          $orgUnit = $newOrgUnits | Where-Object {$_.OrgUnitNumber -eq $pou}                         
          $isExecutive = $false
        }

        #org unit is a divsion (level 3)
        if($orgUnit.OrgUnitLevel -eq 3){ 
          $newUser["Div"] = $orgUnit.OrgUnitDescription
          $newUser["DivNumber"] = $orgUnit.OrgUnitNumber                   
        }           

      }else{
        $warningMsg += "Could not find organisation unit details for user " + $newUser["UserID"]  + " - org unit number " + $orgUnitNumber + ").`r`n"
        $warningMsgHtml += "<p stlye='font-family:calibri'>Could not find organisation unit details for user <strong>" + $newUser["UserID"]  + "</strong> - org unit number " + $orgUnitNumber + ".</p></br>"
        $isExecutive = $false
      }

      #get role for user
      if($contentItem.IdentifiedRole -ne "" -and $contentItem.IdentifiedRole -ne $null){
        $roleCode = $contentItem.IdentifiedRole  
        $role = $newRoles | Where-Object {$_.Code -eq $roleCode} 
        if($role -ne $null){ 
          $newUser["RoleCode"] = $role.Code
          $newUser["RoleLongDescription"] = $role."Long Description"
        }
        else {
          $warningMsg += "Could not find role for user " + $newUser["UserID"]  + " - role code " + $roleCode + ").`r`n"
          $warningMsgHtml += "<p stlye='font-family:calibri'>Could not find role for user <strong>" + $newUser["UserID"]  + "</strong> - role code " + $roleCode + ".</p></br>"
        }
      }

      # if user is executive set their branch to the "Executive" org unit
      if($isExecutive -and $newUser["UserID"] -ne "dorr"){            
        $newUser["Branch"] = "Executive"
        $newUser["BranchNumber"] = 0
        $newUser["IsExecutive"] = $isExecutive
      }
      if($newUser["JobTitle"] -ne "Chairperson"){
        $newUser.update()           
      }     
    }                                
  }        

  $output = "{0} users added `r`n" -f $itemsAdded  
  write-host $output -ForegroundColor Green
  $output | Add-Content $logFile

  if($warningMsg -ne $null){
    $subject = 'AEC Aurion user extract upload **Warning** SharePoint 2019 ENV:{0}' -f $prefix
    if ($sendEmail) {
      Send-MailMessage -From 'AEC Corporate Directory Upload <aecsharepoint@aec.gov.au>' -To $notifyEmailAddress -Subject $subject -BodyAsHtml $warningMsgHtml -smtpServer $smtpServer -Priority High
    }
    write-host $warningMsg -ForegroundColor Yellow
    $warningMsg | Add-Content $logFile
  }
}

function GetExistingRoles([Microsoft.SharePoint.SPList] $roleList){   

  $listItems = $null
  
  # retrieve all existing items to delete
  $query = New-Object Microsoft.SharePoint.SPQuery;
  $query.ViewAttributes = "Scope='Recursive'";
  $query.RowLimit = 10000;   
  $listItems = $roleList.GetItems($query)
  return $listItems             
}

function DeleteExistingRoles([Microsoft.SharePoint.SPList] $roleList, [System.Object[]] $existingRoles)
{
  # build the batch operation
  $itemCount = 0;
  $listId = $roleList.ID;
  [System.Text.StringBuilder]$batchXml = New-Object "System.Text.StringBuilder";
  $batchXml.Append("<?xml version=`"1.0`" encoding=`"UTF-8`"?><Batch>")  | Out-Null;
  $command = [System.String]::Format( "<Method><SetList>{0}</SetList><SetVar Name=`"ID`">{1}</SetVar><SetVar Name=`"Cmd`">Delete</SetVar></Method>", $listId, "{0}" );

  foreach ($item in $existingRoles)
  {
    if($item -ne $null){                                            
      $batchXml.Append([System.String]::Format($command, $item.ID.ToString())) | Out-Null; $itemCount++;
    }
  }

  $batchXml.Append("</Batch>")  | Out-Null;          

  write-host ""
  $output = "{0} existing roles found in list {1}/Lists/{2}" -f $itemCount, $web.Url,$roleList.Title            
  write-host $output
  $output | Add-Content $logFile                            

  $output = "Deleting existing roles from list"
  write-host $output...
  $output | Add-Content $logFile   

  # execute batch operation
  $web.ProcessBatchData($batchXml.ToString()) | Out-Null;                       

  $output = "{0} roles deleted `r`n" -f $itemCount
  write-host $output -ForegroundColor Green
  $output | Add-Content $logFile
}

function AddNewRoles([Microsoft.SharePoint.SPList] $roleList, [System.Object[]] $existingRoles, [System.Object[]] $newRoles)
{   
  $output = "{0} roles found in Aurion extract" -f $newRoles.Count 
  write-host $output
  $output | Add-Content $logFile

  $output = "Adding new roles list..."
  write-host $output
  $output | Add-Content $logFile
  
  # add new org units from Aurion extract to org unit list            
  foreach($contentItem in $newRoles){                
    $itemsAdded  = $itemsAdded  + 1                                               
    
    # create list item
    $newRole = $roleList.items.add()

    # set properties
    $newRole["RoleCode"] = $contentItem.Code
    $newRole["RoleShortDescription"] = $contentItem."Short Description"
    $newRole["RoleLongDescription"] = $contentItem."Long Description"

    # update item
    $newRole.update()      
  }

  $output = "{0} roles added `r`n" -f $itemsAdded  
  write-host $output -ForegroundColor Green
  $output | Add-Content $logFile       
}

Add-PsSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

#$fileLocation = "C:\Temp\CorpD\PowerShell\AurionDataFiles"
$fileLocation = "D:\Imports\Corporate_Directory"

$userArchiveFile = $fileLocation + "\ArchivedExtracts\"
$orgUnitArchiveFile = $fileLocation + "\ArchivedExtracts\"
$roleArchiveFile = $fileLocation + "\ArchivedExtracts\"
$e = "PROD"
$smtpServer = "smtp.prod.aec.gov.au"
$notifyEmailAddress = "aecsharepoint@aec.gov.au"
$errorMsg = ""
$webUrl=""
$sendEmail = $true

switch($env:USERDOMAIN){
  { $_ -in ("DEV", "TEST") } { $e = "dev"; $prefix = "dev"; $webUrl="https://aechub.dev.aec.local/apps/people" }
  { $_ -eq ("UAT") } { $e = "prod"; $prefix = "uat"; $webUrl="https://aechub.uat.aec.local/apps/people" } #uses $e = prod because profile syncs with PROD domain
  default { $e = "prod"; $prefix = "prod"; $webUrl="https://aechub.prod.aec.gov.au/apps/people" }
}

$output = "Commencing Aurion user extract upload at {0} `r`n" -f (Get-Date -Format "dd MMMM yyyy hh:mm tt")
write-host ""
write-host $output

$logFile = $fileLocation + "\Logs\" + (Get-Date -Format "yyyyMMddTHHmm") + ".txt"
$output | Add-Content $logFile

$userFileName = $prefix + "-aec-users-" + (Get-Date -Format 'yyyyMMdd') + "*"
$orgUnitFileName = $prefix + "-aec-org-units-" + (Get-Date -Format 'yyyyMMdd') + "*"
$roleFileName = $prefix + "-aec-roles-" + (Get-Date -Format 'yyyyMMdd') + "*"

$orgUnitBackupErrorCount = 0
$profileBackupErrorCount = 0

if((Test-Path ($fileLocation + ("\$orgUnitFileName*")) -PathType Leaf) -and (Test-Path ($fileLocation + ("\$userFileName*")) -PathType Leaf )){
  try{

    if ($sendEmail -eq $false) {
        write-host "Email functionality is currently disabled" -ForegroundColor Red
    }

    # This script only need to be ran once and therefore testing the date
    if ((Get-Date -Format "dd/MM/yyyy") -eq "02/09/2021") {
      $output = "Creating new profile fields"
      write-host $output
      $output | Add-Content $logFile	

      & "$PSScriptRoot\CreateUserProfileProperties.ps1" "$PSScriptRoot\DataFiles\NewProfileProperties.csv" $webUrl $logFile
    }

    # connect to site collection with Corporate Directory User list
    $web = Get-SPWeb -Identity $webUrl
    Connect-PnPOnline -Url $webUrl -CurrentCredentials
    #Connect-PnPOnline -Url "http://micksportal.dev.aec.local/sites/sd" -Credentials 'CorpDAurionUploadCreds'       

    Get-ChildItem $fileLocation -Filter $orgUnitFileName*.csv | 
    Foreach-Object {
      $orgUnitFile = $_.FullName
      $orgUnitArchiveFile += $_.Name
      $newOrgUnits = Import-Csv $orgUnitFile        
    }


    Get-ChildItem $fileLocation -Filter $userFileName*.csv | 
    Foreach-Object {
      $userFile = $_.FullName
      $userArchiveFile += $_.Name
      $newUsers = Import-Csv $userFile        
    }

    $newRoles = $null
    if (Test-Path ($fileLocation + ("\$roleFileName*")) -PathType Leaf) {
      Get-ChildItem $fileLocation -Filter $roleFileName*.csv | 
      Foreach-Object {
        $roleFile = $_.FullName
        $roleArchiveFile += $_.Name
        $newRoles = Import-Csv $roleFile        
      }
    } 

    # Backup Org Details to Backup List
    # $output = "Backup Org details to Org details backup list"
    # write-host $output
    # $output | Add-Content $logFile	
    
    # & "$PSScriptRoot\BackupOrgUnitDetails.ps1" $webUrl "Corporate Directory Org Units"  "OrgUnitDetailsBackup" $logFile
    # $orgUnitBackupErrorCount = $LASTEXITCODE #get exit code - this is the error count 

    # if ($orgUnitBackupErrorCount -ne 0) {
    #   $output = "Backup of org unit details - Failed"
    #   write-host $output -f red
    #   $output | Add-Content $logFile	
    # } else {
    #   $output = "Backup of org unit details - succeeded"
    #   write-host $output -f green
    #   $output | Add-Content $logFile	
    # }

    # Backup certain fields from the list to the users profile.
    $output = "Backup list fields to profile fields"
    write-host $output
    $output | Add-Content $logFile	
    & "$PSScriptRoot\BackupFieldsToUserProfileProperties.ps1" $webUrl "Corporate Directory Users" $newUsers $logFile
    $profileBackupErrorCount = $LASTEXITCODE #get exit code - this is the error count 

    if ($profileBackupErrorCount -ne 0) {
      $output = "Backup of fields to user profiles - Failed"
      write-host $output -f red
      $output | Add-Content $logFile	
    } else {
      $output = "Backup of fields to user profiles - succeeded"
      write-host $output -f green
      $output | Add-Content $logFile	
    }

    # get roles list        
    $roleList = $web.Lists["Corporate Directory Roles"]      
    # get org User list        
    $orgUnitList = $web.Lists["Corporate Directory Org Units"]      
    # get user list
    $userList = $web.Lists["Corporate Directory Users"]

    if($orgUnitList -and $userList -and $roleList){

      $existingRoles = GetExistingRoles $roleList
      if($newRoles -ne $null) {
        AddNewRoles $roleList $existingRoles $newRoles		
        DeleteExistingRoles $roleList $existingRoles              
      } else {
        $output = "No Roles file found - using existing Roles"
        write-host $output
        $output | Add-Content $logFile	

        $newRoles = $()
        #convert Existing items to an array, as if it was imported from csv.
        foreach($contentItem in $existingRoles){
          $newObject = new-object Object #create a custom object
          $newObject | add-member -membertype NoteProperty -Name "Code" -Value $contentItem["RoleCode"] -passthru | Out-Null
          $newObject | add-member -membertype NoteProperty -Name "Short Description" -Value $contentItem["RoleShortDescription"] -passthru | Out-Null
          $newObject | add-member -membertype NoteProperty -Name "Long Description" -Value $contentItem["RoleLongDescription"] -passthru | Out-Null
          [array]$newRoles += $newObject
        }
      }
        
      $existingOrgUnits = GetExistingOrgUnits $orgUnitList
      AddNewOrgUnits $orgUserList $existingOrgUnits $newOrgUnits		
      DeleteExistingOrgUnits $orgUserList $existingOrgUnits

      $existingUsers = GetExistingUsers $userList
      AddNewUsers  $userList $newUsers $newOrgUnits $existingUsers $newRoles
      DeleteOldUsers $userList $existingUsers

    }else{	
      $output = "'{0}' or '{1}' or '{2}' lists do not exist at web '{3}'" -f "Corporate Directory Users", "Corporate Directory Org Units", "Corporate Directory Roles", $webUrl
      $errorMsg = $output
      write-host $output
      $output | Add-Content $logFile		
    }
  }
  Catch{
    $output = $_.Exception.Message + "`r`n"
    $errorMsg = $output
    write-host $output -ForegroundColor Red
    $output | Add-Content $logFile
  }
  Finally{
    $web.Dispose()
  }
}
else{

  $output =  "Aurion User or Org Unit data file does not exist at path {0}\. Could not complete Corporate Directory Upload" -f $fileLocation
  $errorMsg = $output
  write-host $output -ForegroundColor Red
  $output | Add-Content $logFile
}

if (($errorMsg -eq "") -and ($profileBackupErrorCount -eq 0)){

  Move-Item -Path $userFile -Destination $userArchiveFile
  $output = "Aurion user extract file at location {0} moved to archive folder `r`n" -f $userFile
  write-host $output
  $output | Add-Content $logFile

  Move-Item -Path $orgUnitFile -Destination $orgUnitArchiveFile
  $output = "Aurion user extract file at location {0} moved to archive folder `r`n" -f $orgUnitFile
  write-host $output
  $output | Add-Content $logFile

  if (Test-Path ($fileLocation + ("\$roleFileName*")) -PathType Leaf) {
    Move-Item -Path $roleFile -Destination $roleArchiveFile
    $output = "Aurion user extract file at location {0} moved to archive folder `r`n" -f $orgUnitFile
    write-host $output
    $output | Add-Content $logFile    
  }

  $output = "Aurion user extract upload finished successfully at " + (Get-Date -Format "dd MMMM yyyy hh:mm tt")
  write-host $output -ForegroundColor Green
  $output | Add-Content $logFile

}else{
  $output = "Errors occured in the Aurion user extract upload. The current extracts will not be archived. `r`n"
  write-host $output -ForegroundColor Red
  $output | Add-Content $logFile

  if ($profileBackupErrorCount -ne 0) {
    $output = "Not all modified users with profile field data changes were able to be backed up to the users profile. Please check logs!"
    write-host $output -ForegroundColor Red
    $output | Add-Content $logFile
    $errorMsg = $errorMsg + "`r`n" + $output
  }

  $output = "Aurion user extract upload finished at " + (Get-Date -Format "dd MMMM yyyy hh:mm tt") + " with errors"
  write-host $output -ForegroundColor Red
  $output | Add-Content $logFile

  $subject = 'AEC Aurion user extract upload **Failure** ENV:{0}' -f $prefix

  if ($sendEmail) {
    Send-MailMessage -From 'AEC Corporate Directory Upload <aecsharepoint@aec.gov.au>' -To $notifyEmailAddress -Subject $subject -body $errorMsg -smtpServer $smtpServer -Priority High -Attachment $logFile
  }
}