<template>
  <div class="user-details">
    <b-modal hide-header v-model="showModal" ok-only modal-ok="Close" size="lg">
      <div v-html="helpContent.StaffProfileHelp"></div>
    </b-modal>
    <b-row v-if="displayUser.PreferredName && !loading">
      <b-col sm="12">
        <h5>Staff profile</h5>                     
        <div class="person-image-div float-left">
          <img v-if="displayUser.PictureURL" class="contactCardUserImage float-left" :src="displayUser.PictureURL" /> 
          <span v-else class="person-initials">{{displayUser.PreferredName | initial}}{{displayUser.LastName | initial}}</span>
        </div>
        <div class="float-left">
          <h4>{{displayUser.PreferredName | capitalise}} {{displayUser.LastName | capitalise}}</h4>
          <h5 v-if="displayUser.JobTitle.toLowerCase() === 'director'">{{displayUser.JobTitle}} - {{displayUser.Section | orgTitleFilter}} </h5>
          <h5 v-else>{{displayUser.JobTitle  | apsToUpper}}</h5>
        </div>
      </b-col>
    </b-row>
    <b-row v-if="displayUser.PreferredName" class="mt-3">
      <b-col class="col-md-6 col-xl-3 pr-0 pb-5">
        <h5 class="mt-3 mb-4">Contact information</h5>
        <!--<a @click="openModal" class="pl-1 editlink" v-if="currentUser.UserID === $route.params.userid" v-b-tooltip.hover title="Edit my details"><i class="fal fa-edit"></i> Edit</a>-->
        <b-row>
          <b-col>
            <div>
              <ul class="contact-details mb-1">
                <li v-if="displayUser.Extension || displayUser.WorkPhone"><i class="fas fa-phone fa-fw mr-2"></i><span v-if="displayUser.Extension">x{{displayUser.Extension}}<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                <span v-if="displayUser.WorkPhone">{{displayUser.WorkPhone | removeBrackets}}</span></li>
                <li v-if="displayUser.CellPhone"><i class="fas fa-mobile-alt fa-fw mr-2"></i>{{displayUser.CellPhone | removeBrackets}}</li>
                <!--<li><i class="fab fa-skype"></i><a :href="'sip:' + displayUser.Email">Chat</a></li>-->
                <li><i class="fas fa-comment-alt fa-fw mr-2"></i><a :href="`${teamsChatURL}${displayUser.Email}`" target="_blank">Chat</a></li>
                <li><i class="fas fa-envelope fa-fw mr-2"></i><span v-if="displayUser.Email"><a :href="'mailto:' + displayUser.Email" class="text-break">{{displayUser.Email}}</a></span>
                  <span v-else>"No email listed"</span>
                </li>
              </ul>
              <a @click="openModal" class="btn btn-outline-primary d-print-none" v-if="currentUser.UserID === $route.params.userid">
                <i class="fal fa-edit fa-fw"></i> Edit my details</a>     
            </div>
          </b-col>
        </b-row>
      </b-col>

      <b-col v-if="hasLocation || isCurrentUser || currentUserIsAdmin" class="col-md-6 col-xl-3 pr-0 pb-5">
        <h5 class="mt-3 mb-4">Where to find me</h5>
        <!---<a @click="editMyLocation" class="pl-1 editlink" v-if="currentUser.UserID === $route.params.userid" v-b-tooltip.hover title="Edit my location"><i class="fal fa-edit"></i> Edit</a>-->
        <b-row>
          <b-col>
            <div class="contactCardLocation">
              <ul class="mb-1">
                <li v-if="displayUser.State"><i class="fas fa-globe-asia fa-fw  mr-2"></i>{{displayUser.State}}</li>
                <li v-if="displayUser.LocationBuilding"><i class="fas fa-building fa-fw  mr-2"></i>{{displayUser.LocationBuilding}}</li>
                <li v-if="displayUser.LocationFloor"><i class="fas fa-layer-group fa-fw mr-2"></i>{{displayUser.LocationFloor}}</li>
                <li v-if="displayUser.LocationWorkstation"><i class="fas fa-laptop fa-fw mr-2"></i>{{displayUser.LocationWorkstation}}</li>
                <li v-if="displayUser.LocationX > 0 && displayUser.LocationY > 0"><i class="fas fa-map-marked-alt mr-2" fa-fw></i>
                  <router-link :to="'/location/' + displayUser.UserID"  class="link-bold">View on Map</router-link>
                </li>
                <!--<li v-if="isCurrentUser && !displayUser.LocationImage"><i class="fas fa-map-marker-alt"></i>
                  <router-link :to="'/location/' + displayUser.UserID"  class="link-bold">Set my location</router-link>
                </li>               
                <li v-if="isCurrentUser && displayUser.LocationImage && displayUser.LocationX === 0 && displayUser.LocationY === 0"><i class="fas fa-map-marker-alt"></i>
                  <router-link :to="'/location/' + displayUser.UserID"  class="link-bold">Set my location on map</router-link>
                </li>  -->
              </ul> 
              <a @click="editMyLocation" class="btn btn-outline-primary d-print-none" v-if="isCurrentUser || currentUserIsAdmin || currentUserIsSuperAdmin">
                <i class="fal fa-edit"></i> Edit location</a>     
            </div>      
          </b-col>
        </b-row> 
      </b-col>      

      <b-col class="col-md-6 col-xl-3">
        <h5 class="mt-3">{{displayUser.PreferredName}}'s team</h5>
        <b-row>
          <b-col class="contactCardLabel">
            <ul class="contact-details" v-if="!subordinatesLoading">
              <li>
                <span v-if="displayUser.Manager">
                  <router-link :to="'/user/' + manager.UserID"  class="link-bold">{{manager.PreferredName | capitalise}} {{manager.LastName | capitalise}}</router-link><br />Manager
                </span>
                <span v-else>N/A</span>
              </li>
            </ul> 
          </b-col> 
        </b-row>
        <b-row v-if="directReports.length">
          <b-col class="contactCardLabel">
            <ul class="contact-details" v-if="!subordinatesLoading">
              <li v-for="(item, index) in directReports" :key="index">
                <span><router-link :to="'/user/' + item.accountName"  class="link-bold">{{item.name}}</router-link></span><span> <br />{{item.jobTitle}}</span>
              </li>
            </ul> 
          </b-col> 
        </b-row>  
      </b-col>
      
      <!-- <b-col v-if="peers.length" cols="12" :class="[peers.length ? 'col-md-6 col-xl-3' : 'col-md-6 col-xl-4']"  class="">
        <h5 class="mt-3">{{displayUser.PreferredName}}'s peers</h5>
          <b-row>
            <b-col class="contactCardLabel">
              <ul class="contact-details" v-if="!peersLoading">
                <span v-if="!peers.length">N/A</span>
                <li v-for="(item, index) in peers" :key="index">
                  <span><router-link :to="'/user/' + item.accountName" class="link-bold">{{item.name }}</router-link></span><span><br />{{item.jobTitle}}</span>
                </li>
              </ul>  
          </b-col> 
        </b-row>
      </b-col> -->
      <b-col cols="12" class="col-md-6 col-xl-3">
        <h5 class="mt-3">Organisational structure</h5>             
        <b-row>
          <b-col>
            <ul class="contact-details org-list">
              <li  v-if="displayUser.Branch">
                <!-- <p class="label">Branch<br /> -->
                <span>
                  <router-link :to="branchLink(displayUser.BranchNumber)">{{displayUser.Branch | orgTitleFilter}}</router-link>
                </span>
              </li>
              <li class="ml-2 "  v-if="displayUser.Section">
                <!-- <p class="label">Section<br /> -->
                <span>
                  <i class="fal fa-chevron-left"></i><router-link :to="'/orgunit/' + displayUser.SectionNumber">{{displayUser.Section | orgTitleFilter}}</router-link>
                </span>
              </li>
              <li  class="ml-4"  v-if="displayUser.Team">
                <!-- <p class="label">Team<br /> -->
                <span>
                  <i class="fal fa-chevron-left"></i><router-link :to="'/orgunit/' + displayUser.TeamNumber">{{displayUser.Team | orgTitleFilter}}</router-link>
                </span>
              </li>
            </ul>
          </b-col>
        </b-row>
      </b-col>
      
    </b-row>
    <!-- User not found notification --> 
    <b-row v-if="!displayUser.PreferredName && allUsers.length">
      <b-col>
        <b-alert variant="danger" show>User {{$route.params.userid}} could not be found. <a @click="closeModal" href="#" >Return to previous screen</a></b-alert> 
      </b-col>
    </b-row>
    <!-- </b-modal> -->
  </div>
</template>
<script>
  import { sp, Web } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import inoe from 'isnullorempty';

  /* eslint-disable */
  export default {
    name: 'UserDetails',
    props:["userid"],
    data () {
      return {        
        loading: false,
        peersLoading: false,
        subordinatesLoading: false,
        displayUser: {},
        showModal: false,
      }
    },    
    async created(){
      const self = this;
      await self.init();    
    },
    methods:{ 
      ...mapActions([
        'initialise',
        'loadCurrentUser',
        'loadSelectedUser',
        'updateUser',
        'getTaxonomyTerms',
        'loadCurrentUserAdminStatus'
      ]),    
      async init(){
        let self = this;
        await self.initialise();
        // await this.loadCurrentUser();
        if (IsNullOrUndefined(self.$route.params.userid)){          
          self.gotoCurrentUser()
        }    

        this.loadSelectedUser(self.$route.params.userid);
      },
      clearUser(){
        let self = this;
        self.peers = [];
        self.currentUser = {};
      },
      emitBranch: function(branch, section){
        if (!branch && !section) return false;
        this.$emit('clickBranchOrSection', branch, section);
        this.showContactCard = !this.showContactCard;
      },
      cancelModal() {
        let self = this;
        self.displayUser = _.clone(self.selectedUser);
        self.showModal = false;
      },
      closeModal(){
        history.back();
      },
      editMyLocation() {
        let self = this;
        self.$router.push({ name: 'location', params: { userid: self.displayUser.UserID, editMode: true } });
      },
      gotoCurrentUser(){
        let self = this;
        if (self.currentUser.UserID) {
          self.$router.replace({ name: 'user', params: { userid: self.currentUser.UserID }});
        }
      },
      openModal(){
        let self = this;

        self.getTaxonomyTerms();
        this.showModal = true;
      },
      branchLink(orgNumber){
        if (orgNumber === 0){
          return '/executive/'
        }else{
          return '/orgunit/' + orgNumber
        }
      },
      save(){
        let self = this;

        if (self.locationChanged) {
          self.updateUser(self.displayUser);
          this.$bvToast.toast(`Your changes were saved`, {
              title: "Success",
              autoHideDelay: 3000,
              solid: true,
              variant: 'success'
            })        
        }
        else {
          self.cancelModal();
        }
        self.showModal = false;
      },
    },
    mounted(){
      document.getElementById('s4-workspace').scrollTop = 0;
    },
    watch:{
      selectedUser(){
        let self = this;
        self.displayUser = _.clone(self.selectedUser);
        self.loadCurrentUserAdminStatus();
      },
      '$route.params.userid': function (id) {
        this.init();
      },
      currentUser(){
        // console.log(this.currentUser);
      },
    },
    computed:{
      ...mapGetters([        
        'selectedUser',
        'peers',
        'directReports',
        'allUsers',
        'currentUser',
        'currentUserIsAdmin',
        'currentUserIsSuperAdmin',
        'helpContent',
        'Locations',
        'configItems',
        'teamsChatURL'
      ]),
      /*managerUserid(){
        let self = this;
        let fn = self.selectedUser.Manager.slice(0,1);
        let ln = self.selectedUser.Manager.split(" ")[1];
        let managerUserid = fn + ln;
        return managerUserid.toLowerCase();
      },*/
      manager(){
        // let manager = this.allUsers.filter(user => user.PreferredName + " " + user.LastName === this.selectedUser.Manager);
        let manager = this.allUsers.filter(user => user.UserID === this.selectedUser.ManagerId);
        return manager[0];
      },
      hasLocation() {
        let self = this;
        return !inoe.isNullOrEmpty(self.displayUser.LocationBuilding) || !inoe.isNullOrEmpty(self.displayUser.LocationFloor) || !inoe.isNullOrEmpty(self.displayUser.LocationWorkstation);
      },
      floors() {
        let self = this;
        let returnVal = [];

        const Buildings = self.Locations.filter(b => b.value === self.displayUser.LocationBuilding)
        if (Buildings.length > 0) {
          returnVal = Buildings[0].children;
        }

        return returnVal;
      },    
      isCurrentUser() {
        let self = this;
        return self.currentUser.UserID === self.$route.params.userid;
      },
      locationChanged() {
        let self = this;
        const buildingChanged = self.displayUser.LocationBuilding !== self.selectedUser.LocationBuilding;
        const floorChanged = self.displayUser.LocationFloor !== self.selectedUser.LocationFloor;
        const wsChanged = self.displayUser.LocationWorkstation !== self.selectedUser.LocationWorkstation;

        return buildingChanged || floorChanged || wsChanged;
      },
      modalOk_Text() {
        let self = this;
        return self.locationChanged ? 'Save' : 'Ok';
      },
      emailHREF() {
        let self = this;
        let returnVal

        // Example 'mailto:someone@yoursite.com?subject=Request Buidling to be added to Corporate Directory&body=Body-goes-here'
        if (self.configItems.EmailAddress && self.configItems.EmailAddBuildingSubject && self.configItems.EmailAddBuildingBodyText) {
          returnVal = `mailto:${self.configItems.EmailAddress}?subject=${self.configItems.EmailAddBuildingSubject}&body=${encodeURIComponent(self.configItems.EmailAddBuildingBodyText)}`
        }

        // console.log('emailHREF', self.configItems, returnVal)

        return returnVal;
      }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        return value.charAt(0).toUpperCase() + value.slice(1)
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>