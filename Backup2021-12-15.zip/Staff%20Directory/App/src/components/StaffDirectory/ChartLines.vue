<template>
  <svg class="chartLine container">    
    <line v-if="top"    class="line top"    x1="0"    y1="0"    x2="100%" y2="0"    />
    <line v-if="bottom" class="line bottom" x1="0"    y1="100%" x2="100%" y2="100%" />
    <line v-if="left"   class="line left"   x1="0"    y1="0"    x2="0"    y2="100%" />
    <line v-if="middle" class="line middle" x1="50%"  y1="0"    x2="50%"  y2="100%" />
    <line v-if="right"  class="line right"  x1="100%" y1="0"    x2="100%" y2="100%" />
  </svg>     
</template>
<script>
  // <svg height="15" width="100%" class="chartLine">
  //   <line x1="0" y1="100%" x2="100%" y2="100%" style="stroke:rgb(0,0,0);stroke-width:5" />
  //   <line x1="50%" y1="0" x2="50%" y2="100%" style="stroke:rgb(0,0,0);stroke-width:2" />
  // </svg>     

  /* eslint-disable */
  export default {
    name: 'ChartLines',
    props:{
      top: {
        type: Boolean,
        default: false
      },
      bottom: {
        type: Boolean,
        default: false
      },
      left: {
        type: Boolean,
        default: false
      },
      middle: {
        type: Boolean,
        default: false
      },
      right: {
        type: Boolean,
        default: false
      } 
    },
    components: {
    },
    data () {
      return {        
      }
    },    
    created(){
      const self = this;
      self.init();
    },

    methods:{   
      init() {

      }
    },
    watch:{
    },
    computed:{
    },
    filters: {
    }
  }
</script>