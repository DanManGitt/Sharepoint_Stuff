<template>
  <div id="userIconCircle">
    <b-tooltip target="UIC_profileLink" variant="dark" placement="right" container="userIconCircle">Profile</b-tooltip>
    <b-tooltip target="UIC_chatLink" variant="dark" placement="right" container="userIconCircle">Chat</b-tooltip>
    <b-tooltip v-if="user.Extension || user.WorkPhone" target="UIC_phoneLink" variant="dark"placement="right"  container="userIconCircle">
      <span class="text-nowrap" v-if="user.Extension">x{{user.Extension}}<br /></span>
      <span class="text-nowrap" v-if="user.WorkPhone">{{user.WorkPhone | removeBrackets}}</span></li>
    </b-tooltip>  
    <b-tooltip v-if="user.CellPhone" target="UIC_mobilePhoneLink" variant="dark" placement="right" container="userIconCircle">
      <span class="text-nowrap">{{user.CellPhone | removeBrackets}}</span>
    </b-tooltip>
    <b-tooltip v-if="user.Email" target="UIC_mailLink" variant="dark" placement="right" container="userIconCircle">Mail</b-tooltip>

    <transition name="bounce" appear>
      <a id="UIC_profileLink" class="pos d-print-none" href="#" @click="gotoProfile" ><i class="fas fa-user" ></i></a>
    </transition>
    <transition name="bounce" appear>
      <i id="UIC_chatLink" class="fas fa-comment-alt pos d-print-none" @click="openChat"></i>
    </transition>
    <transition name="bounce" appear>
      <i v-if="user.Extension || user.WorkPhone" id="UIC_phoneLink" class="fas fa-phone pos d-print-none"></i>
    </transition>
    <transition name="bounce" appear>
      <i v-if="user.CellPhone"  id="UIC_mobilePhoneLink" class="fas fa-mobile-alt pos d-print-none"></i>
    </transition>
    <transition name="bounce" appear>
      <a v-if="user.Email" id="UIC_mailLink" class="pos d-print-none" :href="'mailto:' + user.Email"  ><i class="fas fa-envelope" ></i></a>
    </transition>

    <!--<i class="fas fa-user pos"></i>
    <i class="fas fa-comment pos"></i>
    <i class="fas fa-building pos"></i>
    <i class="fas fa-phone pos"></i>
    <i class="fas fa-mobile-alt pos"></i>
    <i class="fas fa-envelope pos"></i>
    <i class="fas fa-user pos"></i>-->
  </div>
</template>
 <script>
  import { sp, Web } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import inoe from 'isnullorempty';

  /* eslint-disable */
  export default {
    name: 'UserIconsCirlce',
    props:{
      user: Object
    },
    data () {
      return {        

      }
    },    
    created(){
      const self = this;
    },

    methods:{    
      gotoProfile(){
        let self = this;

        // if (!self.editMode) {
        console.log('gotoProfile', self.user);
          self.$router.push({ name: 'user', params: { userid: self.user.UserID }});
        // } 
      },
      openChat(){
        let self = this;
        console.log('openChat', self.user);
        // <!--<li><i class="fas fa-comment-alt"></i><a :href="`${teamsChatURL}${user.Email}`" target="_blank">Chat</a></li>
        window.open(`${self.teamsChatURL}${self.user.Email}`);
      }
    },
    watch:{
    },
    computed:{...mapGetters([        
        'teamsChatURL'
      ]),
    },
    filters: {
    }
  }
</script>
