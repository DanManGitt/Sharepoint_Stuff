<template>
  <div class="user-summary-card-chart">
    <b-row v-if="isExecView===false" v-for="levels,index in orgChart.structure" :key="index" >
      <b-col sm="12" v-if="levels.length > 0 && index === 0">
        <h2 v-if="orgChart.titles[index]">{{orgChart.titles[index].displayTitle}}</h2>
        <div v-if="orgChart.titles[index]" class="levelDescription" v-html="getDescriptionContent(orgChart.titles[index].displayTitle)"></div>
      </b-col>
      <b-col sm="12" v-if="levels.length > 0 && index > 1">
        <h2 v-if="orgChart.titles[index-1].displayTitle !== orgChart.titles[index-2].displayTitle">{{orgChart.titles[index-1].displayTitle}}</h2> 
        <div v-if="orgChart.titles[index-1].displayTitle !== orgChart.titles[index-2].displayTitle" class="levelDescription" v-html="getDescriptionContent(orgChart.titles[index-1].displayTitle)"></div>
      </b-col>
      <b-col sm="4" v-if="hasSelection(index)" >
      </b-col>
      <b-col sm="4" v-if="hasSelection(index)">
        <b-row class="outer">
          <b-col class="inner" v-for="person in selectedPerson(levels,index)" :key="person.UserID" @click.stop="selectUserRoute(person,index)" > <!--, {'hasSelection': hasSelection(index)}-->
            <UserSummaryCardChart :id="person.UserID" :user="person" :class="[{selected: isSelected(person)},{ unselected: isUnselected(person,index)}, { 'd-print-none': isUnselected(person,index)}]" 
                                  :structureTitle="orgStruct(index)" :showPromoteToTop="index !== 0 && !isUnselected(person,index) && showPromoteToTop">
            </UserSummaryCardChart>
            <ChartLines v-if="isSelected(person) && hasStaff(index)" middle bottom />
          </b-col>
        </b-row>
      </b-col>
      <b-col :sm="4" class="text-right" v-if="hasSelection(index) && index === 0" >
          <!--<a class="btn d-print-none" :class="[showSelectionItems ? 'btn-aec-primary-alt' : 'btn-aec-primary']" @click="toggleShowSelectionItems">
          <span v-if="!showSelectionItems">Show Selection Items</span>
          <span v-else>Hide Selection Items</span>
        </a>-->
      </b-col>
      <b-col :sm="4"  v-if="hasSelection(index) && index > 0 && showSelectionItems" >
        <b-row class="outer d-print-none">
          <b-col class="inner" v-for="person in levels" :key="person.UserID" sm="4" @click.stop="selectUserRoute(person,index)" :class="[{ 'mx-auto' : index === 0}]" > <!--, {'hasSelection': hasSelection(index)}-->
            <UserSummaryCardChartSmall :id="person.UserID" :user="person" :class="[{selected: isSelected(person)},{ unselected: isUnselected(person,index)}, { 'd-print-none': isUnselected(person,index)}]" 
                                  :structureTitle="orgStruct(index)" :showPromoteToTop="index !== 0 && !isUnselected(person,index) && showPromoteToTop">
            </UserSummaryCardChartSmall>
          </b-col>
        </b-row>
      </b-col>
      <b-col :sm="12"  v-if="!hasSelection(index)">
        <b-row class="outer" v-if="index > 0">
          <b-col class="inner" v-for="person in levels" :key="person.UserID" sm="4" @click.stop="selectUserRoute(person,index)" :class="[{ 'mx-auto' : index === 0}]" > <!--, {'hasSelection': hasSelection(index)}-->
            <UserSummaryCardChart :id="person.UserID" :user="person" :class="[{selected: isSelected(person)},{ unselected: isUnselected(person,index)}, { 'd-print-none': isUnselected(person,index)}]" 
                                  :structureTitle="orgStruct(index)" :showPromoteToTop="index !== 0 && !isUnselected(person,index) && showPromoteToTop">
            </UserSummaryCardChart>
            <ChartLines v-if="isSelected(person) && hasStaff(index)" middle bottom />
          </b-col>
        </b-row>
      </b-col>
    </b-row>

    <b-row v-if="isExecView" v-for="levels,index in orgChart.structure" :key="index" >
      <b-col sm="12" v-if="levels.length > 0">
        <h2>{{orgChart.titles[index].displayTitle}}</h2>
        <div class="levelDescription" v-html="getDescriptionContent(orgChart.titles[index].displayTitle)"></div>
      </b-col>
      <b-col v-for="person in levels" :key="person.UserID" sm="4" :class="{ 'mx-auto' : levels.length === 1}">
        <UserSummaryCardChart :id="person.UserID" :user="person" :class="[{selected: isSelected(person)} ]"
                              :structureTitle="orgStruct(index)">
        </UserSummaryCardChart>
        <ChartLines v-if="isSelected(person) && hasStaff(index)" middle bottom />
      </b-col>
    </b-row>    

  </div>  
</template>
<script>
  import { sp, Web } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import ChartLines from './ChartLines.vue';
  import UserSummaryCardChart from './UserSummaryCardChart';
  import UserSummaryCardChartSmall from './UserSummaryCardChartSmall';

  /* eslint-disable */
  export default {
    name: 'OrgChart',
    props:{
      exectView: {
        type: Boolean, 
        default: false
      },
      useRouting: {
        type: Boolean, 
        default: true
      },
      showPromoteToTop: {
        type: Boolean, 
        default: true
      }
    },
    components: {
      "ChartLines": ChartLines,
      "UserSummaryCardChart": UserSummaryCardChart,
      "UserSummaryCardChartSmall": UserSummaryCardChartSmall
    },
    data () {
      return {        
        // queryFilter: ''
        isExecView: false,
        scrollContainerId: 's4-workspace',
        showSelectionItems: false
      }
    },    
    async created(){
      const self = this;
      // console.log('orgChart created');
      // await this.loadAllUsers();
      await self.init();
    },

    methods:{   
      ...mapActions([
        // 'setSelectedOrgUnit'
        'initialise',
        'getManagementHierarchy',
        'getUserById',
        'loadAllUsers',
        'loadOrgChart',
        'loadOrgChartLevel',
        'OrgChartUserSelect',
        'loadOrgChartExecutive',
        'loadSelectedUser'
      ]),
      async init(){
        const self = this;
        await self.initialise();
        // console.log('orgChart init', this.$route.params.level1, this.$route.params.lastSelected);
        self.isExecView = self.$route.params.level1 === 'exec' || self.exectView;

        // console.log('isExecView', self.isExecView);
        if (self.isExecView) {
          await self.loadOrgChartExecutive();
        } else {
          await self.loadOrgUsingRouteParams();          
        } 

        self.selectTopPersonInStructure();       
      },
      async loadOrgUsingRouteParams() {
        const self = this;
        await self.loadOrgChart(self.$route.params.level1);

        if (!IsNullOrUndefined(self.$route.params.lastSelected)) {
          let userManagement = await self.getManagementHierarchy(self.$route.params.lastSelected);
          const selectedUser = await self.getUserById(self.$route.params.lastSelected);
          const findtops = userManagement.filter(p => p.UserID === self.$route.params.level1);
          if (findtops.length > 0)             
          {
            const topPerson = findtops[0];
            const index = userManagement.indexOf(topPerson);
            userManagement.length = index+1; //remove higher manaagement than top person.
            userManagement = _.reverse(userManagement);
            
            for(let index = 0; index < userManagement.length; index++) { 
            // userManagement.forEach(async (manager,index) => {
              const manager = userManagement[index];
              await self.selectUser(manager,index);
            }
            await self.selectUser(selectedUser,userManagement.length);
          }
          else {
            //top person is not part of selected users Hierarchy so do nothing
          }
        }
      },
      async selectTopPersonInStructure(){
        const self = this;

        if (self.orgChart.structure.length > 0) {
          const topLevelPeople = self.orgChart.structure[0];
          if (topLevelPeople.length > 0) {
            const topPerson = topLevelPeople[0];
            await self.loadSelectedUser(topPerson.UserID);
          }
        }
      },
      getDescriptionContent(title){
        const self = this;

        const titleNoSpaces = title.replace(/\s/g, '');
        return self.helpContent[`${titleNoSpaces}Desc`];
      },
      hasStaff(level){
        const self = this;
        const _hasStaff = self.orgChart.structure[level+1] ? self.orgChart.structure[level+1].length > 0 : false;
        return _hasStaff;
      },
      hasSelection(level){
        const self = this;

        const levelHasSelection = self.orgChart.selected.length > level;
        return levelHasSelection;
      },
      isSelected(person){
        const self = this;
        return self.orgChart.selected.includes(person.UserID);
      },
      isUnselected(person,level){
        const self = this;
        const levelHasSelection = self.orgChart.selected.length > level;
        return !self.orgChart.selected.includes(person.UserID) && levelHasSelection;
      },
      selectedPerson(people,index){
        const self = this;
        let returnVal = [];

        if (self.hasSelection(index)){
          returnVal = people.filter(p => p.UserID === self.orgChart.selected[index] );
        } 

        return returnVal;
      },
      async selectUser(person,level) {
        let payload = {
          person: person,
          level: level
        }
        await this.OrgChartUserSelect(payload);
      },
      selectUserRoute(person,level) {
        const self = this;

        // console.log('current route', self.useRouting, self.$route);
        if (self.useRouting) {
          if (self.$route.params.lastSelected !== person.UserID) {
            self.$router.push({ name: 'orgchart', params: { level1: self.orgChart.structure[0][0].UserID, lastSelected: person.UserID  } });
            // self.$router.push({ name: self.$route.name, params: { level1: self.orgChart.structure[0][0].UserID, lastSelected: person.UserID  } });
          }
        }
        else {
          self.selectUser(person,level);
        }

        self.$scrollTo(`#${person.UserID}`, 1000, { container: `#${self.scrollContainerId}`, easing: 'ease', cancelable: false });
      },
      toggleShowSelectionItems(){
        let self = this;
        self.showSelectionItems = !self.showSelectionItems;
      },
      orgStruct(level) {
        let self = this;

        let ReturnVal = self.orgChart.titles[level]; //Default return the current levels Titles.
        if (level > 0) {
          ReturnVal = self.orgChart.titles[level-1];
        }

        return ReturnVal;
      }
    },
    watch:{
      async $route(to, from) {
        let self = this;
        await self.init();
      },  
    },
    computed:{
      ...mapGetters([
        'displayMode',
        'orgChart',
        'executiveStructure',
        'helpContent'
      ])
    },
    filters: {
    }
  }
</script>