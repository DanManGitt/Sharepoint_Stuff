<template>
  <div class="staff-directory">
    <b-modal hide-header v-model="showModal" ok-only modal-ok="Close" size="lg">
      <div v-html="helpContent.UserSearchHelp"></div>
    </b-modal>
    <b-row>
      <b-col md="3" xl="2" class="d-print-none left-nav">
        <OrgNavigation v-if="!isWidget" title="National Office" :nationalOffice="true" />
        <OrgNavigation v-if="!isWidget" title="State Offices" :nationalOffice="false" />
        <!--<BuildingNavigation v-if="!isWidget" title="Office Location" />-->
      </b-col>
      <b-col md='9' xl="10" class="mb-4 col-print-12 pl-4">
        <OrgBreadcrumb />
        <div v-html="helpContent.infoMessage"></div>
        <transition v-if="initialised" name="fade" mode="out-in">    
          <router-view :key="$route.params.orgid"></router-view>
        </transition>
        <div class="d-print-none pt-4"  v-if="$router.currentRoute.name === 'default' && initialised">
          <b-tabs content-class="mt-3 mb-4" v-model="tabIndex">
            <b-tab title="People Search">
              <b-row  class="mb-4">
                <b-col md="6">
                  <b-input-group class="mt-3">
                    <b-form-input v-model="searchTerms" placeholder="Search by first name, last name or job title" v-on:keyup.enter="searchUsers"></b-form-input>
                  </b-input-group>
                </b-col>
                <b-col md="3">
                  <b-input-group class="mt-3 text-right">
                    <a class="btn btn-aec-secondary" @click="searchUsers"><i class="fal fa-search"></i></a>
                    <a class="btn btn-aec-secondary ml-2" @click="reset"><i class="fal fa-times"></i></a>
                  </b-input-group>
                </b-col>
              </b-row>
              <b-row v-if="$router.currentRoute.name === 'default' && displayMode === 0">
                <b-col v-for="(item, index) in userResults" :key="index" sm="6" lg="4" xl="3" class="d-flex align-content-stretch flex-wrap ">
                  <UserSummary :user="item"></UserSummary>
                </b-col>
              </b-row>
              <b-row v-if="!userResults.length">
                <b-col>
                  <!-- <b-alert show variant="secondary" v-if="!hasSearched">{{helpContent.UserSearchHelp1}}</b-alert> -->
                  <b-alert show variant="secondary" v-if="!userResults.length && hasSearchedUsers" v-html="helpContent.UserSearchHelp"></b-alert>
                </b-col>
              </b-row>
              <UserSummaryTable :users="userResults"  v-if="$router.currentRoute.name === 'default' && displayMode === 1 && userResults.length"></UserSummaryTable>
            </b-tab>
            <b-tab title="Organisation Unit Search" >
              <b-row class="mb-4">
                <b-col md="4">
                  <b-input-group  class="mt-3">
                    <b-form-input v-model="queryStrings.orgUnitTitle" placeholder="Org unit title" v-on:keyup.enter="searchOrgUnits"></b-form-input>
                  </b-input-group>
                </b-col>
                <b-col md="4">
                  <b-input-group  class="mt-3">
                    <b-form-input v-model="queryStrings.orgUnitDescription" placeholder="Org unit description" v-on:keyup.enter="searchOrgUnits"></b-form-input>
                  </b-input-group>
                </b-col>
                <b-col md="4">
                  <b-input-group class="mt-3 text-right">
                    <a class="btn btn-aec-secondary" @click="searchOrgUnits"><i class="fal fa-search"></i></a>
                    <a class="btn btn-aec-secondary ml-2" @click="reset"><i class="fal fa-times"></i></a>
                  </b-input-group>
                </b-col>                
              </b-row>
              <div v-if="$router.currentRoute.name === 'default'">
                <div v-for="(item, index) in orgUnitResults" :key="index" class="d-inline-block mr-4 mb-4">
                  <OrgUnitSummary :orgunit="item"></OrgUnitSummary>
                </div>
              </div>
              <b-row v-if="!orgUnitResults.length && hasSearchedOrgs">
                <b-col>
                  <b-alert show variant="secondary" v-html="helpContent.OrgUnitSearchHelp"></b-alert>
                </b-col>
              </b-row>
            </b-tab>
          </b-tabs>
        </div>
      </b-col>
    </b-row>
  </div>
</template>
<script>

  import UserDetails from './UserDetails.vue';
  import UserLocation from './Userlocation.vue';
  import Building from './Building.vue';
  import BuildingNav from './BuildingNav.vue';
  import OrgChart from './OrgChart.vue';
  import OrgUnit from './OrgUnit.vue';
  import OrgNav from './OrgNav.vue';
  import OrgBreadcrumb from './OrgBreadcrumb.vue';
  import OrgUnitSummary from './OrgUnitSummary';
  import Favourites from './Favourites.vue';
  import Executive from './Executive.vue';
  import LeadershipTeam from './LeadershipTeam';
  import UserSummary from './UserSummary.vue';
  import UserSummaryTable from './UserSummaryTable.vue';
  import { sp, Web } from "@pnp/sp";
  import VueRouter from 'vue-router';
  import { mapActions } from 'vuex';
  import { mapGetters } from 'vuex';

   /* eslint-disable */
  export default {
    name: 'StaffDirectory',
    props:{
      isWidget: Boolean,
      showFavourites: Boolean,
      userListSitePath: String,
    },
    components:{
      "UserDetails": UserDetails,
      "BuildingNavigation": BuildingNav,
      "OrgNavigation": OrgNav,
      "OrgBreadcrumb": OrgBreadcrumb,
      "OrgUnitSummary": OrgUnitSummary,
      "UserSummary": UserSummary,
      "UserSummaryTable": UserSummaryTable,
      "Favourites": Favourites,
      "Executive": Executive,
      "OrgChart": OrgChart,
      "LeadershipTeam": LeadershipTeam
    },
    router: new VueRouter({
      routes: [
        {
          name: 'orgunit',
          path: '/orgunit/:orgid',
          component: OrgUnit,
          props: true
        },
        {
          name: 'user',
          path: '/user/:userid?',
          component: UserDetails,
          props: true
        },
        {
          name: 'location',
          path: '/location/:userid?/:editMode?',
          component: UserLocation,
          props: true
        },
        {
          name: 'default',
          path: '/',
          props: true
        },
        {
          name: 'favourites',
          path: '/favs',
          props: true,
          component: Favourites
        },
        {
          name: 'executive',
          path: '/executive',
          props: true,
          component: Executive
        },
        {
          name: 'leadership',
          path: '/leadership',
          props: true,
          component: LeadershipTeam
        },
        {
          name: 'orgchart',
          path: '/Orgchart/:level1?/:lastSelected?',
          props: true,
          component: OrgChart
        },
        {
          name: 'building',
          path: '/building/:state?/:building?/:floor?',
          props: true,
          component: Building
        }
      ],
      scrollBehavior (to, from, savedPosition) {
        if (to.hash) {
          return {
            selector: to.hash
            // , offset: { x: 0, y: 10 }
          }
        }
      }
    }),
    data () {
      return {
        queryFilter: '',
        paginate: ['items'],
        pageSize: 50,
        pageIndex: 1,
        query:'',
        total: 0,
        firstLoad: true,
        filteredUsers: [],
        queryStrings:{
          firstName: '',
          lastName: '',
          jobTitle: '',
          orgUnitTitle: '',
          orgUnitDescription: ''
        },
        userResults: [],
        orgUnitResults: [],
        searchTerms: '',
        hasSearchedUsers: false,
        hasSearchedOrgs: false,
        showModal: false,
        tabIndex: 0
      }
    },
    async created() {
      $('html').bind('keypress', function(e) {
        if (e.keyCode == 13) {
          return false
        }
      });
      await this.init();
    },
    methods: {
      async init(){
        const self = this;
        await self.initialise();
        await this.loadUsers();
        
        await this.loadOrgUnits();
      },
      async loadUsers(){
        //Check if we are displaying a selected user first, if not we load all users
        if(this.$route.params.userid){
          await this.loadAllUsers(this.$route.params.userid);
        }
        else{
          await this.loadAllUsers();
        }
      }, 
      async loadOrgUnits(){
        //Check if we are displaying a sleceted org unit, if not we load all all org units
        if(this.$route.params.orgid){
          await this.loadAllOrgUnits(this.$route.params.orgid);
          //await this.loadCurrentUserAdminStatus();          
        }
        else{
          await this.loadAllOrgUnits();
          //if not displaying a selected org unit, also call the displayusers.      
          if(this.$route.query.k){
            this.searchTerms = this.$route.query.k;
            this.searchUsers();
          }
          else{  
            await this.loadSearchQuery();
            //await this.loadDisplayUsers();
          }    
        } 
      },
      ...mapActions([
        'initialise',
        'loadAllUsers',
        'loadCurrentUser',
        'loadAllOrgUnits',
        'loadFavourites',
        'setSelectedOrgUnit',
        'setSelectedOrgUnitDetails',
        'loadSelectedUser',
        'loadDisplayUsers',
        'loadSearchQuery',
        'loadHelpContent',
        'loadDisplayMode',
        'loadCurrentUserAdminStatus',
        'loadSpecialFiltersSettings',
        'loadConfigurableContent'
      ]),
      routeToHome(){
        const self = this;
        self.showStaffCard = false;
        this.$router.push({
          name: 'default'
        });

      },
      async searchUsers(){
        let self = this;
        if(this.searchTerms !== '' && this.searchTerms.length > 2){
          self.userResults = this.allUsers.filter(user => {
            //let match = false;
            let fullName1 = user.PreferredName + " " + user.LastName;
            let fullName2 = user.FirstName + " " + user.LastName;
            if(user.FirstName.toLowerCase().indexOf(self.searchTerms.toLowerCase()) !== -1 || user.PreferredName.toLowerCase().indexOf(self.searchTerms.toLowerCase()) !== -1 || user.LastName.toLowerCase().indexOf(self.searchTerms.toLowerCase()) !== -1 || user.JobTitle.toLowerCase().indexOf(self.searchTerms.toLowerCase()) !== -1 || fullName1.toLowerCase().indexOf(self.searchTerms.toLowerCase()) !== -1  || fullName2.toLowerCase().indexOf(self.searchTerms.toLowerCase()) !== -1 ){
              return user;
            }
            this.hasSearchedUsers = true;
            
          })
        }
        
      },
      async searchOrgUnits(){
        this.loadSearchQuery(this.queryStrings);
      },
      reset(){
        this.queryStrings = {
          firstName: '',
          lastName: '',
          jobTitle: '',
          orgUnitTitle: '',
          orgUnitDescription: ''
        }
        this.searchTerms = '';
        this.hasSearchedUsers = false;
        this.hasSearchedOrgs = false;
        this.orgUnitResults = [];
        this.userResults = [];
      },
      searchOrgUnits(){
        let self = this;
        this.orgUnitResults = this.allOrgUnits.filter(unit => {
          let match = false;
          let orgUnitTitle = self.queryStrings.orgUnitTitle.toLowerCase();
          let orgUnitTitleMatch = false;
          let orgUnitDescription = self.queryStrings.orgUnitDescription.toLowerCase();
          let orgUnitDescriptionMatch = false;
          this.hasSearchedOrgs = true;
          if(orgUnitTitle !== ''){
            if(unit.Title.toLowerCase().indexOf(orgUnitTitle) !== -1){
              orgUnitTitleMatch = true;
            }
          }
          if(orgUnitDescription !== '' && !IsNullOrUndefined(unit.UnitDescription)){
            if(unit.UnitDescription.toLowerCase().indexOf(orgUnitDescription) !== -1){
              orgUnitDescriptionMatch = true;
            }
          }
          if(orgUnitTitle !== '' && orgUnitDescription !== ''){
            if(orgUnitTitleMatch && orgUnitDescriptionMatch) return unit;
          }
          else if(orgUnitTitle !== '' && orgUnitDescription === ''){
            if(orgUnitTitleMatch) return unit;
          }
          else if(orgUnitTitle === '' && orgUnitDescription !== ''){
            if(orgUnitDescriptionMatch) return unit;
          }
          
        })
      }
    },

    watch: {
      //Respond to route changes. 
      async $route (to, from){
        //Default view is the landing page view
        if (to.name === 'default') {
          await this.init();
          await this.setSelectedOrgUnit();
          await this.setSelectedOrgUnitDetails();
          await this.loadSelectedUser();          
        }
        //Org Unit view
        else if(to.name === 'orgunit'){
          if(this.$route.params.orgid){
            await this.setSelectedOrgUnit(this.$route.params.orgid);
            await this.setSelectedOrgUnitDetails(this.$route.params.orgid);
            // this.loadCurrentUserAdminStatus();
          }
          else{
            await this.setSelectedOrgUnit();
            await this.setSelectedOrgUnitDetails();
          }
        }
        //User view
        else if(to.name === 'user'){
          await this.setSelectedOrgUnit();         
          await this.setSelectedOrgUnitDetails(); 
        }
        if(to.name === 'location'){
          await this.setSelectedOrgUnit();       
          await this.setSelectedOrgUnitDetails();   
        }

        this.loadCurrentUserAdminStatus();
      },
      displayUsers(){
        this.page = 1;
        var page = this.pageIndex * this.pageSize;
        this.filteredUsers = this.displayUsers.slice(0, page);
      },
      searchStrings(){
        
      }
    },

    computed: {
      ...mapGetters([
        'initialised',
        'allUsers',
        'allOrgUnits',
        'currentUser',
        'quickContacts',
        'searchQuery',
        'displayUsers',
        'displayMode',
        'loading',
        'searchStrings',
        'helpContent'
      ]),
      noSearchTerms(){
        for (var key in this.queryStrings) {
        if (this.queryStrings[key] !== null && this.queryStrings[key] != "")
            return false;
        }
        return true;
      }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString()
        return value.charAt(0).toUpperCase() + value.slice(1)
      }
    }
  }
</script>
