<template>
  <div class="building">
    <h2 class="branded">Building view</h2>
    <!--<div class="sticky d-print-none" v-if="isCurrentUser || currentUserIsAdmin">
      <div class="float-sm-right pt-1 bg-white">          
        <a class="btn" :class="[editMode ? 'btn-aec-primary-alt' : 'btn-aec-primary']" @click="toggleEditMode">
          <span v-if="!editMode"><i class="fal fa-edit"></i> Edit</span>
          <span v-else><i class="fal fa-check"></i> Save</span>
        </a>
        <a class="btn btn-outline-primary" @click="cancelChanges()" v-if="editMode">
          <span ><i class="fal fa-times"></i> Cancel</span>
        </a>
      </div> 
    </div>-->      
    <b-row>
      <b-col sm="8" md="8" >
        <b-form-group label-align-sm="right" label-cols-sm="2"  id="state-group" label="State:" label-for="state" class="mb-0">
          <b-form-select id="state" v-model="LocationState" :options="Locations" size="sm" @change="stateChanged"></b-form-select>
        </b-form-group>      
        <b-form-group label-align-sm="right" label-cols-sm="2" id="building-group" label="Building:" label-for="building" class="mb-0">
          <b-input-group>
              <b-form-select id="building" v-model="LocationBuilding" :options="buildings" size="sm" @change="buildingChanged"></b-form-select>
              <b-input-group-append>
                <a v-if="emailHREF" :href="emailHREF" class="btn btn-aec-primary d-print-none" v-b-tooltip.hover title="Building not there? Email us"><i class="fas fa-envelope-square"></i></a>  
              </b-input-group-append>
            </b-input-group>
        </b-form-group>
        <b-form-group label-align-sm="right" label-cols-sm="2"  v-if="floors.length > 0" id="floor-group" label="Floor:" label-for="floor" class="mb-0">
          <b-form-select id="floor" v-model="LocationFloor" :options="floors" size="sm" @change="floorChanged"></b-form-select>
        </b-form-group>
        <!--<b-form-group label-align-sm="right" label-cols-sm="2" id="ws-group" label="Workstation:" label-for="ws" class="mb-0">
          <b-form-input id="ws" v-model="LocationWorkstation" type="text"></b-form-input>
        </b-form-group>-->
      </b-col>

      <!--<b-col v-if="!editMode" sm="8" md="8" >
        <b-form-group label-align-sm="right" label-cols-lg="2" label-size="sm" id="state-group" label="State:" label-for="state" class="mb-0">
          <div class="pt-1">{{displayUser.State}}</div>
        </b-form-group>      
        <b-form-group label-align-sm="right" label-cols-lg="2" label-size="sm" id="building-group" label="Building:" label-for="building" class="mb-0">
          <div class="pt-1">{{displayUser.LocationBuilding}}</div>
        </b-form-group>
        <b-form-group label-align-sm="right" label-cols-lg="2" label-size="sm" v-if="displayUser.LocationFloor" id="floor-group" label="Floor:" label-for="floor" class="mb-0">
          <div class="pt-1">{{displayUser.LocationFloor}}</div>
        </b-form-group>
        <b-form-group label-align-sm="right" label-cols-lg="2" label-size="sm" id="ws-group" label="Workstation:" label-for="ws" class="mb-0">
          <div class="pt-1">{{displayUser.LocationWorkstation}}</div>
        </b-form-group>     
      </b-col> -->    
    </b-row>

    <!--<b-row v-if="!loading" class="mt-3">
      <b-col sm="12">
        <h5 class="mb-1 d-inline">Location Map </h5><span v-if="mapSrc && editMode" class="d-print-none">(Click in map to set your location)</span>
        <div class="mt-3">

          <div v-if="displayUser.LocationX > 0 && displayUser.LocationY > 0" :style="personStyle(displayUser)" class="pin">
            <div class="person-image-div selected" :id="displayUser.UserID" :title="personName(displayUser)" >
              <img v-if="displayUser.PictureURL" class="" @dblclick="gotoProfile(displayUser)" @click="selectUser($event,displayUser)" :src="displayUser.PictureURL" /> 
              <span v-else class="person-initials" @dblclick="gotoProfile(displayUser)" @click="selectUser($event,displayUser)">{{displayUser.PreferredName | initial}}{{displayUser.LastName | initial}}</span>
            </div>
            <b-tooltip :target="displayUser.UserID" variant="warning" show>{{personName(displayUser)}}</b-tooltip>
            <div class="printName">{{displayUser.PreferredName}} {{displayUser.LastName}}</div>
          </div>

          <div  v-for="person in peopleInSameLocation" :key="person.UserID" 
                :style="personStyle(person)" 
                class="pin"
                >
            <div v-if="showUser(person)" class="person-image-div" :class="{selected : person.UserID ===  displayUser.UserID}" v-b-tooltip.hover :title="personName(person)">
              <img v-if="person.PictureURL" class="" @dblclick="gotoProfile(person)" @click="selectUser($event,person)" :src="person.PictureURL" /> 
              <span v-else class="person-initials" @dblclick="gotoProfile(person)" @click="selectUser($event,person)">{{person.PreferredName | initial}}{{person.LastName | initial}}</span>              
            </div>
            <div v-if="showUser(person)"  class="printName">{{person.PreferredName}} {{person.LastName}}</div>
          </div>
        </div>
        <b-img   v-if="mapSrc" class="locationImage" :src="mapSrc" alt="Location Map" @click="imageClicked"></b-img>
        <b-alert v-if="!mapSrc" variant="success" show>Map not available.</b-alert> 
      </b-col>
    </b-row>--> 

    <!-- User not found notification --> 
    <!--<b-row v-if="!displayUser.PreferredName && allUsers.length">
      <b-col>
        <b-alert variant="danger" show>User {{$route.params.userid}} could not be found. <a @click="closeModal" href="#" >Return to previous screen</a></b-alert> 
      </b-col>
    </b-row>-->
  </div>
</template>
<script>
  import { sp, Web } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import inoe from 'isnullorempty';
  // import _ from 'loadash';

  /* eslint-disable */
  export default {
    name: 'Building',
    props:["userid"],
    data () {
      return {        
        loading: true,
        // editMode: false,
        // displayUser: {},
        // imageLibrary: '../PublishingImages/',
        // userDetatilsChanged: false
        LocationState: '',
        LocationBuilding: '',
        LocationFloor: '',
        LocationImage: ''
      }
    },    
    async created(){
      const self = this;
      await self.init();    
    },
    methods:{ 
      ...mapActions([
        'initialise',
        'loadCurrentUser',
        'loadSelectedUser',
        'updateUser',
        'getTaxonomyTerms',
        'loadCurrentUserAdminStatus'
      ]),    
      init: async function(){
        // _.debounce() {
        let self = this;
        self.loading = true;
        await self.initialise();
        // await self.getTaxonomyTerms();
        // await this.loadCurrentUser();

        console.log('initialising Building');

        if (self.$route.params.state) {
          self.LocationState = self.$route.params.state;
        }

        if (self.$route.params.building) {
          self.LocationBuilding = self.$route.params.building;
        }

        if (self.$route.params.floor) {
          self.LocationFloor = self.$route.params.floor;
        }        

        self.LocationImage = self.imageFilename();
        // await self.loadSelectedUser(self.$route.params.userid);  
        // await self.loadCurrentUserAdminStatus();

        // if (self.$route.params.editMode && (self.isCurrentUser || self.currentUserIsAdmin)){
        //   self.editMode = JSON.parse(self.$route.params.editMode);
        // }

        // if (IsNullOrUndefined(self.$route.params.userid)){
        //   self.gotoCurrentUser()
        // } 

        self.loading = false;          
      },
      // async toggleEditMode(){
      //   let self = this;
        
      //   // console.log('toggleEditMode locationChanged', self.locationChanged, self.isCurrentUser);
      //   if (this.editMode){
      //     await self.save();
      //   }
      //   this.editMode = !this.editMode;
      // },
      // imageClicked(event){
      //   let self = this;

      //   // console.log('imageClicked', event.offsetX, event.offsetY);
        
      //   if (self.editMode) {
      //     self.displayUser.LocationX = event.offsetX;
      //     self.displayUser.LocationY = event.offsetY;

      //     self.userDetatilsChanged = true;
      //   }
      // },
      stateChanged() {
        let self = this;
        self.LocationBuilding = '';
        self.buildingChanged();
      },
      buildingChanged() {
        let self = this;
        self.LocationFloor = '';
        self.floorChanged();
      },
      floorChanged() {
        let self = this;
        self.LocationImage = self.imageFilename();
        // self.clearXY();

        // self.userDetatilsChanged = true;
      },
      // clearXY() {
      //   let self = this;
      //   self.displayUser.LocationX = 0;
      //   self.displayUser.LocationY = 0;
      // },
      closeModal(){
        history.back();
      },
      // cancelChanges() {
      //   let self = this;        
      //   self.displayUser = _.clone(self.selectedUser);
      //   self.userDetatilsChanged = false;
      //   this.editMode = false;
      // },
      // async save(){
      //   let self = this;

      //   let response = await self.updateUser(self.displayUser);
      //   self.userDetatilsChanged = false;
      //   await self.loadSelectedUser(self.displayUser.UserID);  //reselect user
      //   this.$bvToast.toast(`Your changes were saved`, {
      //       title: "Success",
      //       autoHideDelay: 3000,
      //       solid: true,
      //       variant: 'success'
      //     })
      // },
      imageFilename() {
        let self = this;
        let buildingImageSrc = '';
        let floorImageSrc = '';

        const _states = self.Locations.filter(b => b.value === self.LocationState)
        if (_states.length > 0) {
          const _buildings = _states[0].children.filter(b => b.value === self.LocationBuilding);
          if (_buildings.length > 0) {
            buildingImageSrc = _buildings[0].LocalCustomProperties.map;            
            const _floors = _buildings[0].children.filter(f => f.value === self.LocationFloor);
            if (_floors.length > 0) {
              floorImageSrc = _floors[0].LocalCustomProperties.map;
            }
          }
        }

        const imageSrc = floorImageSrc || buildingImageSrc || '';
        return imageSrc;
      },
      personStyle(person) {
        let self = this;
        let style = {};
        const pinLocationAdjustY = 10;
        const pinLocationAdjustX = 15;

        if (person.LocationX !== 0 && person.LocationY !== 0) {
          style["top"] = `${person.LocationY+pinLocationAdjustY}px`;
          style["left"] = `${person.LocationX+pinLocationAdjustX}px`;
        }

        return style;
      },
      personName(person) {
        let self = this;

        return `${person.PreferredName} ${person.LastName}`;
      },
      // gotoCurrentUser(){
      //   let self = this;
      //   if (self.currentUser.UserID) {
      //     self.$router.replace({ name: 'location', params: { userid: self.currentUser.UserID }});
      //   }        
      // },
      gotoProfile(person){
        let self = this;

        if (!self.editMode) {
          self.$router.push({ name: 'user', params: { userid: person.UserID }});
        }
      },
      async selectUser(event,person){
        let self = this;

        const iconWidth = 35;
        const iconHeight = 35;

        if (self.editMode && self.$route.params.userid === person.UserID) {
          self.displayUser.LocationX = Math.round(self.displayUser.LocationX + (event.offsetX - iconWidth/2));
          self.displayUser.LocationY = Math.round(self.displayUser.LocationY + (event.offsetY - iconHeight/2));

          self.userDetatilsChanged = true;
        }

        if (self.editMode && self.userDetatilsChanged && self.$route.params.userid !== person.UserID) {
          await self.save();
        }

        if (self.$route.params.userid !== person.UserID) {
          self.$router.push({ name: 'location', params: { userid: person.UserID, editMode: self.editMode }});
        }
      },
      showUser(person){
        let self = this;
        let returnVal = true;

        if (self.editMode) { //if we are in Edit Mode then only show people in same division
          returnVal = self.currentUser.Div === person.Div;
        }

        return returnVal;
      },
    },
    mounted(){
      document.getElementById('s4-workspace').scrollTop = 0;
    },
    watch:{
      selectedUser(){
        let self = this;
        self.displayUser = _.clone(self.selectedUser);
      },
      '$route.params.state': function () {
        console.log('state param changed');
        this.init();        
      },
      '$route.params.building': function () {
        console.log('building param changed');
        this.init();
      },
      '$route.params.floor': function () {
        console.log('floor param changed');
        this.init();
      },      
      currentUser(){
        // console.log(this.currentUser);
      },
    },
    computed:{
      ...mapGetters([
        'selectedUser',
        'allUsers',
        'currentUser',
        'currentUserIsAdmin',
        'Locations',
        'configItems',
        'imageLibrary'
      ]),
      pinStyle() {
        let self = this;
        let style = {};
        const pinLocationAdjustY = 20;
        const pinLocationAdjustX = 5;

        if (self.displayUser.LocationX !== 0 && self.displayUser.LocationY !== 0) {
          style["top"] = `${self.displayUser.LocationY+pinLocationAdjustY}px`;
          style["left"] = `${self.displayUser.LocationX+pinLocationAdjustX}px`;
        }

        return style;
      },
      buildings() {
        let self = this;
        let returnVal = [];

        const States = self.Locations.filter(b => b.value === self.LocationState)
        if (States.length > 0) {
          returnVal = States[0].children;
        }

        return returnVal;
      },      
      floors() {
        let self = this;
        let returnVal = [];

        const Buildings = self.buildings.filter(b => b.value === self.LocationBuilding)
        if (Buildings.length > 0) {
          returnVal = Buildings[0].children;
        }

        return returnVal;
      },      
      mapSrc() {
        let self = this;
        return self.LocationImage ? `${self.imageLibrary}${self.LocationImage}` : '';
      },
      // isCurrentUser() {
      //   let self = this;
      //   return self.currentUser.UserID === self.$route.params.userid;
      // },
      emailHREF() {
        let self = this;
        let returnVal

        if (self.configItems.EmailAddress && self.configItems.EmailAddBuildingSubject && self.configItems.EmailAddBuildingBodyText) {
          returnVal = `mailto:${self.configItems.EmailAddress}?subject=${self.configItems.EmailAddBuildingSubject}&body=${encodeURIComponent(self.configItems.EmailAddBuildingBodyText)}`
        }

        return returnVal;
      },
      peopleInSameLocation() {
        let people = [];        
        let self = this;

        if (!IsNullOrUndefined(self.displayUser.LocationImage)) { //&& !self.editMode
          people = self.allUsers.filter(p =>  p.LocationImage === self.displayUser.LocationImage 
                                              && p.UserID !== self.displayUser.UserID
                                              && p.LocationX > 0 && p.LocationY > 0)
        }

        return people;
      }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        return value.charAt(0).toUpperCase() + value.slice(1)
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>