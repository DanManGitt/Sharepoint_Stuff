<template>
  <div>
    <b-col cols="12" class="p-0">
      <b-card-img class="contactCardUserImage" v-bind:src="userItem.PictureURL || '/_layouts/15/images/o14_person_placeholder_96.png'"></b-card-img>
      <h4>
        <span class="float-right mr-3"><i v-if="!favouriteUsers.find(user => user.UserID === item.UserID)" @click="addFavouriteUser(item, $event)" v-b-popover.hover="'Add to favourite users'"  class="fal fa-star"></i>
        <i v-else @click="removeFavouriteUser(item, $event)" v-b-popover.hover="'Remove from favourite users'" class="fas fa-star gold-highlight"></i></span>
        {{item.PreferredName | capitalize}}</h4>
        <p v-if="item.JobTitle.toLowerCase() === 'director'">{{item.JobTitle}} - {{item.Section | orgTitleFilter}} </p>
        <p v-else>{{item.JobTitle | apsToUpper}}</p>
        <ul class="contact-details">
          <li><i class="fas fa-phone fa-fw"></i><span v-if="item.Extension">{{item.Extension}}</span><span v-else>No extension provided</span></li>
          <li><i class="fas fa-phone-office fa-fw"></i><span v-if="item.WorkPhone">{{ item.WorkPhone }}</span><span v-else>No phone number provided</span></li>
          <li v-if="item.Email"><i class="fas fa-envelope fa-fw"></i><a id="mailtoLink" :href="'mailto:' + item.Email">{{ item.Email }}</a></li>
        </ul>
    </b-col>

  </div>
</template>
 <script>
  import { sp, Web } from "@pnp/sp";

  /* eslint-disable */
  export default {
    name: 'UserCard',
    props: "userItem",
    data () {
      return {        

      }
    },    
    created(){
      const self = this;
      self.getUserDetails();      
    },

    methods:{     
      getUserDetails(){
        let self = this;              
        sp.web.lists.getByTitle("Corporate Directory Users").items.filter("UserID eq '" + self.$route.params.userid + "'").get().then(result => {
            if(result.length){
              self.currentUser = result[0]; 
              self.currentUser.FirstName = self.currentUser.PreferredName;
              self.currentUser.PreferredName = self.currentUser.PreferredName + " " + self.currentUser.LastName;
              self.getColleagues();
              self.loading = false;
            }
            else{
              self.clearUser();
            }
                    
        });
      },
      getColleagues(){
        const self = this;
        self.peers = [];
        self.directReports = [];        
        sp.profiles.getPropertiesFor("PROD\\" + self.$route.params.userid).then(function(result) {
          if(result.Peers.results){
            result.Peers.results.forEach(peer => {
              sp.profiles.getPropertiesFor(peer).then(function(result3) {
                let accountName = result3.AccountName.replace("PROD\\","");
                self.peers.push({name: result3.DisplayName, accountName: accountName, picture: result3.PictureUrl, jobTitle: result3.Title});             
              });
            });
            self.peersLoading = false;
          }
          else{
            self.peersLoading = false;
          }
          if(result.DirectReports.results){
            result.DirectReports.results.forEach(directReport => {
              sp.profiles.getPropertiesFor(directReport).then(function(result4) {
                let accountName = result4.AccountName.replace("PROD\\","");
                self.directReports.push({name: result4.DisplayName, accountName: accountName, picture: result4.PictureUrl, jobTitle: result4.Title});                  
              });
            });  
            self.subordinatesLoading = false;
          }
          else{
            self.peersLoading = false;
          }
          
        });
      },
      clearUser(){
        let self = this;
        self.peers = [];
        self.currentUser = {};
      },
      emitBranch: function(branch, section){
        if (!branch && !section) return false;
        this.$emit('clickBranchOrSection', branch, section);
        this.showContactCard = !this.showContactCard;
      }   
    },
    watch:{
      '$route.params.userid': function (id) {
          let self = this;
          self.getUserDetails()
      },
    },
    computed:{

      managerUserid(){
        let self = this;
        let fn = self.currentUser.Manager.slice(0,1);
        let ln = self.currentUser.Manager.split(" ")[1];
        let managerUserid = fn + ln;
        return managerUserid.toLowerCase();
      }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString()
        return value.charAt(0).toUpperCase() + value.slice(1)
      }
    }
  }
</script>
 