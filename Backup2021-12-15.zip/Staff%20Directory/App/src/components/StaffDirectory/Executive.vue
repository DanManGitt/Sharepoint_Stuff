<template>
  <b-row class="org-unit">
    <b-col md="12">
      <div class="row">
        <b-col lg="8" >
          <h1 class="display-4">Executive</h1>
          <div v-html="execOrgUnitDetails.UnitDescription"></div>
        </b-col>
        <b-col lg="4" >
          <UserSummary :user="commissioner[0]" v-if="commissioner.length"></UserSummary>
        </b-col>
      </div>         
    </b-col>
    <b-col cols="12">

      <h3  v-if="executive.length">Executive</h3>
      <p v-if="searchQuery !== ''">Displaying users that match '{{searchQuery}}'</p>

      <b-row v-if="$router.currentRoute.name === 'executive' && displayMode === 0 && executive.length">
        <b-col v-for="(item, index) in executive" :key="index" sm="6" lg="4" xl="3" class="d-flex align-content-stretch flex-wrap ">
          <UserSummary :user="item"></UserSummary>
        </b-col>
      </b-row>
      <UserSummaryTable :users="executive"  v-if="$router.currentRoute.name === 'executive' && displayMode === 1"></UserSummaryTable>
        
    </b-col>
  </b-row>
  
</template>
<script>
  import { sp, Web } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import UserSummary from './UserSummary';
  import UserSummaryTable from './UserSummaryTable.vue';
  import OrgChart from './OrgChart.vue';

  /* eslint-disable */
  export default {
    name: 'Executive',
    components: {
      "UserSummary": UserSummary,
      "UserSummaryTable": UserSummaryTable,
      "OrgChart": OrgChart
    },
    data () {
      return {        
        queryFilter: ''
      }
    },    
    async created(){
      const self = this;
      await self.init();
    },

    methods:{   
      ...mapActions([
        'initialise',
        'setSelectedOrgUnit'
      ]),
      async init(){
        const self = this;
        await self.initialise();
        this.setSelectedOrgUnit();
      }
    },
    watch:{
      '$route.params.orgtitle': function (id) {
          let self = this;
          self.init();
      },
    },
    computed:{
      ...mapGetters([
        'displayMode',
        'executive',
        'searchQuery',
        'execOrgUnit',
        'execOrgUnitDetails'
      ]),
      commissioner(){
        let commissioner = this.executive.filter(user => user.JobTitle.toLowerCase() === "electoral commissioner");
        let returnValue = [];
        if (commissioner.length) returnValue = commissioner;
        return returnValue;
      },

    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        return value.charAt(0).toUpperCase() + value.slice(1)
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>