<template>
  <b-row class="d-print-none">
    <b-col lg="8">
      <nav aria-label="breadcrumb">   
        <ol class="breadcrumb pl-0 pt-0">
          <li class="breadcrumb-item active" aria-current="page">
            <router-link :to="'/'"><i class="fal fa-search"></i> People Search</router-link></li>
          <li v-if="branch !== ''" class="breadcrumb-item">
            <router-link v-if="branch.Title.toLowerCase() === 'executive'" :to="'/executive'">{{branch.Title | orgTitleFilter}}</router-link>
            <router-link v-else :to="'/orgunit/' + branch.OrgUnitNumber">{{branch.Title | orgTitleFilter}}</router-link>
          </li>
          <li v-if="section !== ''" class="breadcrumb-item">
            <router-link :to="'/orgunit/' + section.OrgUnitNumber">{{section.Title | orgTitleFilter}}</router-link>
          </li>
          <li v-if="team !== ''" class="breadcrumb-item">
            <router-link :to="'/orgunit/' + team.OrgUnitNumber">{{team.Title | orgTitleFilter}}</router-link>
          </li>
        </ol>
      </nav>
    </b-col>
    <b-col lg="4" class="pl-0">
      <nav aria-label="breadcrumb" >
        <ol class="text-right"> 
          <li class="d-inline">
            <FilterComponent class="d-inline"/>
          </li>        
          <li class="d-inline " >
            <a class="btn" :class="[isOrgChartPage ? 'btn-aec-primary-alt' : 'btn-aec-primary']" 
              @click="gotoOrgStructureView" v-b-tooltip.hover title="View organistation chart"
              v-if="displayOrgChartButton">
              <i class="fal fa-sitemap"></i>
            </a>
          </li>             
          <li v-if="showCardToggle" class="d-inline">
            <a class="btn btn-aec-primary" @click="changeDisplayMode" v-b-tooltip.hover title="Switch between card and table layout" position="bottom">
              <i class="fas" :class="{ 'fa-id-card-alt': displayMode, 'fa-list': !displayMode}"></i></a>
            </li>
          <li class="d-inline" >
            <router-link :to="'/user/' + currentUser.UserID" class="btn btn-aec-primary" active-class="btn-aec-primary-alt" v-b-tooltip.hover title="View and edit your contact information">
              <i class="fal fa-user-edit"></i>
            </router-link>
          </li>
          <li class="d-inline">
            <router-link :to="'/favs/'" class="btn btn-aec-primary" v-b-tooltip.hover title="Display your favourite contacts" active-class="btn-aec-primary-alt"><i class="fa fa-star"></i></router-link>
          </li>
          <li class="d-inline"><a @click="print" class="btn btn-aec-primary" v-b-tooltip.hover title="Print this page"><i class="fas fa-print"></i></a></li>
        </ol>  
        
      </nav>
    </b-col>
  </b-row>
  
</template>
<script>
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import FilterComponent from './FilterComponent.vue';

  /* eslint-disable */
  export default {
    name: 'OrgBreadcrumb',
    components: {
      "FilterComponent": FilterComponent
    },    
    data () {
      return {        
        loading: true,
        branch: "",
        section: "",
        team: "",
        orgUnitLevel: 0,
        showCardToggle: true,
        displayModeWasChanged: false,
        isOrgChartPage: false
      }
    },
    mounted(){
      this.setOrgChartPage();
    },
    methods:{
      ...mapActions([
        'loadDisplayMode'
      ]),
      print(){
        let self = this;
        if (self.displayMode === 0 && self.$route.name !== "user"){
          self.changeDisplayMode();
          self.displayModeWasChanged = true;
        }
        setTimeout(function(){ window.print(); }, 500);
        window.onafterprint = function(event) { 
          if (self.displayMode === 1 && self.$route.name !== "user" && self.displayModeWasChanged){
            self.changeDisplayMode();
            self.displayModeWasChanged = false;
          }
        };
      },
      changeDisplayMode(){
        (this.displayMode === 0) ? this.loadDisplayMode(1) : this.loadDisplayMode(0);
      },
      checkIfNull(val){
        return IsNullOrUndefined(val);
      },
      gotoOrgStructureView(){
        let self = this;
        if (self.$router.currentRoute.name === 'orgunit') {
          let _teamLeader = ''
          switch(self.selectedOrgUnit.OrgUnitLevel) {
            case 4 :  _teamLeader = self.branchHead.UserID
                      break;
            case 5 :  _teamLeader = self.director.UserID
                      break;
            case 6 :  _teamLeader = self.teamLeader.UserID
                      break;
          }
          self.$router.push({ name: 'orgchart', params:  { level1: _teamLeader }});
        } else {
          if (self.$router.currentRoute.name === 'orgchart') {
            if (!IsNullOrUndefined(self.$route.params.level1)) { //allow moving from sub level org char to top level org chart
              self.$router.push({ name: 'orgchart' });
            }
          }
          else {
            self.$router.push({ name: 'orgchart' });
          }
        }
      },
      setOrgUnitStructure(){
        if(this.allOrgUnits.length){
          if(IsNullOrUndefined(this.selectedOrgUnit.Title) && IsNullOrUndefined(this.selectedUser.FirstName)){
            this.branch = "";
            this.section = "";
            this.team = "";
          }
          else if(!IsNullOrUndefined(this.selectedUser.FirstName)){
            let branch = this.allOrgUnits.filter(unit => unit.OrgUnitNumber === this.selectedUser.BranchNumber);
            let section = this.allOrgUnits.filter(unit => unit.OrgUnitNumber === this.selectedUser.SectionNumber);
            let team = this.allOrgUnits.filter(unit => unit.OrgUnitNumber === this.selectedUser.TeamNumber);
            (branch.length) ? this.branch = branch[0] : this.branch = "";
            (section.length) ? this.section = section[0] : this.section = "";
            (team.length) ? this.team = team[0] : this.team = "";
          }
          else{
            let level = this.selectedOrgUnit.OrgUnitLevel
            if(level === 4){
              this.branch = this.selectedOrgUnit;
              this.section = "";
              this.team = "";
            }
            else if(level === 5){
              this.section = this.selectedOrgUnit;
              this.branch = this.getParentOrgUnit(this.selectedOrgUnit.ParentOrganisationUnit);
              this.team = "";
            }
            else if(level === 6){
              this.team = this.selectedOrgUnit;
              this.section = this.getParentOrgUnit(this.selectedOrgUnit.ParentOrganisationUnit);
              this.branch = this.getParentOrgUnit(this.section.ParentOrganisationUnit);
            }
          }
        }
      },
      getParentOrgUnit(orgId){
        let orgUnit = this.allOrgUnits.filter(unit => unit.OrgUnitNumber === orgId);
        return orgUnit[0];
      },
      setOrgChartPage() {
        this.isOrgChartPage = (this.$router.currentRoute.name === 'orgchart');
      }      
    },
    watch:{
      selectedOrgUnit(){
        this.setOrgUnitStructure();
      },
      selectedUser(){
        this.setOrgUnitStructure();
      },
      allOrgUnits(){
        this.setOrgUnitStructure();
      },
      $route (to, from){
        this.showCardToggle = (this.$router.currentRoute.name === 'user') ? false : true;
        this.setOrgChartPage();
      }
    },
    computed:{
      ...mapGetters([
        "selectedOrgUnit",
        "selectedUser",
        "allOrgUnits",
        "allUsers",
        'displayMode',
        'currentUser',
        'branchHead',
        'director',
        'teamLeader',
        'configItems'
      ]),
      displayOrgChartButton() {
        let self = this;
        return self.configItems.OrgChartEnabled;
      }
    }
  }
</script>