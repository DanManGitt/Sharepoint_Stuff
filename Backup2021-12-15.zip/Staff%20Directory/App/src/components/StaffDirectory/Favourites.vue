<template>
  <div>
    <b-row v-if="$router.currentRoute.name === 'favourites' && displayMode === 0 && users.length > 0">
      <b-col v-for="(item, index) in users" :key="index" sm="6" lg="4" xl="3"   class="d-flex align-content-stretch flex-wrap ">
        <UserSummary :user="item"></UserSummary>
      </b-col>
      
    </b-row>
    <b-row v-if="users.length === 0" class="help">
      <b-col>
        <b-alert show variant="secondary" v-html="helpContent.FavouritesHelp"></b-alert>
      </b-col>
    </b-row>
    <UserSummaryTable :users="users"  v-if="$router.currentRoute.name === 'favourites' && displayMode === 1 && users.length"></UserSummaryTable>
  </div>
</template>
<script>
  import UserSummary from './UserSummary.vue';
  import UserSummaryTable from './UserSummaryTable.vue';
  import { sp, Web } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';

  /* eslint-disable */
  export default {
    name: 'Favourites',
    data () {
      return { 
        users: []       
      }
    },   
    async created(){
      const self = this;      
      await self.init();
    },
    components:{
      "UserSummary": UserSummary,
      "UserSummaryTable": UserSummaryTable,
    },
    methods:{   
      ...mapActions([
        'initialise',
        'loadFavourites',
        'loadHelpContent'
      ]),
      async init(){
        const self = this;
        await self.initialise();
        this.users = this.favourites;
        // console.log(this.favourites);
        // this.loadFavourites();
        //await this.loadHelpContent();
      }
    },
    watch:{
      favourites(){
        this.users = this.favourites;
      },
      helpContent(){
        // console.log(this.helpContent);
      }
    },
    computed:{
      ...mapGetters([
        'favourites',
        'displayMode',
        'helpContent'
      ])
    }
  }
</script>
 