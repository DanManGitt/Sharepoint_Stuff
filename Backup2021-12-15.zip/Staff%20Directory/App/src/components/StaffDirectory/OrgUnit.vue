<template>
  <b-row class="org-unit">
    <b-col md="12">
      <div class="row">
        <b-col lg="8">
          <h1 class="display-4">{{selectedOrgUnit.Title | orgTitleFilter}}</h1>
          <div v-html="selectedOrgUnitDetails.UnitDescription" v-if="!editMode" class="d-print-none">
          </div>
          <Editor 
            v-model="unitDescription" 
            v-if="editMode && (currentUserIsAdmin || currentUserIsSuperAdmin)"
            :initialValue="selectedOrgUnitDetails.UnitDescription"
            api-key="no-api-key" 
            :init="tinymceconfig">
          </Editor>
          <b-alert variant="secondary" show v-if="!editMode && branchProjectOfficer.UserID && selectedOrgUnit.OrgUnitLevel === 4" class="d-print-none">
            <strong>Branch Project Officer:</strong> <router-link :to="'/user/' + branchProjectOfficer.UserID">{{branchProjectOfficer.PreferredName}} {{branchProjectOfficer.LastName}}</router-link> - <i class="fal fa-phone"></i>  {{branchProjectOfficer.Extension}}
          </b-alert>    
          <b-alert variant="secondary" show v-if="editMode && tempOrgBPO.UserID && selectedOrgUnit.OrgUnitLevel === 4" class="d-print-none">
            <strong>Branch Project Officer:</strong> <router-link :to="'/user/' + tempOrgBPO.UserID">{{tempOrgBPO.PreferredName}} {{tempOrgBPO.LastName}}</router-link> - <i class="fal fa-phone"></i>  {{tempOrgBPO.Extension}}
          </b-alert>              
        </b-col>
        <b-col lg="4" sm="6" class="pl-sm-0 pl-md-3">
          <h2 class="d-none d-print-block" v-if="selectedOrgUnit.OrgUnitLevel === 4">Assistant Commissioner</h2>
          <h2 class="d-none d-print-block" v-if="selectedOrgUnit.OrgUnitLevel === 5">Director</h2>
          <h2 class="d-none d-print-block" v-if="selectedOrgUnit.OrgUnitLevel === 6">Team Leader</h2>
          <p v-if="editMode">Org Unit Manager is currently set to:</p>
          <UserSummary :user="(editMode) ? tempOrgHead : branchHead" v-if="selectedOrgUnit.OrgUnitLevel === 4 && ((editMode) ? tempOrgHead.LastName : branchHead.LastName)"></UserSummary>
          <UserSummary :user="(editMode) ? tempOrgHead : director" v-if="selectedOrgUnit.OrgUnitLevel === 5 && ((editMode) ? tempOrgHead.LastName : director.LastName)"></UserSummary>
          <UserSummary :user="(editMode) ? tempOrgHead : teamLeader" v-if="selectedOrgUnit.OrgUnitLevel === 6 && ((editMode) ? tempOrgHead.LastName : teamLeader.LastName)"></UserSummary>
          <vue-typeahead-bootstrap  
            v-model="selectedHead" 
            :data="allUsers" 
            :serializer="s => s.PreferredName + ' ' + s.LastName" 
            @hit="setTempOrgHead($event)"
            :placeholder="orgHeadLabel"
            class="mt-4"
            v-if="editMode"
          />
          <vue-typeahead-bootstrap  
            v-model="selectedBPO"
            :data="allUsers" 
            :serializer="s => s.PreferredName + ' ' + s.LastName" 
            @hit="setTempBPO($event)"
            placeholder="Change the Branch Project Officer"
            class="mt-4"
            v-if="editMode && selectedOrgUnit.OrgUnitLevel === 4"
          />
          
        </b-col>
        <b-col sm="6" v-if="selectedOrgUnit.OrgUnitLevel === 4 && branchProjectOfficer" class="d-none d-print-block">
          <h2>Branch Project Officer</h2>
          <UserSummary :user="branchProjectOfficer"></UserSummary>
        </b-col>
        <b-col class="d-print-none" v-if="currentUserIsAdmin || currentUserIsSuperAdmin">
          <p class="text-right mt-3">
            <a class="btn" :class="[editMode ? 'btn-aec-primary-alt' : 'btn-aec-primary']" @click="toggleEditMode">
              <span v-if="!editMode"><i class="fal fa-edit"></i> Edit</span>
              <span v-else><i class="fal fa-check"></i> Save</span>
            </a>
            <a class="btn btn-aec-primary" @click="resetToDefaults" v-if="editMode">
              <span ><i class="fal fa-times"></i> Reset to defaults</span>
            </a>
            <a class="btn btn-aec-primary" @click="editMode = false" v-if="editMode">
              <span ><i class="fal fa-times"></i> Cancel</span>
            </a>
          </p>
        </b-col>
      </div>         
    </b-col>
    <b-col cols="12">
      <h3 v-if="selectedOrgUnitChildren.length" v-html="teamHeading" class="d-print-none"></h3>
      <div v-if="selectedOrgUnitChildren.length" class="d-print-none mb-4">
        <div v-for="child in selectedOrgUnitChildren" :key="child.OrgUnitNumber" class="d-inline-block mr-2 mb-4">
          <OrgUnitSummary :orgunit="child"></OrgUnitSummary>
        </div>
      </div>   
      <b-row v-if="displayUsers.length > 0 || filterJobtitles.length > 0">
        <b-col sm="12" md="12" lg="12" class="mb-2">
          <h3 class="d-inline">Staff</h3>
        </b-col>
      </b-row>
      <b-row v-if="$router.currentRoute.name === 'orgunit' && displayMode === 0 && displayUsers.length">
        <b-col v-for="(item, index) in displayUsers" :key="index" sm="6" lg="4" xl="3"  class="d-flex align-content-stretch flex-wrap ">
          <UserSummary :user="item"></UserSummary>
        </b-col>
      </b-row>
      <UserSummaryTable :users="displayUsers"  v-if="$router.currentRoute.name === 'orgunit' && displayMode === 1 && displayUsers.length"></UserSummaryTable>
        
      <b-alert v-if="!displayUsers.length">It appears that there are no staff associated with {{selectedOrgUnit.Title}}</b-alert>
    </b-col>
  </b-row>
  
</template>
<script>
  import { sp, Web, PermissionKind  } from "@pnp/sp";
  import { mapGetters } from 'vuex';
  import { mapActions } from 'vuex';
  import UserSummary from './UserSummary';
  import OrgUnitSummary from './OrgUnitSummary';
  import UserSummaryTable from './UserSummaryTable.vue';
  import OrgUnitHeadSummary from './OrgUnitHeadSummary.vue';
  
  // Import TinyMCE
  import tinymce from 'tinymce/tinymce';

  // A theme is also required
  import 'tinymce/themes/silver';

  // Any plugins you want to use has to be imported
  import 'tinymce/plugins/paste';
  import 'tinymce/plugins/link';

  import Editor from '@tinymce/tinymce-vue'

  /* eslint-disable */
  export default {
    name: 'OrgUnit',
    props:["orgtitle","allStaff"],
    components: {
      "UserSummary": UserSummary,
      "OrgUnitSummary": OrgUnitSummary,
      "UserSummaryTable": UserSummaryTable,
      'Editor': Editor,
      "OrgUnitHeadSummary": OrgUnitHeadSummary
    },
    data () {
      return {        
        queryFilter: '',
        editMode: false,
        tinymceconfig: {
          height: 300
        },
        //isAdmin: false,
        unitDescription: "",
        testTest: "xxxxx",
        tempOrgHead: {},
        tempOrgBPO: {},
        tempTeamLeader: {},
        selectedHead: "",
        selectedBPO: ""
      }
    },    
    async created(){
      const self = this;
      await self.init();
    },

    methods:{   
      async init(){
        const self = this;
        await self.initialise();
      },
      ...mapActions([
        'initialise',
        'setSelectedOrgUnit',
        'setSelectedOrgUnitDetails',
        'loadSelectedOrgUnit',
        'saveOrgUnitDetails',
        'resetOrgUnitHeadAndBPO',
        'loadCurrentUserAdminStatus'
      ]),
      setTempHeadAndBPO() {
        if(this.selectedOrgUnit.OrgUnitLevel === 4) {
          this.tempOrgHead = this.branchHead;
          this.tempOrgBPO = this.branchProjectOfficer;
          this.unitDescription = this.selectedOrgUnitDetails.UnitDescription;            
        }
        else if(this.selectedOrgUnit.OrgUnitLevel === 5) this.tempOrgHead = this.director;
        else if(this.selectedOrgUnit.OrgUnitLevel === 6) this.tempOrgHead = this.teamLeader;
      },
      async toggleEditMode(){
        //If not in edit mode, set edit mode
        if (!this.editMode){
          this.editMode = true;
          this.setTempHeadAndBPO();
        }
        //else, the button should save the content into the org unit list
        else{
          const saveObj = {
            UnitDescription: this.unitDescription,
            BPO: this.tempOrgBPO,
            Manager: this.tempOrgHead
          }
          await this.saveOrgUnitDetails(saveObj);
          await this.setSelectedOrgUnit(this.$route.params.orgid);
          await this.setSelectedOrgUnitDetails(this.$route.params.orgid);
          this.editMode = false;
          this.$bvToast.toast(`Your changes were saved`, {
            title: "Success",
            autoHideDelay: 3000,
            solid: true,
            variant: 'success'
          })
        }
      },
      setTempOrgHead($event){
        this.tempOrgHead = $event;
      },
      setTempBPO($event){
        this.tempOrgBPO = $event;
      },
      async resetToDefaults(){
        this.tempOrgHead = {};
        this.tempOrgBPO = {};
        this.selectedHead = "";
        this.selectedBPO = "";

        await this.resetOrgUnitHeadAndBPO();

        this.$nextTick(() => {
          this.setTempHeadAndBPO();        
        })
      }
    },
    mounted(){
      document.getElementById('s4-workspace').scrollTop = 0;
    },
    watch:{
      '$route.params.orgid': function (id) {
        let self = this;
        self.init();          
      },
      allOrgUnits(){
        // console.log(this.allOrgUnits.length);
      }
    },
    computed:{
      ...mapGetters([
        "orgUnitHead",
        "selectedOrgUnit",
        "selectedOrgUnitDetails",
        "allOrgUnits",
        "displayUsers",
        'searchQuery',
        'branchHead',
        'branchProjectOfficer',
        'director',
        'teamLeader',
        'selectedOrgUnitChildren',
        'displayMode',
        'currentUser',
        'userSummary',
        'allUsers',
        'currentUserIsAdmin',
        'currentUserIsSuperAdmin',
        'filterJobtitles'
      ]),
      teamHeading(){
        let label = "Sections"
        if(this.selectedOrgUnit.OrgUnitLevel === 5){
          label = "Teams"
        }
        return label
      },
      rowCount(){
        let children = this.selectedOrgUnitChildren.length;
        let className = "col-md-2";
        switch(children.length) {
          case 1: className = "col-md-6"
            break;
          case 2: className = "col-md-6"
            break;
          case 3: className = "col-md-4"
            break;
          case 4: className = "col-md-3"
            break;
          case 5: className = "col-md-2"
            break;
          case 6: className = "col-md-2"
            break;
          default:
            case 6: className = "col-md-2"
        }
        return className;
      },
      managerUserid(){
        let self = this;
        let fn = self.currentUser.Manager.slice(0,1);
        let ln = self.currentUser.Manager.split(" ")[1];
        let managerUserid = fn + ln;
        return managerUserid.toLowerCase();
      },
      orgHeadLabel(){
        let orgLevel = this.selectedOrgUnit.OrgUnitLevel;
        if( orgLevel === 4) return 'Change the Branch Head'
        else if(orgLevel === 5) return 'Change the Director'
        else if(orgLevel === 6) return 'Change the Team Leader'
      }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        return value.charAt(0).toUpperCase() + value.slice(1)
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>