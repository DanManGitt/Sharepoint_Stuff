<template>
    <b-card no-body :class="{statemanager: checkIfStateManager(user.JobTitle), director: checkIfDirector(user.JobTitle), commissioner: checkIfCommissioner(user.JobTitle), operationsmanager: checkIfOperationsManager(user.JobTitle) }" class="user-summary">
      <div class="user-summary-header d-print-none" v-if="checkIfDirector(user.JobTitle)">Director</div> 
      <div class="user-summary-header d-print-none" v-if="checkIfStateManager(user.JobTitle)">State Manager</div> 
      <div class="user-summary-header d-print-none" v-if="checkIfCommissioner(user.JobTitle)">Executive</div> 
      <div class="user-summary-header d-print-none" v-if="checkIfOperationsManager(user.JobTitle)">Operations Manager</div>  
      <div class="card-body">     
      <b-row no-gutters>
        <b-col cols="12">
          <b-row>
            <b-col cols="8">
              <div class="person-title-div">
                <h5 class="mb-0">
                  <router-link :to="'/user/' + user.UserID">{{user.PreferredName | capitalise}} {{user.LastName | capitalise}}</router-link>
                </h5>
                <div v-if="user.JobTitle && user.JobTitle.toLowerCase().indexOf('director') !== -1 && user.JobTitle.toLowerCase().indexOf('assistant') === -1">
                  <p class="text-truncate mb-0" v-b-popover.hover="" :ref="'directorTitle' + id">{{user.Section | orgTitleFilter}}</p>
                  <p class="text-truncate" v-b-popover.hover="user.Branch">{{user.Branch}} </p>
                </div>
                <div v-else>
                  <p class="mb-0" >{{user.JobTitle | apsToUpper}}</p>
                  <p class="text-truncate" v-b-popover.hover="user.Branch">{{user.Branch}}</p>
                </div>
              </div>
            </b-col>
            <b-col cols="4" class="text-align-right py-0">
              <div class="person-image-div ">
                <img v-if="user.PictureURL" class="contactCardUserImage float-left" :src="user.PictureURL" /> 
                <span v-else class="person-initials d-print-none">{{user.PreferredName | initial}}{{user.LastName | initial}}</span> 
              </div>
              <span class="favourite-span d-print-none">
                  <i v-if="checkIfFavourite(user)" @click="callToggleFavourite(user)" v-b-popover.hover="'Remove from favourite users'" class="fas fa-star gold-highlight"></i>
                  <i v-else @click="callToggleFavourite(user)" v-b-popover.hover="'Add to favourite users'"  class="fal fa-star"></i>
                </span>
            </b-col>
            <b-col cols="12">
              <ul class="contact-details">
                <li v-if="user.Extension || user.WorkPhone"><i class="fas fa-phone fa-fw"></i><span  v-if="user.Extension">x{{user.Extension}}<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                <span v-if="user.WorkPhone">{{ user.WorkPhone | removeBrackets }}</span><span v-else>No phone number provided</span></li>
                <li v-if="user.CellPhone"><i class="fas fa-mobile-alt fa-fw" style="margin-right:3px !important;"></i><span >{{ user.CellPhone }}</span></li>
                <!-- <li class="d-inline-block w-50 d-print-none"></li>
                <li v-if="user.Email" class="d-inline-block  d-print-none"><i class="fas fa-envelope mr-2"></i><a id="mailtoLink" :href="'mailto:' + user.Email">Email</a></li>
                <li v-if="user.Email" class="d-none  d-print-block"><i class="fas fa-envelope mr-2"></i><a id="mailtoLink" :href="'mailto:' + user.Email">{{user.Email}}</a></li> -->
              </ul>
            </b-col>
          </b-row>
        </b-col>
      </b-row>
      </div>
      <div class="card-footer">
        <router-link :to="'/user/' + user.UserID" class="btn btn-light"><i class="fas fa-user"></i></router-link>
        <a class="btn btn-light" :href="`${teamsChatURL}${user.Email}`" target="_blank"><i class="fas fa-comment-alt"></i></a> 
        <a id="mailtoLink" class="btn btn-light" :href="'mailto:' + user.Email"><i class="fas fa-envelope"></i></a> 

      </div>    
    </b-card>

</template>
<script>
import { sp, Web } from "@pnp/sp";
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';
import { objectToMap } from '@pnp/common';

  /* eslint-disable */
export default {
    name: 'UserSummaryCard',
    props:{
      user: Object,
      id: Object,
    },
    data () {
        return {       

        }
    },    
    created(){
        this.init();
    },
    mounted: function () {
      // console.log("height: " + this.offsetHeight);
    },
    methods: {
        
        init(){
        },
        ...mapActions([
            'toggleFavourite'
        ]),
        checkIfDirector(jobTitle){
            if(!IsNullOrUndefined(jobTitle)){
                return jobTitle.toLowerCase().indexOf("director") !== -1 && jobTitle.toLowerCase().indexOf("assistant") === -1 ? true : false;
            }

        },
        checkIfStateManager(jobTitle){
            if(!IsNullOrUndefined(jobTitle)){
                return jobTitle.toLowerCase().indexOf("state manager") !== -1 && jobTitle.toLowerCase().indexOf("assistant") === -1 ? true : false;
            }

        },
        checkIfCommissioner(jobTitle){
            if(!IsNullOrUndefined(jobTitle)){
                return ((jobTitle.toLowerCase().indexOf("commissioner") !== -1 || jobTitle.toLowerCase().indexOf("chief legal") !== -1) && jobTitle.toLowerCase().indexOf("to the") === -1  && jobTitle.toLowerCase().indexOf("assistant to") === -1) ? true : false;
            }
        },
        checkIfOperationsManager(jobTitle){
            if(!IsNullOrUndefined(jobTitle)){
                return jobTitle.toLowerCase().indexOf("operations manager") !== -1 ? true : false;
            }

        },        
        checkIfFavourite(user){
            let isFav = false;
            this.favourites.forEach(fav => {
                if(user.UserID === fav.UserID){
                    isFav = true;
                }
            });
            return isFav;
        },
        callToggleFavourite(user, $event){
            this.toggleFavourite(user);
        }
    },
    computed: {
        ...mapGetters([
            'favourites',
            'teamsChatURL'
        ])
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        if(value.indexOf("mc") !== -1 || value.indexOf("o'") !== -1){
          return value.charAt(0).toUpperCase() + value.slice(1,2) + value.charAt(2).toUpperCase() + value.slice(3)
        }
        else{
          return value.charAt(0).toUpperCase() + value.slice(1)
        }
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>
 