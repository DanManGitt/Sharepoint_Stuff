<template>
  <b-table :items="users" :fields="tableFields" striped bordered hover no-sort-reset show-empty fixed responsive>
    <template slot="empty">
        <h5>No results</h5>
    </template>

    <template #cell(PictureURL)="data">
        <div class="person-image-div ">
          <b-img v-if="data.item.PictureURL" class="contactCardUserImage float-left" :src="data.item.PictureURL" /> 
          <span v-else class="person-initials">{{data.item.PreferredName | initial}}{{data.item.LastName | initial}}</span>
        </div>
    </template>
    <template #cell(PreferredName)="data">
        <router-link :to="'/user/' + data.item.UserID">{{data.item.PreferredName | capitalise}} {{data.item.LastName | capitalise}}</router-link>
        <!-- <h5 style="display:inline">{{data.item.PreferredName}}</h5> -->
        <!-- <p>{{ data.item.JobTitle }}</p> -->
    </template>
    <template #cell(JobTitle)="data">
        
        <!-- <h5 style="display:inline">{{data.item.PreferredName}}</h5> -->
        <p>{{ data.item.JobTitle }}</p>
    </template>
    <!-- <template slot="BranchState" slot-scope="data">
      <router-link :to="'/orgunit/' + data.item.BranchNumber">{{ data.item.Branch }}</router-link>
    </template>
    <template slot="Section" slot-scope="data">
      <router-link :to="'/orgunit/' + data.item.SectionNumber">{{ data.item.Section }}</router-link>
    </template>

    <template slot="TeamDivisionLWU" slot-scope="data">
      <router-link :to="'/orgunit/' + data.item.TeamNumber">{{ data.item.Team }}</router-link>
    </template> -->

    <template #cell(ContactDetails)="data">
        <ul class="list-unstyled">
          <li v-if="data.item.Extension"><i class="fal fa-phone mr-2"></i>x{{data.item.Extension}}</li>
          <li v-if="data.item.WorkPhone"><i class="fas fa-phone mr-2 d-print-none"></i>{{data.item.WorkPhone}}</li>
          <li v-if="data.item.CellPhone"><i class="fas fa-mobile fa mr-2"></i>{{data.item.CellPhone}}</li>
          <li v-if="data.item.Email"><i class="fas fa-envelope fa mr-2 d-print-none"></i><a :href="'mailto:' + data.item.Email">{{data.item.Email}}</a></li>
        </ul>

    </template>
    <template #cell(Pin)="data">
        <span class="favourite-span">
          <i v-if="checkIfFavourite(data.item)" @click="callToggleFavourite(data.item)" v-b-popover.hover="'Remove from favourite users'" class="fas fa-star gold-highlight"></i>
          <i v-else @click="callToggleFavourite(data.item)" v-b-popover.hover="'Add to favourite users'"  class="fal fa-star"></i>
        </span>
    </template>
  </b-table>
</template>
<script>
import { sp, Web } from "@pnp/sp";
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';

  /* eslint-disable */
export default {
    name: 'UserSummaryTable',
    props:["users"],
    data () {
        return {       
          tableFields: [
            { key: "PictureURL", label: "Picture", tdClass: 'userTableUserImage d-print-none position-relative', thClass: 'd-print-none'},
            { key: "PreferredName", label: "Name" , tdClass: 'userTableNameCol'},
            { key: "JobTitle", label: "JobTitle" , tdClass: 'userTableNameCol'},
            // { key: "BranchState",label: "Branch"},
            // { key: "Section", label: "Section"},
            // { key: "TeamDivisionLWU", label: "Team"},
            { key: "ContactDetails", label: "Contact Details" , tdClass: 'userTableContactCol'},
            { key: "Pin", label: "", label: "Add to favourites", tdClass: 'userTableFavouritesCol  d-print-none position-relative text-center', thClass: 'd-print-none text-center'}
          ],
        }
    },    
    created(){
        this.init();
        console.log('created', this.users);
    },
    methods: {
        ...mapActions([
          'toggleFavourite'
        ]),
        init(){
        },
        checkIfDirector(jobTitle){
            if(!IsNullOrUndefined(jobTitle)){
                return jobTitle.toLowerCase().indexOf("director") !== -1 && jobTitle.toLowerCase().indexOf("assistant") === -1 ? true : false;
            }

        },
        checkIfCommissioner(jobTitle){
            if(!IsNullOrUndefined(jobTitle)){
                return jobTitle.toLowerCase().indexOf("commissioner") !== -1 || jobTitle.toLowerCase().indexOf("chief legal") !== -1 ? true : false;
            }
        },
        checkIfFavourite(user){
            let isFav = false;
            this.favourites.forEach(fav => {
                if(user.UserID === fav.UserID){
                    isFav = true;
                }
            });
            return isFav;
            //return this.favourites.find(contact => contact.UserID !== user.UserID)
        },
        callToggleFavourite(user, $event){
            this.toggleFavourite(user);
        }
    },
    computed: {
        ...mapGetters([
            'favourites'
        ])
    },
    filters: {
      /*capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        return value.charAt(0).toUpperCase() + value.slice(1)
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }*/
    }
  }
</script>
 