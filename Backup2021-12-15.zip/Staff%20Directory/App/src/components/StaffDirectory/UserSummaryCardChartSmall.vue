<template>
    <b-card no-body :class="{commissioner: checkIfCommissioner(user.JobTitle) }" class="p-3 user-summary-card-chart-small">
      <b-row no-gutters v-b-tooltip.hover :title="`${user.PreferredName} ${user.LastName}`">
        <b-col cols="12">
          <b-row>
            <b-col cols="9">
              <div class="person-title-div">
                <h5 class="mb-0 small-title">
                  <router-link :to="'/user/' + user.UserID" event="" 
                    @click=""
                  >{{user.PreferredName | capitalise}} {{user.LastName | capitalise}}</router-link>
                </h5>
                  <p class="mb-0 text-truncate" >{{user.JobTitle | apsToUpper}}</p>
                  <p v-if="titleToShowAtLevel" class="struct_title  mb-0 text-truncate" >{{titleToShowAtLevel}}</p>
              </div>
            </b-col>
            <b-col cols="3" class="text-align-right py-0">
              <div class="person-image-div ">
                <img v-if="user.PictureURL" class="contactCardUserImage float-left" :src="user.PictureURL" /> 
                <span v-else class="person-initials d-print-none">{{user.PreferredName | initial}}{{user.LastName | initial}}</span> 
              </div>
              <!--<span v-if="showPromoteToTop" class="promoteToTop-span d-print-none">
                <i @click.stop="promoteToTop(user)" v-b-popover.hover="'Select as top of structure'" class="fas fa-sitemap"></i>
              </span>-->
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-card>

</template>
<script>
import { sp, Web } from "@pnp/sp";
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';
import { objectToMap } from '@pnp/common';

  /* eslint-disable */
export default {
    name: 'UserSummaryCardChart',
    props:{
      user: Object,
      // id: Object,
      structureTitle: Object,
      showPromoteToTop: {
        type: Boolean,
        default: false
      }
    },
    data () {
        return {       

        }
    },    
    created(){
        this.init();
    },
    mounted: function () {
      // console.log("height: " + this.offsetHeight);
    },
    methods: {
        
        init(){
        },
        ...mapActions([
        ]),
        checkIfCommissioner(jobTitle){
          if(!IsNullOrUndefined(jobTitle)){
            return (jobTitle.toLowerCase().indexOf("electoral commissioner") !== -1 && jobTitle.toLowerCase().indexOf("deputy") === -1); 
          }
        },
        handleUserClick(userID){
          let self = this;
          self.$router.push({ name: 'user', params: { userid: userID  } });
        },
        promoteToTop(user){
          let self = this;
          // console.log('current route', self.$route);
          self.$router.push({ name: 'orgchart', params: { level1: user.UserID, lastSelected: self.$route.params.lastSelected } });
          // self.$router.push({ name: self.$route.name, params: { level1: user.UserID, lastSelected: self.$route.params.lastSelected } });
        },
    },
    computed: {
        ...mapGetters([
        ]),
        showLevelTitle() {
          let self = this;
          const isCommisioner = self.checkIfCommissioner(self.user.JobTitle);
          const isDeputyCommisioner = self.checkIfDeputyCommissioner(self.user.JobTitle);
          return !isCommisioner && !isDeputyCommisioner;
        }, 
        structureLevel() {
          let self = this;
          let ReturnVal;

          if (self.structureTitle.title === self.user.Branch) {
            ReturnVal = 0;
          } 
          else if (self.structureTitle.title === self.user.Div) {
            ReturnVal = 1;
          } 
          else if (self.structureTitle.title === self.user.Section) {
            ReturnVal = 2;
          } 
          else if (self.structureTitle.title === self.user.Team) {  
            ReturnVal = 3;
          } 
          else {
            ReturnVal = -1;
          }

          return ReturnVal;
        },
        titleToShowAtLevel() {
          // show the next level down in structure. 
          // ie If the person is appearing under a Title that is at the branch level, then show this person's Division title
          // Branch: Show Division
          // Division: Show Section
          // Section: Show Team
          // Team: show nothing.
          // Unknown: show Team || Section || Branch || Division;
          let self = this;
          let ReturnVal = "";

/*          const Branch   = self.user.Branch  ? `${self.user.Branch} Branch`   : null;
          const Division = self.user.Div     ? `${self.user.Div} Division`    : null;
          const Section  = self.user.Section ? `${self.user.Section} Section` : null;
          const Team     = self.user.Team    ? `${self.user.Team} Team`       : null;*/

          const Branch   = self.user.Branch;
          const Division = self.user.Div;
          const Section  = self.user.Section;
          const Team     = self.user.Team;

          switch (self.structureLevel) {
            case 0 :  ReturnVal = Division;
                      break;
            case 1 :  ReturnVal = Section;
                      break;
            case 2 :  ReturnVal = Team;
                      break;
            case 3 :  ReturnVal = "";
                      break;                                                                
            case -1:  ReturnVal = Team || Section || Branch || Division;
                      break;                                                                                                        
          }

          if (ReturnVal === self.structureTitle.title) {
            ReturnVal = undefined;
          }

          return ReturnVal;
        }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        if(value.indexOf("mc") !== -1 || value.indexOf("o'") !== -1){
          return value.charAt(0).toUpperCase() + value.slice(1,2) + value.charAt(2).toUpperCase() + value.slice(3)
        }
        else{
          return value.charAt(0).toUpperCase() + value.slice(1)
        }
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>
