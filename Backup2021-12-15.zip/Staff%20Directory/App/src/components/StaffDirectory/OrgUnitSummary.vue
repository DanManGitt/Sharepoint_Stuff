<template>
<div>
  <b-button :id="`tooltip-${orgunit.Id}`" @click="$router.push(`/orgunit/${orgunit.OrgUnitNumber}`)" variant="outline-primary">
    {{orgunit.Title | orgTitleFilter}} <span v-if="orgunit.Title.toLowerCase() === 'operations'" v-html="orgUnitParentTitle(orgunit.ParentOrganisationUnit)"></span>
  </b-button>
  <b-tooltip v-if="orgunit.UnitDescription" :target="`tooltip-${orgunit.Id}`" triggers="hover" placement="top">
      <span v-html="truncateDescription(orgunit.UnitDescription)"></span>
    </b-tooltip>
</div>
  <!-- <b-card class="p-3 org-unit-summary"> 
    <b-row no-gutters>
      <b-col cols="12">
          <div class="text-center">
            <router-link v-if="orgunit.OrgUnitNumber !== 0"  :to="'/orgunit/' + orgunit.OrgUnitNumber">{{orgunit.Title | orgTitleFilter}} <span v-if="orgunit.Title.toLowerCase() === 'operations'" v-html="orgUnitParentTitle(orgunit.ParentOrganisationUnit)"></span></router-link>
            <router-link v-else :to="'/executive/'">{{orgunit.Title}}</router-link>
          </div>
      </b-col>
    </b-row>
  </b-card>-->
</template> 
<script>
import { sp, Web } from "@pnp/sp";
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';
import clip from "text-clipper"

  /* eslint-disable */
export default {
    name: 'OrgUnitSummary',
    props:{
      orgunit:  {
        type: Object
      }
    },
    data () {
        return {       

        }
    },    
    created(){
        this.init();
    },
    methods: {
        
        init(){
        },
        orgUnitParentTitle(parentOrgId){
          let parent = this.allOrgUnits.filter(unit => unit.OrgUnitNumber === parentOrgId);
          return "<br />(" + parent[0].Title + ")";
        },
        truncateDescription(htmlString){
          const clippedHtml = clip(htmlString, 140, { html: true, maxLines: 5 });
          //var result = RegExp.Replace(clippedHtml,"(style=\")(.*?;).*\"");
          return clippedHtml;
        }

        
    },
    computed: {
        ...mapGetters([
            'allUsers',
            'allOrgUnits'
        ])
        
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        return value.charAt(0).toUpperCase() + value.slice(1)
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>
 