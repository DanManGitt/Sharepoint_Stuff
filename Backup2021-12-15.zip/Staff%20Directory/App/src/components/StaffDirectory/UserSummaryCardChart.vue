<template>
    <b-card no-body :class="{commissioner: checkIfCommissioner(user.JobTitle) }" class="p-3 user-summary-card-chart">
      <b-row no-gutters>
        <b-col cols="12">
          <b-row>
            <b-col cols="9">
              <div class="person-title-div">
                <h5 class="mb-0">
                  <router-link :to="'/user/' + user.UserID" event="" 
                    @click.native.prevent.stop="handleUserClick(user.UserID)"
                  >{{user.PreferredName | capitalise}} {{user.LastName | capitalise}}</router-link>
                </h5>
                  <p class="mb-0 text-truncate" >{{user.JobTitle | apsToUpper}}</p>
                  <p v-if="titleToShowAtLevel" class="struct_title  mb-0 text-truncate" >{{titleToShowAtLevel}}</p>
              </div>
            </b-col>
            <b-col cols="3" class="text-align-right py-0">
              <div class="person-image-div ">
                <img v-if="user.PictureURL" class="contactCardUserImage float-left" :src="user.PictureURL" /> 
                <span v-else class="person-initials d-print-none">{{user.PreferredName | initial}}{{user.LastName | initial}}</span> 
              </div>
              <span v-if="showPromoteToTop" class="promoteToTop-span d-print-none">
                <i @click.stop="promoteToTop(user)" v-b-popover.hover="'Select as top of structure'" class="fas fa-sitemap"></i>
              </span>
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-card>

</template>
<script>
import { sp, Web } from "@pnp/sp";
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';
import { objectToMap } from '@pnp/common';

  /* eslint-disable */
export default {
    name: 'UserSummaryCardChart',
    props:{
      user: Object,
      // id: Object,
      // structureTitle: Object,
      showPromoteToTop: {
        type: Boolean,
        default: false
      }
    },
    data () {
        return {       

        }
    },    
    created(){
        this.init();
    },
    mounted: function () {
      // console.log("height: " + this.offsetHeight);
    },
    methods: {
        
        init(){
        },
        ...mapActions([
          'getManager'
        ]),
        checkIfCommissioner(jobTitle){
          if(!IsNullOrUndefined(jobTitle)){
            return (jobTitle.toLowerCase().indexOf("electoral commissioner") !== -1 && jobTitle.toLowerCase().indexOf("deputy") === -1); 
          }
        },
        handleUserClick(userID){
          let self = this;
          self.$router.push({ name: 'user', params: { userid: userID  } });
        },
        promoteToTop(user){
          let self = this;
          // console.log('current route', self.$route);
          self.$router.push({ name: 'orgchart', params: { level1: user.UserID, lastSelected: self.$route.params.lastSelected } });
          // self.$router.push({ name: self.$route.name, params: { level1: user.UserID, lastSelected: self.$route.params.lastSelected } });
        },
        findUserLevelInStructure() {
          let self = this;

          let foundLevel = -1;
          self.orgChart.structure.forEach((users, index) => {
            const foundItems = users.filter(user => self.user.UserID === user.UserID);
            if(foundItems.length > 0) {
              foundLevel = index;
            }
          });
          
          return foundLevel;
        }
    },
    computed: {
      ...mapGetters([
        'allUsers',
        'orgChart'        
      ]),
      showLevelTitle() {
        let self = this;
        const isCommisioner = self.checkIfCommissioner(self.user.JobTitle);
        const isDeputyCommisioner = self.checkIfDeputyCommissioner(self.user.JobTitle);
        return !isCommisioner && !isDeputyCommisioner;
      }
    },
    asyncComputed: {
      async titleToShowAtLevel() {
        let self = this;
        let ReturnVal = "";

        const Branch   = self.user.Branch;
        const Division = self.user.Div;
        const Section  = self.user.Section;
        const Team     = self.user.Team;

        ReturnVal = Team || Section || Division || Branch ;

        const manager = await self.getManager(self.user);
        if (manager) {
          const isManagerFAS = manager.JobTitle.toLowerCase().indexOf("first assistant commissioner") !== -1;
          if (isManagerFAS){
            ReturnVal = Branch;
          }
        }

        const level = self.findUserLevelInStructure();
        if (level > 0){
          if (self.orgChart.titles[level-1] ? self.orgChart.titles[level-1].title === ReturnVal : false){
            ReturnVal = undefined;
          }
        } else {
          ReturnVal = undefined;
        }

        return ReturnVal;
      }
    },
    filters: {
      capitalize: function (value) {
        if (!value) return ''
        value = value.toString().toLowerCase();
        if(value.indexOf("mc") !== -1 || value.indexOf("o'") !== -1){
          return value.charAt(0).toUpperCase() + value.slice(1,2) + value.charAt(2).toUpperCase() + value.slice(3)
        }
        else{
          return value.charAt(0).toUpperCase() + value.slice(1)
        }
      },
      initial: function (value) {
        if (!value) return ''
        return value.charAt(0).toUpperCase()
      }
    }
  }
</script>
