import Vue from "vue";
import Vuex from "vuex";
import orgUnits from "./modules/orgUnits"
import users from "./modules/users";

Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
      orgUnits,
      users
    }
  })