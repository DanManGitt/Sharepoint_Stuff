import { sp, PermissionKind } from "@pnp/sp";
import { taxonomy } from "@pnp/sp-taxonomy";
import _ from 'lodash';

// initial state
const state = {
  initialised: false,
  hasPerms: undefined,
  currentUser: {},
  currentUserIsAdmin: false,
  currentUserPreferences: {},
  userGroups: [],
  allUsers: [],
  userSummary: [],
  executive: [],
  orgUnitUsers: [],
  displayUsers: [],
  selectedUser: {},
  selectProperties:[
    'PreferredName',
    'FirstName',
    'LastName',
    'JobTitle',
  ],
  freetextSearchFields: [
    'PreferredName',
    'JobTitle',
    'FirstName',
    'LastName'
  ],
  favourites: [],
  specialFilters: {
    filterJobtitles: [],
  },
  defaults: {
    specialFilters: { filterJobtitles: ["temporary office assistant"] }
  },
  filterJobtitles: [],
  showAllAllowableJobTitles: true, // true = Show all allowableFilterJobTitles, false = show only allowableFilterJobTitles that are currently available to filter
  allowableFilterJobTitles: [],    // add "All" to allow filtering on all job titles.
  peers: [],
  directReports: [],
  searchQuery: '',
  displayMode: 0, //0 = card, 1 = table
  searchStrings: {
    firstName: '',
    lastName: '',
    jobtitle: '',
    orgUnitTitle: '',
    orgUnitDescription: ''
  },
  helpContent: {},
  configItems: {},
  executiveStructure: [
    { jobTitles: ["electoral commissioner"],                         jobTitleExclude: "",      OrgChartTitle: { title: "Executive", displayTitle: "Executive Leadership Team" } , matchExact: true,  filterStates: false },
    { jobTitles: ["deputy electoral commissioner"],                  jobTitleExclude: "",      OrgChartTitle: { title: "Executive", displayTitle: ""},                            matchExact: true,  filterStates: false },
    { jobTitles: ["first assistant commissioner"],                   jobTitleExclude: "",      OrgChartTitle: { title: "Executive", displayTitle: ""},                            matchExact: true,  filterStates: false },
    { jobTitles: ["assistant commissioner", "chief legal officer"],  jobTitleExclude: "first", OrgChartTitle: { title: "",          displayTitle: "Senior Executive Staff"},      matchExact: false, filterStates: true },
    { jobTitles: ["state manager"],                                  jobTitleExclude: "",      OrgChartTitle: { title: "",          displayTitle: "State Office Operations"},     matchExact: false, filterStates: false }
  ],
  orgChart: {
    selected: [],
    structure: [],
    titles: []    
  },
  taxonomySources: {
    termStore : { name: "Managed Metadata Service", Id: null},
    termGroup : { name: "AEC",  Id: null},
    termSet   : { name: "Office Locations", Id: null}
  },
  Locations: [],
  AusStates: ["Australian Capital Territory", "New South Wales", "Northern Territory", "Queensland", "South Australia", "Tasmania", "Victoria", "Western Australia"],
  imageLibrary: '/apps/people/PublishingImages/',
  teamsChatURL: 'https://teams.microsoft.com/l/chat/0/0?users='
}

// getters
const getters = {
  initialised: state => state.initialised,
  currentUser: state => state.currentUser,
  currentUserIsAdmin: state => state.currentUserIsAdmin,
  // currentUserIsSuperAdmin: state => state.currentUserIsSuperAdmin,
  currentUserIsSuperAdmin: state => {
    let superAdminGroups = state.userGroups.filter(g => g.Title.toLowerCase().includes("sd super admins"));
    return superAdminGroups.length > 0;
  },
  currentUserPreferences: state => state.currentUserPreferences,
  allUsers: state => state.allUsers,
  userSummary: state => state.userSummary,
  executive: state => state.executive,
  orgUnitUsers: state => state.orgUnitUsers,
  displayUsers: state => state.displayUsers,
  selectedUser: state => state.selectedUser,
  favourites: state => state.favourites,
  peers: state => state.peers,
  directReports: state => state.directReports,
  searchQuery: state => state.searchQuery,
  displayMode: state => state.displayMode,
  searchStrings: state => state.searchStrings,
  helpContent: state => state.helpContent,
  configItems: state => state.configItems,
  filterJobtitles: state => state.filterJobtitles,
  specialFilters: state => state.specialFilters,
  orgChart: state => state.orgChart,
  Locations: state => state.Locations,
  imageLibrary: state => state.imageLibrary,
  teamsChatURL: state => state.teamsChatURL,
}

//actions
const actions = {
  async initialise({commit, dispatch}) {
    if (state.initialised === false) {
      await new Promise(function(resolve, reject) {
        let promises = [];
        let promise = null;

        promise = dispatch('loadAllUsers');
        promises.push(promise);
        promise = dispatch('loadCurrentUser');
        promises.push(promise);
        promise = dispatch('getUserGroups');
        promises.push(promise);
        promise = dispatch('loadFavourites');
        promises.push(promise);
        promise = dispatch('loadSpecialFiltersSettings');
        promises.push(promise);
        promise = dispatch('loadConfigurableContent');
        promises.push(promise);
        promise = dispatch('loadDisplayMode');
        promises.push(promise); 
        promise = dispatch('getTaxonomyTerms');
        promises.push(promise);         

        Promise.all(promises).then(() => {
          commit('setInitialised',true);
          resolve();
        });

      });
    }
  },
  //Load the current user
  async loadCurrentUser({commit, dispatch}){
    commit('startLoading');
    let currentUser = await sp.web.currentUser.get();
    const loginNameComponents = currentUser.LoginName.split('\\');
    let loginName = currentUser.LoginName;
    if (loginNameComponents.length > 0) {
      loginName = loginNameComponents[1];
    }

    if (state.allUsers.length === 0) {
      await dispatch('loadAllUsers');
    }

    let matchedUser = state.allUsers.filter(sUser => {
      return sUser.UserID === loginName;
    });
    commit('setCurrentUser', matchedUser);
    dispatch('loadCurrentUserAdminStatus');
    
    commit('stopLoading');
  },
  async loadCurrentUserAdminStatus({commit, rootState}){
    if (IsNullOrUndefined(state.hasPerms)) {
      let hasPerms = await sp.web.currentUserHasPermissions(PermissionKind.editListItems);
      commit('setHasPerms', hasPerms);
    }

    if (state.hasPerms){
      if  ((state.currentUser.BranchNumber === rootState.orgUnits.selectedOrgUnit.OrgUnitNumber
          || state.currentUser.SectionNumber === rootState.orgUnits.selectedOrgUnit.OrgUnitNumber 
          || state.currentUser.TeamNumber === rootState.orgUnits.selectedOrgUnit.OrgUnitNumber) //current userin same unit as the selected unit
          || state.currentUser.BranchNumber === state.selectedUser.BranchNumber ){ //or in same branch as selected user
        commit('setCurrentUserAdminStatus', true);
      }
      else{
        commit('setCurrentUserAdminStatus', false);
      }
    }
  },
  loadCurrentUserPreferences({commit}){
    if(!IsNullOrUndefined(localStorage.getItem("AECUserPreferences"))){
      let preferences = JSON.parse(localStorage.getItem("AECUserPreferences"))
      commit('setCurrentUserPreferences', preferences);
    } 
  },
  getUserGroups ({ commit, dispatch }) {
    commit('startLoading');
    return sp.web.currentUser.groups.get().then(groups => {
      commit("setUserGroups",groups);
      commit('stopLoading');
    })
    .catch(err => {
      commit('stopLoading');
    });
  },  
  //Load all users from the list
  async loadAllUsers({commit, dispatch, rootState}, userID){
    commit('startLoading');
    let users = await sp.web.lists.getByTitle("Corporate Directory Users").items.getAll()
    let sortedUsers = users.sort(function (a, b) {
      const aLastName = a.LastName.toLowerCase();
      const bLastName = b.LastName.toLowerCase();
      const aPreferredName = a.PreferredName.toLowerCase();
      const bPreferredName = b.PreferredName.toLowerCase();      

      if (aLastName < bLastName) return -1
      if (aLastName > bLastName) return 1 
      if (aLastName === bLastName) {
        if (aPreferredName < bPreferredName) return -1
        if (aPreferredName > bPreferredName) return 1 
      }     
      return 0
    });
    commit('setAllUsers', sortedUsers);
    let userSummary = [];
    sortedUsers.forEach(user =>{
      userSummary.push(user.PreferredName + " " + user.LastName);
    });
    dispatch('loadCurrentUser');
    commit('setSummaryUsers', sortedUsers);
    dispatch('loadExecutive');
    //dispatch('loadCurrentUser');
    //iterate users to derive branches todo: refactor this to depend on orgids from aurion rather than users
    if (users){
      users.forEach(user => {
        if (rootState.orgUnits.branchRefiners.indexOf(user.BranchState) === -1){
          //state.branchRefiners.push(user.BranchState);
          commit('setBranchRefiners', user.BranchState);
        }
        dispatch('setOrgUnitStructure', user);
      });
      if (userID) dispatch('loadSelectedUser', userID);
    }
    // console.log('done loading users');
    commit('stopLoading');            
  },
  async filterUsersByGenericJobTitle({}, users){
    
    let orgUnitFilteredUsers = users;

    let filterDirectors = state.specialFilters.filterJobtitles.filter(i => i.toLowerCase() === 'director').length > 0;
    let filterAssistantDirectors = state.specialFilters.filterJobtitles.filter(i => i.toLowerCase() === 'assistant director').length > 0;
    let filterCommissioners = state.specialFilters.filterJobtitles.filter(i => i.toLowerCase() === 'commissioner').length > 0;
    let filterAssistantCommissioners = state.specialFilters.filterJobtitles.filter(i => i.toLowerCase() === 'assistant commissioner').length > 0;

    //Do additional filtering based on Generic titles such as "Director"
    orgUnitFilteredUsers = orgUnitFilteredUsers.filter(user =>{
      let filterUser = false;
      let constainsDirector = user.JobTitle.toLowerCase().includes("director");
      let constainsCommissioner = user.JobTitle.toLowerCase().includes("commissioner");
      let constainsAssistant = user.JobTitle.toLowerCase().includes("assistant");
      let isDirector = constainsDirector && !constainsAssistant;            
      let isAssistantDirector = constainsDirector && constainsAssistant;
      let isCommissioner = constainsCommissioner && !constainsAssistant;
      let isAssistantCommissioner = constainsCommissioner && constainsAssistant;
      
      if (filterDirectors && isDirector) { filterUser = true; };
      if (filterAssistantDirectors && isAssistantDirector) { filterUser = true; };
      if (filterCommissioners && isCommissioner) { filterUser = true; };
      if (filterAssistantCommissioners && isAssistantCommissioner) { filterUser = true; }

      if (!filterUser) {
        return user;
      }
    });

    return orgUnitFilteredUsers;
  },
  async filterUsersByJobTitle({commit, dispatch}, users){
    let orgUnitFilteredUsers = users;
    let jobTitles = [];

    if (state.showAllAllowableJobTitles) {
      // get all possible job titles
      jobTitles = _.uniq(_.map(state.allUsers, 'JobTitle'));

      //add job titles specified in state.allowableFilterJobTitles as may contain generic Titles like Commissioner or Director
      state.allowableFilterJobTitles.forEach(item => {
        if (!jobTitles.includes(item)) {
          if (item.toLowerCase() !== 'all') {
            jobTitles.push(item);
          }
        }
      })
      
    } else {
      // get unique Jobtitles for filtered users
      jobTitles = _.uniq(_.map(orgUnitFilteredUsers, 'JobTitle'));
    }

    //sort ignoring case
    jobTitles = jobTitles.sort((a, b) => { return a.toLowerCase().localeCompare(b.toLowerCase()); });

    //restrict to allowable list of filter titles
    if (state.allowableFilterJobTitles.filter(i => i.toLowerCase() === 'all').length > 0) {
      //do nothing
    }
    else if (state.allowableFilterJobTitles.length > 0) {
      if (state.showAllAllowableJobTitles) {
        jobTitles = state.allowableFilterJobTitles.sort();
      } else {
        jobTitles = jobTitles.filter(jobTitle => state.allowableFilterJobTitles.includes(jobTitle));  
      }
    }
    else {
      jobTitles = [];
    }

    commit('setFilterJobtitles', jobTitles);

    orgUnitFilteredUsers = await dispatch('filterUsersByGenericJobTitle', orgUnitFilteredUsers); 

    //now filter users by JobTitle
    orgUnitFilteredUsers = orgUnitFilteredUsers.filter(user =>{
      if (!state.specialFilters.filterJobtitles.includes(user.JobTitle.toLowerCase())) {
        return user;
      }
    });

    return orgUnitFilteredUsers;

  },
  //Define the Executive group by querying allUsers for the isExecutive column
  async loadExecutive({commit, dispatch}){
    commit('startLoading');
    let executive = state.allUsers.filter(user => user.IsExecutive);
    //find and set the FASs          
    let commissioners = _.remove(executive, user => user.JobTitle.toLowerCase().indexOf("assistant commissioner") !== -1 && user.JobTitle.toLowerCase().indexOf("assistant to") === -1  && user.JobTitle.toLowerCase().indexOf("officer to") === -1);              
    commissioners.forEach(comm => {          
      executive.unshift(comm);       
    }); 
    //find and set the deputy commissioner
    let depCommissioner = _.remove(executive, user => user.JobTitle.toLowerCase() === "deputy electoral commissioner"); 
    if (depCommissioner.length > 0) { 
      executive.unshift(depCommissioner[0]);   
    }
    //find and set the commissioner
    let commissioner = _.remove(executive, user => user.JobTitle.toLowerCase() === "electoral commissioner");  
    if (commissioner.length > 0) {
      executive.unshift(commissioner[0]);  
    }

    executive = await dispatch('filterUsersByJobTitle', executive); 
    commit('setExecutive', executive);
    commit('stopLoading');
  },
  //Load all org units from the list
  async loadDisplayUsers({commit, rootState, dispatch}){
      commit('startLoading');
      let orgId = rootState.orgUnits.selectedOrgUnit.OrgUnitNumber;
      //Start by filtering users by org unit
      let orgUnitFilteredUsers = [];

      if(orgId){
        // filter users by Branch, section or team
        orgUnitFilteredUsers = state.allUsers.filter(user =>{
          if ((user.BranchNumber === orgId || user.SectionNumber === orgId || user.TeamNumber === orgId)){
            return user;
          }
        });

        orgUnitFilteredUsers = await dispatch('filterUsersByJobTitle', orgUnitFilteredUsers); 
        
        let orgLevel = rootState.orgUnits.selectedOrgUnit.OrgUnitLevel;
        //Set branch head or director to the manager field if it has been set
        if(!IsNullOrUndefined(rootState.orgUnits.selectedOrgUnitDetails.Manager)){
          if(orgLevel === 4){
            let branchHead = state.allUsers.filter(user => user.UserID === rootState.orgUnits.selectedOrgUnitDetails.Manager);
            commit('setBranchHead', branchHead[0]);
          }
          else if(orgLevel === 5){
            let director = state.allUsers.filter(user => user.UserID === rootState.orgUnits.selectedOrgUnitDetails.Manager);
            commit('setDirector', director[0]);
          }
          else if(orgLevel === 6){
            let teamLeader = state.allUsers.filter(user => user.UserID === rootState.orgUnits.selectedOrgUnitDetails.Manager);
            commit('setTeamLeader', teamLeader[0]);
          }
        }
        //otherwise we will try to determine the org unit head programatically
        else{
          if(orgLevel === 4){
            dispatch('loadBranchHead', orgId);
          }
          else if(orgLevel === 5){
            dispatch('loadDirector', orgId);
          }
        }
        
        //set the bpo
        if(!IsNullOrUndefined(rootState.orgUnits.selectedOrgUnitDetails.BPO)){
          let bpo = state.allUsers.filter(user => user.UserID === rootState.orgUnits.selectedOrgUnitDetails.BPO);
          commit('setBranchProjectOfficer', bpo[0]);
        } else {
          dispatch('loadBPO', orgId);
        }     
        
        let directors = _.remove(orgUnitFilteredUsers, user => user.JobTitle.toLowerCase().indexOf("director") !== -1 && user.JobTitle.toLowerCase().indexOf("assistant") === -1); 
        directors = _.reverse(directors);             
        directors.forEach(dir => {          
          orgUnitFilteredUsers.unshift(dir);       
        }); 
      }
      
      //then filter users by the search query
      let usersArray = []
      let searchFilteredUsers = [];
      //Check if we are filtering by orgunit, and if we have found any matching users for the org unit
      if(orgUnitFilteredUsers.length) { 
        usersArray = orgUnitFilteredUsers
      }
      else if(!orgId){
        usersArray = state.allUsers
      }
      //filter by the search string if we don't have a selected org unit
      if(state.searchQuery !== "" && !orgId){
        //console.log("loadDisplayUsers have a search query");
        //(orgUnitFilteredUsers.length) ? usersArray = orgUnitFilteredUsers : usersArray = state.allUsers;
        searchFilteredUsers = usersArray.filter(user => {
          let fullName = user.PreferredName.toLowerCase() + " " + user.LastName.toLowerCase();
          if(user.FirstName.toLowerCase().indexOf(state.searchQuery.toLowerCase()) > -1 ||
            user.LastName.toLowerCase().indexOf(state.searchQuery.toLowerCase()) > -1 ||
            user.PreferredName.toLowerCase().indexOf(state.searchQuery.toLowerCase()) > -1 ||
            user.JobTitle.toLowerCase().indexOf(state.searchQuery.toLowerCase()) > -1 ||
            fullName.indexOf(state.searchQuery.toLowerCase()) > -1
            ){
              //console.log("loadDisplayUsers found a user that matches the search term");
              return user;
            }
          // return state.selectProperties.some(function(key) {
          //     if (state.freetextSearchFields.indexOf(key) > -1){
          //       console.log("loadDisplayUsers found a user that matches the search term");
        
                  //return user[key] && user[key].toLowerCase().indexOf(state.searchQuery.toLowerCase()) >- 1;
          //     }
          // })
        });
      }
      else{
        searchFilteredUsers = usersArray;
        //console.log("loadDisplayUsers no search term");
      }

      //Set the users we want to display based on org unit and search string
      commit('setDisplayUsers', searchFilteredUsers);
      commit('stopLoading');
      
  },
  getManagementHierarchy({commit, dispatch}, userID){
    let management = [];
    let currentUserID = userID;

    while (!IsNullOrUndefined(currentUserID)) {
      let user = null;
      const users = state.allUsers.filter(user => user.UserID === currentUserID);
      if (users.length) {
        user = users[0];

        // const managers = state.allUsers.filter(m => `${m.PreferredName} ${m.LastName}`.toLowerCase() === (user.Manager || '').toLowerCase());
        const managers = state.allUsers.filter(m => m.UserID === (user.ManagerId || '').toLowerCase());
        currentUserID = null;
        if (managers.length > 0){
          currentUserID = managers[0].UserID;
          management.push(managers[0]);
        }
      }
      else {
        currentUserID = null;
      }
    }

    return management;
  },
  getUserById({commit}, userID){
    let user;
    const users = state.allUsers.filter(user => user.UserID === userID);
    if (users.length > 0) {
      user = users[0];
    }

    return user;
  },
  //Load the selected user
  loadSelectedUser({commit, dispatch}, userID){
      commit('startLoading');
      commit('setSelectedUser');
      commit('setDirectReports');
      commit('setPeers');
      if(!state.allUsers.length){
        dispatch('loadAllUsers', userID)
      }
      else{
        let user = state.allUsers.filter(user => user.UserID === userID);
        if(user.length){
          commit('setSelectedUser', user[0]);
          dispatch('loadColleagues', user[0]);
        }
      }
      
      commit('stopLoading');
  },
  loadOrgChartExecutive({commit, dispatch}, level1){
    let newStructure = { structure: [], selected: [], titles: [] };
    let people = [];

    state.executiveStructure.forEach(ExecLevel => {
      newStructure.titles.push(ExecLevel.OrgChartTitle);

      if (ExecLevel.matchExact){
        //find by JobTitile Exact
        people = state.allUsers.filter(i => ExecLevel.jobTitles.includes(i.JobTitle.toLowerCase()));
      } else {
        //find if Job title is contained within the users title
        people = state.allUsers.filter(i => {
          const items = ExecLevel.jobTitles.filter(jt => i.JobTitle.toLowerCase().includes(jt));
          return items.length > 0;
        });
      }

      //exclude people that have particular value in their title
      if (ExecLevel.jobTitleExclude !== '') {
        people = people.filter(i => !i.JobTitle.toLowerCase().includes(ExecLevel.jobTitleExclude.toLowerCase()));
      }

      if (ExecLevel.filterStates) {
        const AusStatesLC = state.AusStates.map(i => i.toLowerCase());
        people = people.filter(i => !AusStatesLC.includes(i.Branch.toLowerCase()));
      }

      newStructure.structure.push(people);
      if (people.length === 1) {
        newStructure.selected.push(people[0].UserID);
      } else {
        newStructure.selected.push("");
      }
    })

    commit('setOrgStructure', newStructure);
  },
  getManager({commit, dispatch}, user){
    // const managers = state.allUsers.filter(m => `${m.PreferredName} ${m.LastName}`.toLowerCase() === (user.Manager || '').toLowerCase());
    const managers = state.allUsers.filter(m => m.UserID === (user.ManagerId || '').toLowerCase());

    return managers.length > 0 ? managers[0] : null;
  },
  async loadOrgChart({commit, dispatch}, level1){
    let topperson;
    let newStructure = { structure: [], selected: [], titles: [] };
    let l1 = [];

    if (IsNullOrUndefined(level1)) {
      topperson = state.allUsers.filter(i => {
        return IsNullOrUndefined(i.Manager) && i.JobTitle.toLowerCase() === state.executiveStructure[0].jobTitles[0].toLowerCase();
      })[0];
    }
    else {
      topperson = state.allUsers.filter(i => i.UserID === level1)[0];
    }

    if (topperson) {
      l1.push(topperson);
      newStructure.structure.push(l1);

      let orgTitle = topperson.Team || topperson.Section || topperson.Div || topperson.Branch;
      const manager = await dispatch('getManager', topperson);

      // console.log('topUser manager', manager);

      if (manager){
        const isManagerFAS = manager.JobTitle.toLowerCase().indexOf("first assistant commissioner") !== -1;
        if (isManagerFAS){
          orgTitle = topperson.Branch;
        }      
      }

      newStructure.titles.push({ title: orgTitle, displayTitle: orgTitle });
      // console.log("loadOrgChart Structure ", JSON.stringify(newStructure));
      commit('setOrgStructure', newStructure);
      dispatch('OrgChartUserSelect', { person: topperson, level: 0})
    }
  },
  async OrgChartUserSelect({commit, dispatch}, payload) {
    let newStructure = _.clone(state.orgChart);

    if (!newStructure.selected.includes(payload.person.UserID)) {      
      newStructure.selected.length = payload.level;
      newStructure.selected.push(payload.person.UserID);

      newStructure.titles.length = payload.level;

      let orgTitle = payload.person.Team || payload.person.Section || payload.person.Div || payload.person.Branch;
      const manager = await dispatch('getManager', payload.person);

      // console.log('payload.person manager', manager);

      if (manager){
        const isManagerFAS = manager.JobTitle.toLowerCase().indexOf("first assistant commissioner") !== -1;
        if (isManagerFAS){
          orgTitle = payload.person.Branch;
        }      
      }

      newStructure.titles.push({ title: orgTitle, displayTitle: orgTitle });
      commit('setOrgStructure', newStructure);

      let newPayload = _.clone(payload);
      newPayload.level++;
      dispatch('loadOrgChartLevel', newPayload);
    }
  },
  loadOrgChartLevel({commit}, payload) {

    let newStructure = _.clone(state.orgChart);
    newStructure.structure.length = payload.level;
    const Manager = `${payload.person.PreferredName} ${payload.person.LastName}`.toLowerCase();

    let people = state.allUsers.filter(i => {
      return (i.Manager || '').toLowerCase() === Manager
    });

    //Move first assistant commissioners to the top
    let fsas = _.remove(people, user => user.JobTitle.toLowerCase().indexOf("first assistant commissioner") !== -1); 
    fsas = _.reverse(fsas);             
    fsas.forEach(fas => {          
      people.unshift(fas);       
    });     

    newStructure.structure.push(people);
    commit('setOrgStructure', newStructure);
  },
  loadColleagues({commit}, user){
      let peers = [];
      let directReports = [];      
      sp.profiles.getPropertiesFor("PROD\\" + user.UserID).then(function(result) {
        if(!IsNullOrUndefined(result.Peers) && result.Peers.results.length){
          if(result.Peers.results){
            let count = 0;
            result.Peers.results.forEach(peer => {
                sp.profiles.getPropertiesFor(peer).then(function(result3) {
                  count ++;
                  if(result3.DisplayName.indexOf("(") === -1 && result3.DisplayName.indexOf("_") === -1){
                    let accountName = result3.AccountName.replace("PROD\\","");
                    let peerObj = {
                        name: result3.DisplayName, 
                        accountName: accountName, 
                        picture: result3.PictureUrl, 
                        jobTitle: result3.Title
                    }
                    peers.push(peerObj);
                    if (count === result.Peers.results.length) {
                      let sortedPeers = peers.sort(function (a, b) {
                        if (a.name < b.name) return -1
                        if (a.name > b.name) return 1
                        return 0
                      });
                      commit('setPeers', sortedPeers);
                    }   
                  }        
                });
            });
          }
        }
        if(result.DirectReports.results.length){
          if(result.DirectReports.results){
            let count = 0;
            result.DirectReports.results.forEach(directReport => {
                sp.profiles.getPropertiesFor(directReport).then(function(result4) {
                  count ++;
                  //Some account have
                  if(result4.DisplayName.indexOf("(") === -1 && result4.DisplayName.indexOf("_") === -1){
                    let accountName = result4.AccountName.replace("PROD\\","");
                    let reportsObj = {
                        name: result4.DisplayName, 
                        accountName: accountName, 
                        picture: result4.PictureUrl, 
                        jobTitle: result4.Title
                    }
                    directReports.push(reportsObj);
                    if (count === result.DirectReports.results.length) {
                      let sortedReports = directReports.sort(function (a, b) {
                        if (a.name < b.name) return -1
                        if (a.name > b.name) return 1
                        return 0
                      });
                      commit('setDirectReports', sortedReports)
                    }
                  }
                });
            });  
          }
          else{
          }
        }          
      });
  },
  async loadBranchHead({commit, dispatch}, orgUnitNumber){
    const branchHead = await dispatch('getDefaultBranchHead', orgUnitNumber);
    commit('setBranchHead', branchHead);
  },
  async loadBPO({commit, dispatch}, orgUnitNumber){
    const branchProjectOfficer = await dispatch('getDefaultBSO', orgUnitNumber);
    commit('setBranchProjectOfficer', branchProjectOfficer);
  },  
  async loadDirector({commit, dispatch}, orgUnitNumber){
    const director = await dispatch('getDefaultDirector', orgUnitNumber);
    commit('setDirector', director);
  },
  getDefaultBranchHead({}, orgUnitNumber) {
    let branchHead = state.allUsers.filter(user => {
      if(!IsNullOrUndefined(user.JobTitle)){
        return ((user.JobTitle.toLowerCase().indexOf("commissioner") !== -1 || user.JobTitle.toLowerCase().indexOf("chief legal") !== -1 || user.JobTitle.toLowerCase().indexOf("state manager") !== -1 ) && user.BranchNumber === orgUnitNumber) ? true : false;
      }
    });
    return branchHead[0];
  },
  getDefaultBSO({}, orgUnitNumber) {
    let branchProjectOfficer = state.allUsers.filter(user => {
      if(!IsNullOrUndefined(user.JobTitle)){
        return (user.JobTitle.toLowerCase() === "branch project officer" && user.BranchNumber === orgUnitNumber) ? true : false;
      }
    });    
    return branchProjectOfficer[0];
  },
  getDefaultDirector({}, orgUnitNumber) {
    let director = state.allUsers.filter(user => {
      if(!IsNullOrUndefined(user.JobTitle)){
        if(user.SectionNumber === orgUnitNumber){
          //console.log(user.JobTitle.toLowerCase());
          if (user.JobTitle.toLowerCase().indexOf("director") !== -1 && user.JobTitle.toLowerCase().indexOf("assistant") === -1){
            return true
          }
          else{
            return false
          }
        }  
      }
    });
    return director[0];
  },
  //Load quick contacts from local storage todo: save data to list, and retrieve from there
  loadFavourites({commit}){
    commit('startLoading');
    if(!IsNullOrUndefined(localStorage.getItem("PeopleSearchFavourites"))){
      let favourites = JSON.parse(localStorage.getItem("PeopleSearchFavourites"))
      commit('setfavourites', favourites);
    }     
    commit('stopLoading');
  },
  loadSpecialFiltersSettings({commit}){
    commit('startLoading');
    if(!IsNullOrUndefined(localStorage.getItem("PeopleSearchSpecialFiltersSettings"))){
      let filters = JSON.parse(localStorage.getItem("PeopleSearchSpecialFiltersSettings"))
      commit('setSpecialFilters', filters);
    } else {
      commit('setSpecialFilters', state.defaults.specialFilters);
    }
    commit('stopLoading');
  },
  toggleJobtitlesFilter({commit, dispatch}, filter) {
    commit('startLoading');
    let newFilters = JSON.parse(JSON.stringify(state.specialFilters)); //clone Object

    if (newFilters.filterJobtitles.includes(filter.toLowerCase())) {
      newFilters.filterJobtitles = newFilters.filterJobtitles.filter(item => item != filter.toLowerCase());
    } else {
      newFilters.filterJobtitles.push(filter.toLowerCase());
    }
    commit('setSpecialFilters', newFilters);
    dispatch('loadDisplayUsers');
    dispatch('loadExecutive');
    
    commit('stopLoading');    
  },
  bulkAddJobtitlesFilter({commit, dispatch}, items) {
    commit('startLoading');
    let newFilters = JSON.parse(JSON.stringify(state.specialFilters)); //clone Object

    items.forEach(item => {
      if (!newFilters.filterJobtitles.includes(item.toLowerCase())) {
        newFilters.filterJobtitles.push(item.toLowerCase());
      }
    })

    commit('setSpecialFilters', newFilters);
    dispatch('loadDisplayUsers');
    dispatch('loadExecutive');
    commit('stopLoading');    
  },
  bulkRemoveJobtitlesFilter({commit, dispatch}, items) {
    commit('startLoading');
    let newFilters = JSON.parse(JSON.stringify(state.specialFilters)); //clone Object

    items.forEach(item => {
      if (newFilters.filterJobtitles.includes(item.toLowerCase())) {
        newFilters.filterJobtitles  = newFilters.filterJobtitles.filter(i => i != item.toLowerCase());
      }
    })

    commit('setSpecialFilters', newFilters);
    dispatch('loadDisplayUsers');
    dispatch('loadExecutive');
    commit('stopLoading');    
  },  
  cleanJobTitleFilters({commit, dispatch}) {
    //We need to clean up filtered jobTitle if the allowableFilterJobTitles have changed since the last page load
    if (state.allowableFilterJobTitles.filter(i => i.toLowerCase() === 'all').length === 0) {
      let filters = JSON.parse(JSON.stringify(state.specialFilters)); //clone Object
      filters.filterJobtitles = [];
      //in here because not all JobTitles are filterable, so we need to ensure that only AllowableFilteredJobTitles are being Filtered
      state.allowableFilterJobTitles.forEach(item => {
        if (state.specialFilters.filterJobtitles.includes(item.toLowerCase())) {
          // newFilters.filterJobtitles  = newFilters.filterJobtitles.filter(i => i != item.toLowerCase());
          filters.filterJobtitles.push(item.toLowerCase());
        }
      })

      if (state.specialFilters.filterJobtitles.length !== filters.filterJobtitles.length) {
        commit('setSpecialFilters', filters);
      }
    }
  },
  // add user to favourite users
  toggleFavourite({commit}, fav) {
      commit('startLoading');
      if(state.favourites.find( user => user.UserID === fav.UserID)){
          commit('removeUserFromFavourites', fav);
      }
      else{
          commit('addUserToFavourites', fav)
      }
      commit('stopLoading');
  },
  
  fieldSorter(fields) {
    return function (a, b) {
      return fields
        .map(function (o) {
          var dir = 1;
          if (o[0] === '-') {
            dir = -1;
            o=o.substring(1);
          }
          if (a[o] > b[o]) return dir;
          if (a[o] < b[o]) return -(dir);
          return 0;
        })
        .reduce(function firstNonZeroValue (p,n) {
          return p ? p : n;
        }, 0);
    };
  },
  async loadSearchQuery({commit}, query){
    commit('startLoading');
    (query) ?  await commit('setSearchQuery', query) : await commit('setSearchQuery');
    commit('stopLoading');
  },
  loadDisplayMode({commit}, setting){
    commit('startLoading');
    if(setting === 0 || setting === 1){
      localStorage.setItem("PeopleSearchDisplayMode", setting);
      commit('setDisplayMode', setting);
    }
    else{
      let storedSetting = localStorage.getItem("PeopleSearchDisplayMode");
      commit('setDisplayMode', parseInt(storedSetting));
    }
    commit('stopLoading');
  },
  async loadConfigurableContent({commit, dispatch}){
    commit('startLoading');
    let helpItems = [];
    let configItems = [];

    let configListItems = await sp.web.lists.getByTitle("Configuration").items.getAll();
    configListItems.forEach(item =>{
      //help Items
      if(item.Title.indexOf("PeopleSearch - ") !== -1){
        let key = item.Title.replace("PeopleSearch - ","");
        let newObj = {
          [key]: item.ConfigValue
        }
        helpItems.push(newObj);
      } 

      //Other Configuration Items
      if(item.Title.indexOf("PeopleSearchConfig - ") !== -1){
        let key = item.Title.replace("PeopleSearchConfig - ","");
        let data;
        try {
          data = JSON.parse(item.ConfigValue);
        } catch (e) {
          // not json data so just the raw data
          data = item.ConfigValue;
        }
        switch(key){
          case 'AllowableFilterJobTitles' : 
            commit('setAllowableFilterJobTitles', data);
            dispatch('cleanJobTitleFilters');
            break;
          default: 
            let newObj = {
              [key]: data
            }
            configItems.push(newObj);          
            break;
        }
      } 
    })
    
    commit('setHelpContent', helpItems);
    commit('setConfigItems', configItems);
    commit('stopLoading');
  },
  async updateUser({commit, dispatch}, user) {

    // console.log('updateUser user:',user);
    let saveLocationObj = {
      State: user.State,
      LocationBuilding: user.LocationBuilding,
      LocationFloor: user.LocationFloor,
      LocationWorkstation: user.LocationWorkstation,
      LocationImage: user.LocationImage,
      LocationX: user.LocationX,
      LocationY: user.LocationY
    }
    await sp.web.lists.getByTitle("Corporate Directory Users").items.getById(user.Id).update(saveLocationObj);
    const updateduser = await sp.web.lists.getByTitle("Corporate Directory Users").items.getById(user.Id).get();

    //replace the existing user with the updated user
    const updatedUsers = state.allUsers.map(user => {
      if (user.UserID !== updateduser.UserID) {
        return user;
      } else {
        return updateduser;
      }
    });

    commit('setAllUsers', updatedUsers);    
  },

  //
  // Taxonomy Functions
  //
  cleanGuid({ commit, state, dispatch }, payload) {
    if (payload !== undefined) {
        return payload.replace('/Guid(', '').replace('/', '').replace(')', '');
    } else {
        return '';
    }
  },
  async getTaxonomyTerms({ commit, state, dispatch }, payload) {
    try {
      let newTaxonomySources = Object.assign({},state.taxonomySources);

      const allTermIdCached = newTaxonomySources.termStore.Id && newTaxonomySources.termGroup.Id && newTaxonomySources.termSet.Id;
      if (!allTermIdCached) {

        // Term Store
        let termStore = await taxonomy.termStores.getByName(newTaxonomySources.termStore.name).get();
        const termStoreId = await dispatch('cleanGuid', termStore.Id);        
        newTaxonomySources.termStore.Id = termStoreId;

        // Term Group
        let termGroup = await termStore.groups.getByName(newTaxonomySources.termGroup.name).get();
        const termGroupId = await dispatch('cleanGuid', termGroup.Id);
        newTaxonomySources.termGroup.Id = termGroupId;
          
        // Term Set
        let termSet = await termGroup.termSets.getByName(newTaxonomySources.termSet.name).get();
        const termSetId = await dispatch('cleanGuid', termSet.Id);
        newTaxonomySources.termSet.Id = termSetId;

        // Update taxonl=omy object with Id's
        commit("setTaxonomySources", newTaxonomySources);
      }
      
      let values = await dispatch('getTaxonomy',{termstoreId: newTaxonomySources.termStore.Id, termsetId: newTaxonomySources.termSet.Id});

      // console.log('values',values)

      // map to a more useable (simpler) structure
      let newVals = await dispatch('mapTaxonomy', values);

      commit("setLocations", newVals);
    }
    catch(err) {
      // self.addError(err, "getting 'Divisions' data from termstore")
      console.error(err);
    }
  },

  async mapTaxonomy({ dispatch }, payload){
    let mappedValues = await Promise.all(payload.map(async item => {
      const _children = await dispatch('mapTaxonomy', item.children)
      const obj = {
        value: item.label, 
        text: item.label,
        LocalCustomProperties: item.LocalCustomProperties,
        children: _children
      }
      
      return obj;
    }));

    return mappedValues;
  },

  async getTaxonomy( { dispatch }, payload) {

    const _store = await taxonomy.termStores.getById(payload.termstoreId); //Store 
    const _termset = await _store.getTermSetById(payload.termsetId).get(); 
    const terms = await _termset.terms.select('Id', 'Name', 'Parent', 'PathOfTerm', 'IsRoot', 'LocalCustomProperties').get();
    
    let newTerms = terms;
    newTerms = await Promise.all(terms.map(async (term) => {
      term.Id = await dispatch('cleanGuid', term.Id); ///self.cleanGuid(term.Id);       
      term.Name = term.Name;
      term.label = term.Name;

      term['PathDepth'] = term.PathOfTerm.split(';').length;
      const termsetId = await dispatch('cleanGuid', _termset.Id); 
      term.TermSet = { Id: termsetId, Name: _termset.Name };

      if (term["Parent"]) {
        term.ParentId = await dispatch('cleanGuid', term["Parent"].Id);  
      }
      return term;
    }));

    // RootNodes
    const parents = newTerms.filter(t => t.IsRoot);
    // Children of RootNodes
    const children = newTerms.filter(t => t.IsRoot === false);
    // Check if has children
    parents.forEach(async parentTerm => {
      await dispatch('_checkIfChildren', {items: children, term: parentTerm});  
    })

    return parents;
  },

  async _checkIfChildren( { commit, state, dispatch }, payload) {
    const children = [];

    // Loop through and check if parentId equal to parent.Id
    payload.items.forEach(async i => {
      if (i.ParentId == payload.term.Id) {
        // Found a child, push
        children.push(i);
        // Remove this term from items and recurr
        await dispatch('_checkIfChildren', {items: payload.items.filter(item => item !== i), term: i}); 
      }
    })
    payload.term.children = children;
  },  
}

//mutations
const mutations = {
  setInitialised(state, value){
    state.initialised = value;
  },
  setHasPerms(state, hasPerms){
    state.hasPerms = hasPerms;
  },
  setCurrentUser(state, user){
      (user[0]) ? state.currentUser = user[0] : state.currentUser = {};
  },
  setCurrentUserAdminStatus(state, isAdmin){
    (isAdmin) ? state.currentUserIsAdmin = true : state.currentUserIsAdmin = false;
  },
  setCurrentUserPreferences(state, preferences){
    (preferences) ? state.currentUserPreferences = preferences : state.currentUserPreferences = {};
  },
  setOrgUnitUsers(state, orgUnitUsers){
      orgUnitUsers ? state.orgUnitUsers = orgUnitUsers : state.orgUnitUsers = [];
      orgUnitUsers ? state.displayUsers = orgUnitUsers : state.displayUsers = [];
  },
  setAllowableFilterJobTitles(state, jobTitles){
    state.allowableFilterJobTitles = jobTitles;
  },
  setAllUsers(state, users){
    users ?  state.allUsers = users : state.allUser = [];
    // users ?  state.userSummary = users : state.userSummary = [];
  },
  setSummaryUsers(state, users){
    // users ?  state.allUsers = users : state.allUser = [];
    users ?  state.userSummary = users : state.userSummary = [];
  },
  setExecutive(state, executive){
    executive ?  state.executive = executive : state.executive = [];
  },
  setDisplayUsers(state, users){
      (users) ? state.displayUsers = users : state.displayUsers = [];
  },
  setSelectedUser(state, user){
      if(user) state.selectedUser = user;
      else state.selectedUser = {};
  },
  setPeers(state, peers){
      if(peers) state.peers = peers;
      else state.peers = [];
  },
  setDirectReports(state, reports){
      if(reports) state.directReports = reports;
      else state.directReports = [];
  },
  setfavourites(state, favourites){
      state.favourites = favourites;
  },
  setFilterJobtitles(state, jobTiltes){
    state.filterJobtitles = jobTiltes;
  },
  setSpecialFilters(state, filter){
    state.specialFilters = filter;
    localStorage.setItem("PeopleSearchSpecialFiltersSettings", JSON.stringify(state.specialFilters));
  },
  addUserToFavourites(state, user){
      state.favourites.push(user);
      localStorage.setItem("PeopleSearchFavourites", JSON.stringify(state.favourites));
  },
  removeUserFromFavourites(state, user){
      let newContacts = state.favourites.filter(function( u ) {
          return u.UserID !== user.UserID;
      });
        //= state.favourites.filter(c => {c.UserID !== user.UserID});
      state.favourites = newContacts;
      localStorage.setItem("PeopleSearchFavourites", JSON.stringify(state.favourites));
  },
  setSearchQuery(state, query){
    
    if (query){
      state.searchStrings = query;
      //console.log('searchStrings has changed');
    }
    else{
      state.searchStrings = {
        firstName: '',
        lastName: '',
        jobtitle: '',
        orgUnitTitle: '',
        orgUnitDescription: ''
      }
      //console.log('searchStrings has changed and is empty');
    } 
  },
  setDisplayMode(state, setting){
    (setting) ? state.displayMode = setting : state.displayMode = 0;
  },
  setHelpContent(state, items){
    let newItems = {};
    items.forEach(function(item, i){
      let key = Object.keys(items[i])[0];
      let value = Object.values(items[i])[0]
      newItems[key] = value
    });
    (items) ? state.helpContent = newItems : state.helpContent = {};
  },
  setConfigItems(state, items){
    let newItems = {};
    items.forEach(function(item, i){
      let key = Object.keys(items[i])[0];
      let value = Object.values(items[i])[0]
      newItems[key] = value
    });
    (items) ? state.configItems = newItems : state.configItems = {};
  },
  setOrgStructure(state, org){
    /*console.log('setOrgStructure: ', org);
    let msg = "   People: "
    org.selected.forEach(selPerson => {
      msg += `${selPerson}; `
    });
    console.log(msg);

    msg = "    Titles: ";
    org.titles.forEach(title =>  {
      msg += `${title.displayTitle}; `
    });
    console.log(msg);

    
    org.structure.forEach((users, index) => {
      console.log(`  structure level (${index})`);
      msg = "    Users: ";
      users.forEach(user => {
        msg += `${user.UserID}; `
      });
      console.log(msg);
    });*/

    state.orgChart = org;
  },
  setTaxonomySources(state, value) {
    state.taxonomySources = value; 
  },
  setLocations(state, value) {
    state.Locations = value; 
  },
  setUserGroups(state, value) {
    state.userGroups = value; 
  },
}

export default{
  state,
  getters,
  actions,
  mutations
}