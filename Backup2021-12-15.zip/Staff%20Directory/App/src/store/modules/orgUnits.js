import { sp } from "@pnp/sp";

// initial state
const state = {
  selectedOrgUnit: {},
  selectedOrgUnitDetails: {},
  selectedOrgUnitChildren: [],
  orgUnitHead: {},
  branchHead: {},
  branchProjectOfficer: {},
  director: {},
  teamLeader: {},
  orgUnitDirectors: [],
  branchRefiners: [],
  loading: false,
  branches: [],
  sections: [],
  teams: [],
  allOrgUnits: [],
  allOrgUnitDetails: [],
  execOrgUnit: {},
  execOrgUnitDetails: {}
}

// getters
const getters = {
  selectedOrgUnit: state => state.selectedOrgUnit,
  selectedOrgUnitDetails: state => state.selectedOrgUnitDetails,
  // selectedOrgUnitDescription: state => state.selectedOrgUnitDetails.UnitDescription,
  selectedOrgUnitChildren: state => state.selectedOrgUnitChildren,
  orgUnitHead: state => state.orgUnitHead,
  branchHead: state => state.branchHead,
  branchProjectOfficer: state => state.branchProjectOfficer,
  director: state => state.director,
  teamLeader: state => state.teamLeader,
  orgUnitDirectors: state => state.orgUnitDirectors,
  branchRefiners: state => state.branchRefiners,
  loading: state => state.loading,
  branches: state => state.branches,
  sections: state => state.sections,
  teams: state => state.teams,
  allOrgUnits: state => state.allOrgUnits,
  allOrgUnitDetails: state => state.allOrgUnitDetails,
  execOrgUnit: state => state.execOrgUnit,
  execOrgUnitDetails: state => state.execOrgUnitDetails
}

//actions
const actions = {
  async setSelectedOrgUnit({commit, dispatch}, orgId){
      commit('startLoading');
      commit('setOrgUnitDirectors');
      commit('setOrgUnitHead');
      commit('setSelectedOrgUnit');
      await dispatch('setSelectedOrgUnitDetails', orgId);
      if(!IsNullOrUndefined(orgId)){
        let orgUnit = state.allOrgUnits.filter(unit => {
          return unit.OrgUnitNumber.toString() === orgId;
        })
        dispatch('setSelectedOrdUnitChildren',orgUnit[0].OrgUnitNumber);        
        commit('setSelectedOrgUnit', orgUnit[0]);
        commit('setSelectedUser');
        commit('setBranchProjectOfficer');
        commit('setTeamLeader');
        let orgLevel = state.selectedOrgUnit.OrgUnitLevel;
        if(orgLevel === 3){
          //dispatch('loadCommissioner')
        }
        else if(orgLevel === 4){
          //dispatch('loadBranchHead')
        }
        else if(orgLevel === 5){
          //dispatch('loadDirector');
        }
        dispatch('loadDisplayUsers');
        commit('stopLoading');
      }
      else{
        dispatch('loadDisplayUsers');
      }
  },
  async setSelectedOrgUnitDetails({commit, dispatch}, orgId){
    commit('startLoading');

    if(!IsNullOrUndefined(orgId)){
      const orgUnitDetails = state.allOrgUnitDetails.find(unit => {
        return unit.OrgUnitNumber.toString() === orgId;
      })
      commit('setSelectedOrgUnitDetails', orgUnitDetails);
      commit('stopLoading');
    }
    else{
      commit('setSelectedOrgUnitDetails');
    }
  },
  setSelectedOrdUnitChildren({commit}, orgUnitNumber){
    let orgUnitChildren = state.allOrgUnits.filter(unit => unit.ParentOrganisationUnit === orgUnitNumber);
    commit('setSelectedOrgUnitChildren',orgUnitChildren);
  },
  async loadAllOrgUnits({commit, dispatch}, orgId){
      commit('startLoading');
      // console.log('loadAllOrgUnits', orgId)
      let results = await sp.web.lists.getByTitle("Corporate Directory Org Units").items.orderBy('Title').getAll()
      //sp.web.lists.getByTitle("Corporate Directory Org Units").items.orderBy('Title').getAll().then(results => {
      let sortedUnits = results.sort(function(a,b){
        if (a.Title > b.Title) {
          return 1;
        }
        if (b.Title > a.Title) {
          return -1;
        }
        return 0;
      })
      commit('setAllOrgUnits', sortedUnits);
      await dispatch('loadAllOrgUnitsDetails', orgId); 
      dispatch('setExecOrgUnit');      
      //console.log('done loading org units');
      if (orgId){
        dispatch('setSelectedOrgUnit', orgId);
      }
      
      commit('stopLoading');
  },
  async loadAllOrgUnitsDetails({commit, dispatch}, orgId){
    commit('startLoading');
    let results = await sp.web.lists.getByTitle("Corporate Directory Org Units Details").items.orderBy('Title').top(2000).get();
    commit('setAllOrgUnitDetails', results); 
    dispatch('setExecOrgUnitDetails'); 
    if (orgId){
      await dispatch('setSelectedOrgUnitDetails', orgId);
    }
    commit('stopLoading');
},
async saveOrgUnitDetails({commit, dispatch}, saveInfo){
  commit('startLoading');

  // console.log('saveOrgUnitDetails', saveInfo);
  let defaultManager = undefined;
  let defaultBSO = undefined;
  const orgId = state.selectedOrgUnit.OrgUnitNumber;
  const orgLevel = state.selectedOrgUnit.OrgUnitLevel;
  if(orgLevel === 4){
    defaultManager = await dispatch('getDefaultBranchHead', orgId);
    defaultBSO = await dispatch('getDefaultBSO', orgId);    
  }
  else if(orgLevel === 5){
    defaultManager = await dispatch('getDefaultDirector', orgId);
  }

  const saveManagerID = !defaultManager || defaultManager !== saveInfo.Manager ? saveInfo.Manager.UserID : null;
  const saveBPO_ID = !defaultBSO || defaultBSO !== saveInfo.BPO ? saveInfo.BPO.UserID : null;
  
  const saveOject = {
    Title: state.selectedOrgUnit.Title, //update the title to match the corresponding Unit Title
    OrgUnitNumber: orgId,
    UnitDescription: saveInfo.UnitDescription,
    BPO: saveBPO_ID,
    Manager: saveManagerID
  }

  // console.log('saveOject', state.selectedOrgUnitDetails.ID, saveOject);

  if (state.selectedOrgUnitDetails && state.selectedOrgUnitDetails.ID) {
    await sp.web.lists.getByTitle("Corporate Directory Org Units Details").items.getById(state.selectedOrgUnitDetails.ID).update(saveOject);
      // .then(result => {
      //   commit('setSelectedOrgUnitDescription', saveInfo.UnitDescription);
      // });
  } else {
    await sp.web.lists.getByTitle("Corporate Directory Org Units Details").items.add(
      saveOject
    ).then(async () => {
      await dispatch('loadAllOrgUnitsDetails', state.selectedOrgUnit.ID.toString());
    });
  }

  commit('setSelectedOrgUnitDescription', saveInfo.UnitDescription);
  commit('setOrgUnitHead', saveInfo.Manager);
  commit('setBranchProjectOfficer', saveInfo.BPO);

  commit('stopLoading');
},
// async saveOrgUnitDescription({commit, dispatch}, description){
//     commit('startLoading');

//     if (state.selectedOrgUnitDetails.ID) {
//       await sp.web.lists.getByTitle("Corporate Directory Org Units Details").items.getById(state.selectedOrgUnitDetails.ID).update({
//         Title: state.selectedOrgUnit.Title,  //update the title to match the corresponding Unit Ttle
//         UnitDescription: description
//       }).then(result => {
//         commit('setSelectedOrgUnitDescription', description);
//       });
//     } else {
//       await sp.web.lists.getByTitle("Corporate Directory Org Units Details").items.add({        
//         Title: state.selectedOrgUnit.Title,  
//         UnitDescription: description,
//         OrgUnitNumber: state.selectedOrgUnit.OrgUnitNumber
//       }).then(result => {
//         dispatch('loadAllOrgUnitsDetails', state.selectedOrgUnit.orgId);
//       });
//     }

//     commit('stopLoading');
//   },
  setExecOrgUnit({commit}){
    commit('startLoading');
    let execOrgUnit = state.allOrgUnits.filter(unit => unit.Title === "Executive");
    commit('setExecOrgUnit',execOrgUnit[0]);
    commit('stopLoading');
  },
  setExecOrgUnitDetails({commit}){
    commit('startLoading');
    let execOrgUnitDetails = state.allOrgUnitDetails.filter(unit => unit.Title === "Executive");
    commit('setExecOrgUnitDetails',execOrgUnitDetails[0]);
    commit('stopLoading');
  },  
  setOrgUnitStructure({commit, dispatch}, user){
      commit('startLoading');
      commit('setOrgUnitStructure', user);
      commit('stopLoading');
  },
  // async saveOrgUnitHead({commit}, user){
  //   commit('startLoading');
  //   await sp.web.lists.getByTitle("Corporate Directory Org Units").items.getById(state.selectedOrgUnit.ID).update({
  //     Manager: user.UserID
  //   }).then(result => {
  //       commit('setOrgUnitHead', user);
  //   });
  //   commit('stopLoading');
  // },
  // async saveBPO({commit}, user){
  //   commit('startLoading');
  //   await sp.web.lists.getByTitle("Corporate Directory Org Units").items.getById(state.selectedOrgUnit.ID).update({
  //     BPO: user.UserID
  //   }).then(result => {
  //       commit('setBranchProjectOfficer', user);
  //       //console.log("BPO")
  //   });
  //   commit('stopLoading');
  // },
  async resetOrgUnitHeadAndBPO({dispatch, commit}){
    commit('startLoading');
    // await sp.web.lists.getByTitle("Corporate Directory Org Units").items.getById(state.selectedOrgUnit.ID).update({
    await sp.web.lists.getByTitle("Corporate Directory Org Units Details").items.getById(state.selectedOrgUnitDetails.ID).update({
      BPO: '',
      Manager: ''
    }).then(async result => {
      // commit('setOrgUnitHead');
      commit('setBranchHead');
      commit('setBranchProjectOfficer');
      commit('setDirector');
      commit('setTeamLeader');
      commit('stopLoading');
    });

    let defaultManager = undefined;
    let defaultBSO = undefined;
    const orgId = state.selectedOrgUnit.OrgUnitNumber;
    const orgLevel = state.selectedOrgUnit.OrgUnitLevel;
    if(orgLevel === 4){
      defaultManager = await dispatch('getDefaultBranchHead', orgId);
      commit('setBranchHead', defaultManager);
      defaultBSO = await dispatch('getDefaultBSO', orgId);    
      commit('setBranchProjectOfficer', defaultBSO);
    }
    else if(orgLevel === 5){
      defaultManager = await dispatch('getDefaultDirector', orgId);
      commit('setBranchHead', defaultManager);
    }
  }
}

//mutations
const mutations = {
  startLoading(state){
      state.loading = true;
  },
  stopLoading(state){
    setTimeout(function(){ 
        state.loading = false;
    }, 200); 
  },
  setSelectedOrgUnit(state, orgUnit){
    (orgUnit) ? state.selectedOrgUnit = orgUnit : state.selectedOrgUnit = {};   
  },
  setSelectedOrgUnitDetails(state, orgUnitDetails){
    state.selectedOrgUnitDetails = (orgUnitDetails) ?  orgUnitDetails :  {};   
  },  
  setSelectedOrgUnitDescription(state, description){
    if (description) state.selectedOrgUnitDetails.UnitDescription = description;
  },
  setSelectedOrgUnitChildren(state, orgUnits){
    (orgUnits) ? state.selectedOrgUnitChildren = orgUnits : state.selectedOrgUnitChildren = {}; 
  },
  setAllOrgUnits(state, allOrgUnits){
    state.allOrgUnits = allOrgUnits;    
  },
  setAllOrgUnitDetails(state, allOrgUnitDetails){
    state.allOrgUnitDetails = allOrgUnitDetails;    
  },
  setOrgUnitDirectors(state, directors){
    directors ?  state.orgUnitDirectors = directors : state.orgUnitDirectors = [];
  },
  setOrgUnitManager(state, manager){
    manager ?  state.orgUnitHead = orgUnitHead : state.orgUnitHead = {};
  },
  setOrgUnitHead(state, orgUnitHead){
    orgUnitHead ?  state.orgUnitHead = orgUnitHead : state.orgUnitHead = {};
    if(orgUnitHead) state.selectedOrgUnitDetails.Manager = orgUnitHead.UserID;
  },
  setBranchHead(state, branchHead){
    branchHead ? state.branchHead = branchHead : state.branchHead = {}
  },
  setBranchProjectOfficer(state, branchProjectOfficer){
    if(branchProjectOfficer){
      state.branchProjectOfficer = branchProjectOfficer;
      state.selectedOrgUnitDetails.BPO = branchProjectOfficer.UserID;
    }
    else{
      state.branchProjectOfficer = {}
    }
  },
  setDirector(state, director){
    director ? state.director = director : state.director = {}
  },
  setTeamLeader(state, teamLeader){
    teamLeader ? state.teamLeader = teamLeader : state.teamLeader = {}
  },
  setBranchRefiners(state, branch){
    state.branchRefiners.push(branch);
    state.branchRefiners.sort(function(a,b){
      if (a > b) {
        return 1;
      }
      if (b > a) {
        return -1;
      }
      return 0;
    })
  },
  setOrgUnitStructure(state, user){
    if (user){
      if(state.branches.indexOf(user.BranchState) === -1 && !IsNullOrUndefined(user.BranchState)) state.branches.push(user.BranchState);
      if(state.sections.indexOf(user.Section) === -1 && !IsNullOrUndefined(user.Section)) state.sections.push(user.Section);
      if(state.teams.indexOf(user.TeamDivisionLWU) === -1 && !IsNullOrUndefined(user.TeamDivisionLWU)) state.teams.push(user.TeamDivisionLWU);
    }
    else{
      state.branches = [];
      state.sections = [];
      state.teams = [];
    }
  },
  setExecOrgUnit(state, unit){
    (unit) ? state.execOrgUnit = unit : state.execOrgUnit = {};
  },
  setExecOrgUnitDetails(state, unit){
    (unit) ? state.execOrgUnitDetails = unit : state.execOrgUnitDetails = {};
  }
}

export default{
    state,
    getters,
    actions,
    mutations
}