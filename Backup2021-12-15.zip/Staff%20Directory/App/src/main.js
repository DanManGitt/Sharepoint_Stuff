// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.

//global imports
import Vue from "vue";
import store from "./Store";
import VueRouter from "vue-router";
import BootstrapVue from "bootstrap-vue";
import ToastPlugin from "bootstrap-vue";
import { sp } from "@pnp/sp";
import InfiniteLoading from "vue-infinite-loading";
import vuetypeaheadbootstrap from 'vue-typeahead-bootstrap'
import VueScrollTo from 'vue-scrollto';
import AsyncComputed from 'vue-async-computed';

//Component imports
import StaffDirectory from "./components/StaffDirectory/StaffDirectory.vue";

Vue.config.productionTip = false;
Vue.use(AsyncComputed);
Vue.use(BootstrapVue);
Vue.use(VueRouter);
Vue.use(InfiniteLoading);
Vue.use(ToastPlugin);
Vue.use(VueScrollTo);

// Global registration
Vue.component('vue-typeahead-bootstrap', vuetypeaheadbootstrap)

//setup pnp for JSON light (sp environments that aren't patched)
sp.setup({
  sp: {
    headers: {
      Accept: "application/json;odata=verbose",
      Authorisation: "Bearer " + $("#__REQUESTDIGEST").value
    },
    credentials: "include",
    mode: "cors"
  }
});

//global date format filter
Vue.prototype.$filters = Vue.options.filters; //make filters available globally in JS code
Vue.filter("standardDateFormat", function(value) {
  return moment(value).format("D MMM YYYY h:mmA");
});
Vue.filter("dateOnlyFormat", function(value) {
  return moment(value).format("D MMM YYYY");
});
Vue.filter("day", function(value) {
  return moment(value).format("Do");
});
Vue.filter("month", function(value) {
  return moment(value).format("MMMM");
});
Vue.filter("removeBrackets", function(value){
  if (!value) return '';
  let newVal = "";
  newVal = value.replace(/\(/g,"").replace(/\)/g,"");
  if (value.indexOf("/ ") !== -1){
    newVal = newVal.split("/ ")[1];
  }
  return newVal;
});
Vue.filter("capitalise", function(value){
    if (!value) return ''

    const isAllCaps = value === value.toUpperCase();
    if (!isAllCaps) {
      return value;
    }

    // Only manipulate name if original value is all Caps
    value = value.toString().toLowerCase().trim();
    if(value.indexOf("de ") === 0){
      value = value.slice(0,3)  + value.charAt(3).toUpperCase() + value.slice(4);
    }
    else if(value.indexOf("mc") === 0 || value.indexOf("'") === 1){
      value = value.charAt(0).toUpperCase() + value.slice(1,2) + value.charAt(2).toUpperCase() + value.slice(3);
    }
    else{
      value = value.charAt(0).toUpperCase() + value.slice(1);
    }

    if (value.indexOf('-') !== -1 &&  value.indexOf(' ') === -1){
      const dashIndex = value.indexOf('-');
      value = value.slice(0,dashIndex+1) + value.charAt(dashIndex+1).toUpperCase() + value.slice(dashIndex+2);
    }

    return value
})

Vue.filter("initial", function(value){  
  if (!value) return ''
  return value.charAt(0).toUpperCase()
})

Vue.filter("orgTitleFilter", function(value){
  if (!value) return ''
  let newValue = value.toString().toLowerCase();
  if(newValue === "special positions"){
    return "Additional Positions"
  }
  else{
    return value
  }
})
Vue.filter("apsToUpper", function(value){
  if (!value) return ''
  //only replace stand alone of strings 'aps' | 'aps ' | aps[1-9]
  let newValue = value.toString().replace(/\baps(?=[1-9 ])/ig,'APS');   
  return newValue;
})

let VMs = [];
let VM = null;

function cleanupVM() {
  VMs.forEach(vm => {
    vm.$destroy();
  });
}

//execute controls inside this function when they are dependent on SP.ClientContext
SP.SOD.executeFunc("sp.js", "SP.ClientContext", function() {
  let inDesignMode = typeof document.forms[MSOWebPartPageFormName].MSOLayout_InDesignMode !== "undefined"  ? document.forms[MSOWebPartPageFormName].MSOLayout_InDesignMode.value : "0";
  let wikiInEditMode = typeof document.forms[MSOWebPartPageFormName]._wikiPageMode !== "undefined"  ? document.forms[MSOWebPartPageFormName]._wikiPageMode.value : "0";
  let editMode = inDesignMode === "1" || wikiInEditMode === "Edit" ? true : false;
  $(document).ready(function() {
    
    window.addEventListener("unload", cleanupVM);

    //start staff directory component
    if (document.getElementById("staff-directory") && !editMode) {
      let lockToSection = "";
      let lockToBranch = "";
      let lockToTeam = "";
      let fullStaffDirectoryPath = "";
      let userListSitePath = "";
      let isWidget = false;
      let showFavourites = false;

      if (typeof $("#staff-directory").data("locktosection") !== "undefined")
        lockToSection = $("#staff-directory").data("locktosection");

      if (typeof $("#staff-directory").data("locktobranch") !== "undefined")
        lockToBranch = $("#staff-directory").data("locktobranch");

      if (typeof $("#staff-directory").data("locktoteam") !== "undefined")
        lockToTeam = $("#staff-directory").data("locktoteam");

      if (
        typeof $("#staff-directory").data("staffdirectorypath") !== "undefined"
      )
        fullStaffDirectoryPath = $("#staff-directory").data(
          "staffdirectorypath"
        );

      if (typeof $("#staff-directory").data("iswidget") !== "undefined")
        isWidget = $("#staff-directory").data("iswidget");

      if (typeof $("#staff-directory").data("showfavourites") !== "undefined")
        showFavourites = $("#staff-directory").data("showfavourites");

      if (typeof $("#staff-directory").data("userlistsitepath") !== "undefined")
        userListSitePath = $("#staff-directory").data("userlistsitepath");

      new Vue({
        el: "#staff-directory",
        template: `<StaffDirectory 
                  :lockToSection="'${lockToSection}'" 
                  :lockToBranch="'${lockToBranch}'" 
                  :lockToTeam="'${lockToTeam}'" 
                  :fullStaffDirectoryPath="'${fullStaffDirectoryPath}'" 
                  :userListSitePath="'${userListSitePath}'"                   
                  :isWidget="${isWidget}" 
                  :showFavourites="${showFavourites}" 
                  />`,
        store,
        components: { StaffDirectory }
      });
    }
  });
});
