'use strict';
var spsave = require('gulp-spsave');

// Put deployment options into file called "deployment-options.json"
// use the following structure
// {
//     "siteUrl" : "http://deploymentsite/",
//     "adminSiteUrl" : "http://teams.dev.aec.local/sites/admin/",
//     "creds" : {
//         "username": "user_name",
//         "password": "password"
//     }
// }
//
//
// To stop Git from monitoring changes to this file so that your credentials are not checked into source control
//    git update-index --assume-unchanged deployment-options.json
// to Start tracking again
//    git update-index --no-assume-unchanged deployment-options.json
//
var deployOptions = require('./deployment-options.json');

var siteUrl = deployOptions.siteUrl;
var adminSiteUrl = deployOptions.adminSiteUrl;
var creds = {
    username: deployOptions.creds.username,
    password: deployOptions.creds.password
}

//gulp and dependencies
var gulp = require('gulp'),
    watch = require('gulp-watch'),
    sass = require('gulp-sass');

//Sass compilation for dev build
gulp.task('sass', function () {
    return gulp.src('./src/sass/*.scss')
        .pipe(sass().on('error', sass.logError))
        .pipe(gulp.dest('./dist/css'));
});

//Sass compilation for prod build
gulp.task('sass-prod', function () {
    return gulp.src('./src/sass/*.scss')
        .pipe(sass({ outputStyle: 'compressed' }).on('error', sass.logError))
        .pipe(gulp.dest('./dist/css'));
});

//Load js into SP site
gulp.task("spsave-js", function () {
    return gulp.src(["./dist/js/*.js*"])
        .pipe(spsave({
            siteUrl: adminSiteUrl,
            folder: "/Style Library/dist/js/",
            flatten: false,
            checkin: false
        }, creds));
});

//Save css into SP site
gulp.task("spsave-css", function () {
    return gulp.src(["./dist/css/*.css*"])
        .pipe(spsave({
            siteUrl: adminSiteUrl,
            folder: "/Style Library/dist/css/",
            flatten: false,
            checkin: false
        }, creds));
});

//Save masterpage into SP site
gulp.task("spsave-masterpage", function () {
    return gulp.src(["../SharePoint/_catalogs/masterpage/*.*"])
        .pipe(spsave({
            siteUrl: siteUrl,
            folder: "_catalogs/masterpage",
            flatten: false,
            checkin: true,
            checkinType: 1
        }, creds));
});

//Watch for changes in the masterpage
gulp.task('watch-mpage', function () {
    gulp.watch('../SharePoint/_catalogs/masterpage/*.*', ['spsave-masterpage']);
});

//Watch for changes in any .scss files and then run sass compilation
gulp.task('watch-sass', function () {
    gulp.watch('./src/sass/*.scss', ['sass']);
});

//Watch for changes in any .css files and load to SP site
gulp.task('watch-css', function () {
    gulp.watch('./dist/css/*.css', ['spsave-css']);
});

//Watch for changes in any .js files and load to SP site
gulp.task('watch-app', function () {
    gulp.watch('./dist/js/*.js', ['spsave-js']);
});