'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  MY_SITES_URL: '"http://dev-sp13-act20/"',
  SEARCH_RESULTS_STUB: "'/searchcenter/pages/'"
})
