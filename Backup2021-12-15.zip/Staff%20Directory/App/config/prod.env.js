'use strict'
module.exports = {
  NODE_ENV: '"production"',
  MY_SITES_URL: '"http://dev-sp13-act20/"',
  SEARCH_RESULTS_STUB: "'/searchcenter/pages/'"
}
