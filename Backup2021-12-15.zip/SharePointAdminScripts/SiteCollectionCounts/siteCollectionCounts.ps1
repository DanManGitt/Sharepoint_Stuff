﻿Add-PSSnapin Microsoft.SharePoint.PowerShell

$webApps = Get-SPWebApplication
$total = 0
foreach($webApp in $webApps){
    $siteCount = 0
    foreach($site in $webApp.Sites){
        if($site.Url.IndexOf("mysites") -eq -1){
            $siteCount++
        }
    }
    Write-Host $webApp.DisplayName $siteCount
    $total += $siteCount
}
Write-Host "Total: " $total 