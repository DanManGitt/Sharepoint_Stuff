
Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

$creds = get-credential

Connect-PnPOnline -Url "https://aecspace.prod.aec.gov.au" -Credentials $creds
function writeItem($item,$attachments) {
    # check if file exists first
    #$items=Add-PnPListItem -List testlist

    #$newListItem = Set-PnPListItem -Identity $ItemId -List testlist -Values @{"Title" = $itemTitle; "other" = $itemOther}

    for ($a=0; $a -lt $attachments.length; $a++) {
        #Write-host " " $attachments[$a]
        writeAttachment -item $item -fileWithPath  $attachments[$a]
    }
}

function writeAttachment($item, $fileWithPath){
    $ctx=Get-PnPContext
    $memoryStream = New-Object IO.FileStream($fileWithPath,[System.IO.FileMode]::Open)
    $fileName = Split-Path $fileWithPath -Leaf
    $attachInfo = New-Object -TypeName Microsoft.SharePoint.Client.AttachmentCreationInformation
    $attachInfo.FileName = $fileName
    $attachInfo.ContentStream = $memoryStream
    $attFile = $item.attachmentFiles.add($attachInfo)
    $ctx.load($attFile)
    $ctx.ExecuteQuery()
}

$results = Submit-PnPSearchQuery -Query "ContentClass:STS_Site" -TrimDuplicates:$false
Disconnect-PnPOnline

#$siteCols = @();
$urls = $results.ResultRows | ForEach-Object{$_.Path}
# foreach ($siteCol in $results.ResultRows) {
#     $siteCols + $siteCol.Path;
# }
# Write-Host $siteCols
# Write-Host $urls
#Define list of sites to collect inventory for
$sites = 
"https://aecspace.prod.aec.gov.au/sites/vic-election",
"https://aecspace.prod.aec.gov.au/sites/tas/"

$ownerData = @(
       [pscustomobject]@{
           CurrentOwners = 'Commercial Law and Procurement','Legal and Procurement','Legal and Procurement Branch','Legal Services','Legal Services Section';
           ExpectedOwner = 'Legal and Procurement Branch'
        }
        [pscustomobject]@{
            CurrentOwners = 'Corporate Services','Corporate Services Branch','Finance & Business Services','Finance and Business Services';
            ExpectedOwner = 'Corporate Services Branch'
        }
        [pscustomobject]@{
            CurrentOwners = 'Disclosure, Assurance and Engagement','Disclosure, Assurance and Engagement Branch','Disclosure, Assurance and Engagement.','Information and Communications Technology Branch','Information, Communication and Technology','Information, Communication and Technology Branch','Education and Communications';
            ExpectedOwner = 'Digital Technology and Communications Branch'
        }
        [pscustomobject]@{
            CurrentOwners = 'Election planning','Election Planning, Policy and Operations','Operations Branch';
            ExpectedOwner = 'Digital Technology and Communications Branch'
        }
        [pscustomobject]@{
            CurrentOwners = 'Elections','Elections Branch','Enrolment','Roll Management and Community Engagement Branch';
            ExpectedOwner = 'Delivery and Support Branch'
        }
        [pscustomobject]@{
            CurrentOwners = 'International','International Services';
            ExpectedOwner = 'Community and International Engagement Section'
        }
)

#Read more: https://www.sharepointdiary.com/2016/10/get-all-site-collections-in-web-application-using-powershell.html#ixzz6TLPL0Oxs

#destination list url to put the items and attachments
$destinationUrl = "https://aechub.prod.aec.gov.au/teams/intranet-cleanup"

#connect to each site
foreach($site in $urls){
    Connect-PnPOnline -Url $site -Credentials $creds
    #pupulate an array of all webs to iterate over, including the root site collection web
    $webs = [System.Collections.ArrayList]@()
    $webs.Add($site)
    $subwebs = Get-PnPSubWebs -Recurse
    foreach($subweb in $subwebs){
        $webs.Add($subweb.Url)
    }

    $siteInfoList = Get-PnPListItem -List "Site_Information"
    
    if($null -eq $siteInfoList){
        $newOwner = "Unknown"
        $siteCategory = "Unknown"
        $siteStatus = "Unknown"
    }
    else{
        #$businessOwner
        $newOwner  = $siteInfoList["BusinessOwner"].Label
        $siteCategory = $siteInfoList["SiteCategory"].Label
        $siteStatus = $siteInfoList["SiteStatus"]
        foreach ($owner in $ownerData) {
            foreach($currentOwner in $owner.CurrentOwners){
                #check for the current owner field
                if($newOwner -eq $currentOwner){
                    #check for the new owner
                    $newOwner = $owner.ExpectedOwner   
                }
            }
            
        }
    }
    
    Disconnect-PnPOnline
    #Create Excel object
    $excel = New-Object -ComObject excel.application
    $excel.visible = $True
    $workbook = $excel.Workbooks.Add()

    #iterate through list of webs, connecting and retreiving list info, then adding az new worksheet for each web
    $worksheetIndex = 1
    foreach($web in $webs){
        
        Connect-PnPOnline -Url $web -Credentials $creds
        $currentWeb = Get-PnPWeb;

        #Print out current web details into the top of the worksheet
        #$currentWebWorksheet = $workbook.Worksheets.Item($worksheetIndex)
        $sheet = $workbook.ActiveSheet
        $lastSheet = $sheet
        $currentWebWorksheet = $workbook.Worksheets.add([System.Reflection.Missing]::Value,$lastsheet)
        #Write-Host $currentWebWorksheet
        $worksheetTitle = $currentWeb.Title.Replace("/","-")
        if($worksheetTitle.length -gt 30){
            $worksheetTitle = $worksheetTitle.Substring(0,30)
        }
        $currentWebWorksheet.Name = $worksheetTitle
        $currentWebWorksheet.Cells.Item(1,1) = "Site Information"
        $currentWebWorksheet.Cells.Item(1,1).Font.Size = 14
        $currentWebWorksheet.Cells.Item(1,1).Font.Bold = $True
        $currentWebWorksheet.Cells.Item(2,1) = "Site title"
        $currentWebWorksheet.Cells.Item(2,2) = $currentWeb.Title
        $currentWebWorksheet.Cells.Item(3,1) = "Site url"
        $currentWebWorksheet.Cells.Item(3,2) = $currentWeb.Url
        $currentWebWorksheet.Cells.Item(4,1) = "Site description"
        $currentWebWorksheet.Cells.Item(4,2) = $currentWeb.Description

        $currentWebWorksheet.Hyperlinks.Add(
            $currentWebWorksheet.Cells.Item(3,2),
            $currentWeb.Url,
            "",
            "",
            $currentWeb.Url
        ) | Out-Null

        #Print out list info for current web
        $currentWebWorksheet.Cells.Item(6,1) = "List Information"
        $currentWebWorksheet.Cells.Item(6,1).Font.Size = 14
        $currentWebWorksheet.Cells.Item(6,1).Font.Bold = $True

        #create the column headers
        $currentWebWorksheet.Cells.Item(7,1) = 'List Title'
        $currentWebWorksheet.Cells.Item(7,2) = 'List Url'
        $currentWebWorksheet.Cells.Item(7,3) = 'Item Count'
        $currentWebWorksheet.Cells.Item(7,4) = 'Last Item Modified'
        $lists = Get-PnPList;
        $index = 8
        foreach($list in $lists){
            $currentWebWorksheet.Cells.Item($index,1) = $list.Title
            $currentWebWorksheet.Hyperlinks.Add(
                $currentWebWorksheet.Cells.Item($index,2),
                "https://aecspace.prod.aec.gov.au" + $list.DefaultViewUrl,
                "",
                "",
                $list.DefaultViewUrl
            ) | Out-Null
            #$currentWebWorksheet.Cells.Item($index,2) = $list.DefaultViewUrl
            $currentWebWorksheet.Cells.Item($index,3) = $list.ItemCount
            $currentWebWorksheet.Cells.Item($index,4) = $list.LastItemModifiedDate
            $index++
        }
        #make usre all columns are visible
        $usedRange = $currentWebWorksheet.UsedRange
        $usedRange.EntireColumn.AutoFit() | Out-Null
        
        $worksheetIndex++
        Disconnect-PnPOnline
    }
    $workbook.Worksheets.item(1).Delete()
    $workbook.Worksheets.item(1).Activate()
    Connect-PnPOnline -Url $site -Credentials $creds
    $currentWeb = Get-PnPWeb;

    #setup the filename and save the excel document
    #$path = "C:\Users\gbailey\SharePointAdminScripts\Excel\"
    $fileName = $currentWeb.Title -replace ('[\W]', '-') #Regex away all "non-words", replace with dashes(-)'s
    #$fileName = "SharePointAdminScripts\Excel\" + $fileName + ".xlsx"
    $fileNameWithPath = "SharePointAdminScripts\SiteInventory\Excel\" + $fileName + ".xlsx"
    #$outputpath = $path + $fileName + ".xls"
    $fullPath = join-path -Path $env:USERPROFILE -ChildPath $fileNameWithPath
    #$name = "desktop\excelltest.xlsx"
    $outputpath = $fullPath
    
    #turn off alerts so you can overwright existing files
    $excel.DisplayAlerts = $false;

    #save the file and quite excel
    $workbook.SaveAs($outputpath)
    $excel.Quit()

    #Disconnect
    Disconnect-PnPOnline
    Connect-PnPOnline -Url $destinationUrl -Credentials $creds

    #try and retrieve an existing item
    $query = "<View><Query><Where><Eq><FieldRef Name='Siteid'/><Value Type='Text'>" + $currentWeb.Id + "</Value></Eq></Where></Query></View>"
    $item = Get-PnPListItem -List 2933a43f-6927-47d0-88ba-f0baa2262b03 -Query $query

    #if item doesn't exist then add it
    if($Null -eq $item){
        $addItem = Add-PnPListItem -List 2933a43f-6927-47d0-88ba-f0baa2262b03 -Values @{"Title" = $currentWeb.Title; "Url"= $currentWeb.Url; "Siteid" = $currentWeb.Id; "Subsites" = $subwebs.Length; "SiteCategory" = $siteCategory; "SiteStatus" = $siteStatus; "BusinessOwner" = $newOwner  }
    }
    #if item already exists, update it and delete the attachment so we can re load it. 
    else {
        $addItem = Set-PnPListItem -List 2933a43f-6927-47d0-88ba-f0baa2262b03 -Identity $item.Id  -Values @{"Title" = $currentWeb.Title; "Url"= $currentWeb.Url; "Siteid" = $currentWeb.Id; "Subsites" = $subwebs.Length;  "SiteCategory" = $siteCategory; "SiteStatus" = $siteStatus; "BusinessOwner" = $newOwner }
        $clientContext = Get-PnPContext
        $existingFile = $item.AttachmentFiles.GetByFileName($fileName + ".xlsx")
        $existingFile.DeleteObject()
        $clientContext.ExecuteQuery()

    }
    
    
    $Att=@($fullPath)

    writeItem -item $addItem -attachments $Att 
    Disconnect-PnPOnline
}
