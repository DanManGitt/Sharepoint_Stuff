
Add-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue
#Source site collection to pull data from:
$Source = "https://aechub.prod.aec.gov.au"

#Source directory to pull data from:
$SourceFiles = "$source/SiteAssets/Images"

#Destination Sites:
$sites = get-spsite -limit all | where-object {$_.url -match "$Source/"} #The / Suffix will ensure the root site collection is ignored.


#Get a list of all webs utilizing the STS#3 (Modern Team Site) and SITEPAGEPUBLISHING#0 (Communication Site) templates 
$webs = @() 
foreach ($site in $sites) {
    $web = get-spweb $site.url
    if ($web.Configuration -eq 3 -and $web.WebTemplate -eq "STS") {
        $webs += $web
    }
    if ($web.Configuration -eq 0 -and $web.WebTemplate -eq "SITEPAGEPUBLISHING") {
        $webs += $web
    }
}

#Download all files from source
connect-pnponline $source -CurrentCredentials
$SourceConnection = Get-PnPConnection
$subfolders = get-pnpfolderitem -Identity $SourceFiles -ItemType Folder 

#Copies all the files in a given folder across.
Function CopyFiles($Folder) {
    $files = Get-PnPFolderItem -identity $folder.ServerRelativeUrl -ItemType File -Connection $SourceConnection 
    foreach ($web in $webs) {
        $URL = $web.URL
        connect-pnponline -Url $URL -CurrentCredentials
        foreach ($file in $files) {
            $SRU = $file.ServerRelativeURL
            $WSRU = $web.ServerRelativeURL
            $filename = $file.name
            write-host "Copying $SRU$filename to $URL"
            Copy-PnPFile -SourceUrl $SRU -TargetUrl "$WSRU$SRU" -Connection $SourceConnection -confirm:$false -force -ErrorAction SilentlyContinue
        }
    }
}

#The "-recursive" switch never seems to work properly with "Get-PnPFolderItems" - I built a function to do the same thing
Function FindFolders($Folder){
    $Folder
    $RecursiveSearch = get-pnpfolderitem -identity $folder.ServerRelativeUrl -ItemType Folder
    if ($RecursiveSearch) {
        foreach ($Folder in $RecursiveSearch) {
            FindFolders -Folder $Folder
        }
    }
}

#Build all the subfolders in the modern sites
Function CreateFolders($Folder) {
    $fpath = (Get-PnPFolder -Url $folder.ServerRelativeUrl -Includes ParentFolder.ServerRelativeURL -Connection $SourceConnection).ParentFolder.ServerRelativeURL #Get the parent folder 
    $fname = $folder.Name
    foreach ($web in $webs) {
        Connect-PnPOnline $web.url -CurrentCredentials 
        $url = $web.url
        #Create the Image directory if needed
        Try {
            $ImageFolder = get-pnpfolder -Url /SiteAssets/Images -ErrorAction Stop
        }
        Catch {
            write-host "No image folder found - Creating one"
            Add-PnPFolder -Name "Images" -Folder /SiteAssets/
            start-sleep 3 #Give it a few secs to allow replication
            $ImageFolder = get-pnpfolder -Url /SiteAssets/Images -ErrorAction Stop
        }
        if (!$ImageFolder) {
            write-host "The Image folder has not been generated, stopping script."
            break
            pause
        }
        write-host "Creating folder structure: $fname`t$fpath on $url"
        Add-PnPFolder -Name "$fname" -Folder $fpath -ErrorAction SilentlyContinue
        start-sleep 1 #Delays in to allow for provisioning.
    }
} 

#This gets all the subfolders that might be in the source directory.
$FolderList = foreach ($folder in $Subfolders) {FindFolders -Folder $folder} 

#If the wiki feature is enabled a site asset library will be provisioned automatically. If it already is enabled the library should already be there.
foreach ($web in $webs) {
    $Url = $web.url
    Connect-PnPOnline $URL -CurrentCredentials
    if ((get-PnPfeature -scope web).definitionID -notcontains "00bfea71-d8fe-4fec-8dad-01c19a6e4053") {
        Write-host "The Wiki feature is not enabled on $url. Enabling it to generate a site assets library"
        Enable-PnPfeature -identity 00bfea71-d8fe-4fec-8dad-01c19a6e4053
        start-sleep 2 #Give a few secs to allow provisioning
    }
}

#Iterate through each folder, creating required folder structure then copying the files across.
foreach ($folder in $FolderList) {
    CreateFolders -Folder $folder
    CopyFiles -folder $folder
}

#Don't forget to copy the base folder
$folder = Get-PnPFolder -Url "/SiteAssets/Images" -Connection $SourceConnection -ErrorAction Stop
CopyFiles -folder $folder