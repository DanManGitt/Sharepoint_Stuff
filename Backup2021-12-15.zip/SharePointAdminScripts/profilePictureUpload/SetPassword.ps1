#Use this script to create the encrypted password file required for the pictureUploadScript.
#It needs to be run as the service account that will be running the script.
#If interactive login is not available with the service account, schedule this script to run as a once-off task with the credentials of the service account.
#Once the password file is created, remove the password from this script. DevOps build process may overwrite this file without notice.

# Define clear text password
[string]$userPassword = 'InsertPasswordToEncryptHere'

# Crete credential Object
[SecureString]$secureString = $userPassword | ConvertTo-SecureString -AsPlainText -Force 

# Get content of the string
[string]$stringObject = $secureString | ConvertFrom-SecureString

# Save Content to file
$stringObject | Set-Content -Path 'C:\DirSync\Password.txt'