Add-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue
$wa = Get-SPWebApplication -Identity "http://aecspace.prod.aec.gov.au"

foreach ($siteCollection in $wa.sites) {
    Write-Host $siteCollection
}