Add-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue;
#[xml]$inputfile = Get-Content C:\Data\theme\ThemeScriptInput.xml

$WebApp = Get-SPWebApplication 'https://cedars.dev.aec.local'

#Get all Site collections from the web application
$SiteCollections  = $WebApp.Sites

$ColorFilePartUrl = "/_catalogs/theme/15/";
$FontFilePartUrl = "/_catalogs/theme/15/";
#$ColorFilePartUrl = "";
#$FontFilePartUrl = "";
$MasterPagePartUrl = "/_catalogs/masterpage/";
 
foreach( $site in $SiteCollections)
{
    #$siteurl = $site.Url;
    $siteUrl = $site.Url;
    $themeName = 'AEC Theme';
    $colorfile = 'aecPalette.spcolor';
    $fontfile = 'fontschemeRoboto.spfont';
    $masterpage = 'seattle.master';
    $colorshemeFilePath = './assets/aecPalette.spcolor';
    $colorfontFilePath = './assets/fontschemeRoboto.spfont';
    $IsfilesToUpload = 'true';
 
    Write-Host "$siteurl + " :: " + $themeName + " :: " + $colorfile + " :: " + $fontfile + " :: " + $masterpage";
    
    #Enable custom scripts
    (Get-SPSite -Identity $siteUrl).DenyPermissionsMask= [Microsoft.SharePoint.SPBasePermissions]::EmptyMask
     
    $site = Get-SPSite $siteurl;
    $rootweb = $site.RootWeb;
 
    if($IsfilesToUpload -eq "true")
    {
        #region Upload theme files to the root web gallery      
 
        $colorSchemeBytes = [System.IO.File]::ReadAllBytes($colorshemeFilePath);
        $fontSchemeBytes = [System.IO.File]::ReadAllBytes($colorfontFilePath);
 
        $rootweb.allowunsafeupdates = $true;
        $themeList = $rootweb.GetCatalog([Microsoft.SharePoint.SPListTemplateType]::ThemeCatalog);
        $folder = $themeList.RootFolder.SubFolders["15"];
        $folder.Files.Add($colorfile,$colorSchemeBytes,$true);
        $folder.Files.Add($fontfile,$fontSchemeBytes, $true);
        $rootweb.allowunsafeupdates = $false;
        #endregion
    }
 
    $colorfile=$site.AllWebs[0].GetFile("$siteurl$ColorFilePartUrl$colorfile");
    $fontfile=$site.AllWebs[0].GetFile("$siteurl$FontFilePartUrl$fontfile");
 
    foreach ($Web in $site.AllWebs)
    {
       Write-Host "processing: " $Web.Title;
       $Web.allowunsafeupdates = $true;
       $relativeUrl = $Web.ServerRelativeUrl;
       $spList = $Web.GetCatalog([Microsoft.SharePoint.SPListTemplateType]::DesignCatalog);
 
       #region Add New theme to the Composed Looks gallery
 
       $SPQuery1 =  New-Object Microsoft.SharePoint.SPQuery;
       $SPQuery1.Query = "<Where><Eq><FieldRef Name='Name'/><Value Type='Text'>$themeName</Value></Eq></Where>";
       $SPQuery1.RowLimit = 1;
       $SPQuery1.ViewFields = "<FieldRef Name='Name'/>";
       $SPQuery1.ViewFieldsOnly = $true;
 
       $spListItems1 = $spList.GetItems($SPQuery1);
        
 
       if($spListItems1.Count -eq 0)
       {        
 
       $newThemeItem = $spList.AddItem();
 
       $newThemeItem["Name"] = $themeName;
       $newThemeItem["Title"] = $themeName;
       $newThemeItem["MasterPageUrl"] =  "/_catalogs/masterpage/$masterpage";#$Web.MasterUrl;
       $newThemeItem["ThemeUrl"] = "$colorfile";
       $newThemeItem["FontSchemeUrl"] = "$fontfile";
       $newThemeItem["DisplayOrder"] = 121;
       $newThemeItem.Update();
 
       }
       #endregion
 
       #region Set the theme
        $file = '/_catalogs/theme/15'+$colorfile;
         
        $theme=[Microsoft.SharePoint.Utilities.SPTheme]::Open($themeName, $file);
        Write-Host $theme.Name "to" $Web.Title;
        $theme.ApplyTo($Web, $false);
         
                 
         
       #endregion
 
       #region Set applied theme as current theme             
 
       $SPQuery =  New-Object Microsoft.SharePoint.SPQuery;
       $SPQuery.Query = "<Where><Eq><FieldRef Name='DisplayOrder'/><Value Type='Number'>0</Value></Eq></Where>";
       $SPQuery.RowLimit = 1;
       $SPQuery.ViewFields = "<FieldRef Name='DisplayOrder'/>";
       $SPQuery.ViewFieldsOnly = $true;
 
       $spListItems = $spList.GetItems($SPQuery);
        
 
       if($spListItems.Count -eq 1)
       {
            $spListItems[0].Delete();
       }
 
       $currentThemeItem = $spList.AddItem();
 
       $currentThemeItem["Name"] = [Microsoft.SharePoint.SPResource]::GetString([System.Threading.Thread]::CurrentThread.CurrentUICulture, [Microsoft.SharePoint.Strings]::DesignGalleryCurrentItemName);
       $currentThemeItem["Title"] = [Microsoft.SharePoint.SPResource]::GetString([System.Threading.Thread]::CurrentThread.CurrentUICulture,[Microsoft.SharePoint.Strings]::DesignGalleryCurrentItemName);
       $currentThemeItem["MasterPageUrl"] = "/_catalogs/masterpage/$masterpage";#$Web.MasterUrl;
       $currentThemeItem["ThemeUrl"] = "$colorfile";
       $currentThemeItem["FontSchemeUrl"] = "$fontfile";
       $currentThemeItem["DisplayOrder"] = 0;
       $currentThemeItem.Update();
 
       #endregion
        
       $Web.allowunsafeupdates = $false;
       Write-Host "Set" $theme.Name "theme to :" $Web.Title "(" $Web.Url ")" ;
    }     
}