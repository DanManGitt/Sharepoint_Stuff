$siteUrl = "https://aechub.dev.aec.local/sites/noc"

Connect-PnPOnline -Url $siteUrl

Apply-PnPProvisioningTemplate -Path 'modernSiteTemplate.xml'

Disconnect-PnPOnline