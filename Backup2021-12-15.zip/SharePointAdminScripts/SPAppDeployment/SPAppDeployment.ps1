Write-host "Please ensure the application to be deployed has been copied into the global app catalog before going through the rest of this script."
Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
function Options {
    #Destination Sites:
    $sites = get-spsite -limit all

    #Get a list of all webs utilizing the STS#3 (Modern Team Site) and SITEPAGEPUBLISHING#0 (Communication Site) templates 
    $webs = @() 
    $AppCatalog = @()
    foreach ($site in $sites) {
        $web = get-spweb $site.url
        if ($web.Configuration -eq 3 -and $web.WebTemplate -eq "STS") {
            $webs += $web
        }
        if ($web.Configuration -eq 0 -and $web.WebTemplate -eq "SITEPAGEPUBLISHING") {
            $webs += $web
        } 
        if ($web.Configuration -eq 0 -and $web.WebTemplate -eq "APPCATALOG") {
            $AppCatalog += $web
        }
    }

    #Select App Catalog
    if ($AppCatalog.count -gt 1) {
        write-host "Multiple app catalogs detected, please select the one you deployed your app to"
        $AppCatalog = $AppCatalog | out-gridview -PassThru -Title "Please select the app catalog you deployed your app to"
    }
    $AppCatalog = $AppCatalog.url

    $UserOption = read-host "Would you like to deploy to a (S)ingle site collection or (A)ll site collections?"

    if ($UserOption -ieq "s") {
        $URL = ($webs | select-object URL |out-gridview -PassThru -Title "Please select the site you wish to deploy to").url
        DeploySite -site $URL -AppCatalog $AppCatalog
    }

    if ($UserOption -ieq "A") {
        $TeamsWebs = $Webs | where-object {$_.WebTemplate -eq "STS"}
        $CommsWebs = $Webs | where-object {$_.WebTemplate -eq "SITEPAGEPUBLISHING"}

        $Options = @('Teams', 'Comms', 'Both')
        $Selection = $Options | out-gridview -title "Please select which type of sites you would like the apps deployed to" -passthru

        write-host "App Component ID is found in `"*AppName*.manifest.json`" in .\src\extensions\*appname*\"
        $id = read-host "Please enter the client side component id of the app you wish to deploy."

        if ($Selection -eq "Teams") {
            DeployAll -sites $TeamsWebs -id $id -AppCatalog $AppCatalog
        }

        If ($Selection -eq "Comms") {
            DeployAll -sites $CommsWebs -id $id -AppCatalog $AppCatalog
        }

        If ($Selection -eq "Both") {
            DeployAll -sites $webs -id $id -AppCatalog $AppCatalog
        }
    }
}

function DeploySite($site, $AppCatalog) {
    Connect-PnPOnline -url $AppCatalog -CurrentCredentials
    $AppCatalogConnection = get-pnpconnection
    write-host "Connecting to site.. (sometimes this takes a minute or two)"
    Connect-PnPOnline -Url $site -CurrentCredentials
    write-host "If you do not see the app you wish to deploy, please ensure it has been uploaded to the app catalog and made available to the whole organisation"
    $App = get-pnpapp -Connection $AppCatalogConnection| out-gridview -PassThru -Title "Please select the app you wish to deploy"
    write-host "Component ID is found in `"*AppName*.manifest.json`" in .\src\extensions\*appname*\"
    $id = read-host "Please enter the client side component id of the app."
    Try {
        Get-PnPList -identity "Deployed Apps" -erroraction Stop
    }
    Catch {
        New-PnPList -title "Deployed Apps" -Template GenericList
        start-sleep 3
        Set-PnPList -Identity "Deployed Apps" -Hidden $True
    }   
    $Title = $App.Title
    Add-PnPCustomAction -Title $Title -Name $Title -Location "ClientSideExtension.ApplicationCustomizer" -ClientSideComponentId $id -Scope Site
    Add-PnPListItem -List "Deployed Apps" -Values @{"Title" = "$Title"}
    write-host "Done"
    pause
    exit
}

function DeployAll($sites, $id, $AppCatalog) {
    Connect-PnPOnline -url $AppCatalog -CurrentCredentials
    $AppCatalogConnection = get-pnpconnection
    write-host "If you do not see the app you wish to deploy, please ensure it has been uploaded to the app catalog and made available to the whole organisation"   
    $hostUrl = $sites[0].Url
    Connect-PnPOnline -Url $hostUrl -CurrentCredentials
    Try {
        Get-PnPList -Title "Deployed Apps" -erroraction Stop
    }
    Catch {
        New-PnPList -title "Deployed Apps" -Template GenericList
        start-sleep 3
        Set-PnPList -Identity "Deployed Apps" -Hidden $True
    }    
    $app = get-pnpapp -Connection $AppCatalogConnection | out-gridview -PassThru -Title "Please select the app you wish to deploy"
    Disconnect-PnPOnline
    foreach ($site in $sites) {
        $url = $site.Url
        $Title = $App.Title
        write-host "Connecting to $url.. (sometimes this takes a minute or two)"
        Connect-PnPOnline -Url $url -CurrentCredentials
        Add-PnPCustomAction -Title $Title -Name $Title -Location "ClientSideExtension.ApplicationCustomizer" -ClientSideComponentId $id -Scope Site
        Add-PnPListItem -List "Deployed Apps" -Values @{"Title" = "$Title"}
        Disconnect-PnPOnline
    }
    write-host "Done"
    pause
    exit
}
Options
